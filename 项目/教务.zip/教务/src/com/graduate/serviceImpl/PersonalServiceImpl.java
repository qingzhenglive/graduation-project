package com.graduate.serviceImpl;

import java.util.List;

import org.hibernate.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.graduate.bean.Job;
import com.graduate.bean.Recruit;
import com.graduate.bean.Undergraduate;
import com.graduate.dao.PersonalDao;
import com.graduate.daoImpl.BaseDaoImpl;
import com.graduate.service.PersonalService;

@Service
public class PersonalServiceImpl  implements PersonalService{
	@Autowired
	private PersonalDao personalDao;


	@Override
	public List<Job> getAllJobPeopleByYear(String year) {
		// TODO Auto-generated method stub
		return personalDao.getAllJobPeopleByYear(year);
	}

	@Override
	public List<Undergraduate> getAllUnderGratuatePeopleByYear(String year) {
		// TODO Auto-generated method stub
		return personalDao.getAllUnderGratuatePeopleByYear(year);
	}
}
