package com.graduate.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.graduate.bean.Comment;
import com.graduate.bean.Company;
import com.graduate.bean.Recruit;
import com.graduate.dao.CompanyDao;
import com.graduate.service.CommentService;
import com.graduate.service.CompanyService;
@Service
public class CompanyServiceImpl implements CompanyService{

	@Autowired
	private CompanyDao companyDao;
	@Override
	public List<Company> getCompanyByPeopleId(int id) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	 //根据招聘信息ID获得公司
	public  Company getCompanyByRecruitId(int id) {
		 return companyDao.getCompanyByRecruitId(id);
	 }

	
}
