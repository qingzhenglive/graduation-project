package com.graduate.serviceImpl;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.graduate.bean.Comment;
import com.graduate.bean.Recruit;
import com.graduate.dao.CommentDao;
import com.graduate.service.CommentService;
@Service
public class CommentServiceImpl implements CommentService{

	@Autowired
	private CommentDao commentDao;
	@Override
	public List<Comment> getPageCommentByTeachingId(int id,int currentPage,int sum) {
		// TODO Auto-generated method stub
		return commentDao.getPageCommentByTeachingId(id,currentPage,sum);
	}
	@Override
	public void InsertComment(Comment comment) {
		commentDao.InsertComment(comment);
		
	}

}
