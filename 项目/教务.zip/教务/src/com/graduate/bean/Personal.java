package com.graduate.bean;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="personal")
public class Personal {
	private int id;
	private String name;
	private int salary;
	private Company company;
	private String exprience;
	private String motto;
	private  String sclass;
	private String post;
	private Set<Teaching> Teachings=new HashSet<Teaching>();
	private  Set<Recruit> recruits=new HashSet<Recruit>();
	
	@Id
	@Column(name="personal_id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@Column(name="personal_name")
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Column(name="personal_salary")
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	@ManyToOne
	@JoinColumn(name="personal_company")
	public Company getCompany() {
		return company;
	}
	public void setCompany(Company company) {
		this.company = company;
	}
	@Column(name="personal_exprience")
	public String getExprience() {
		return exprience;
	}
	public void setExprience(String exprience) {
		this.exprience = exprience;
	}
	@Column(name="personal_motto")
	public String getMotto() {
		return motto;
	}
	public void setMotto(String motto) {
		this.motto = motto;
	}
	
	@Column(name="personal_sclass")
	public String getSclass() {
		return sclass;
	}
	public void setSclass(String sclass) {
		this.sclass = sclass;
	}
	
	@Column(name="personal_post")
	public String getPost() {
		return post;
	}
	public void setPost(String post) {
		this.post = post;
	}
	@OneToMany(mappedBy="lecturer",targetEntity=Teaching.class,cascade=CascadeType.ALL)
	public Set<Teaching> getTeachings() {
		return Teachings;
	}
	public void setTeachings(Set<Teaching> teachings) {
		Teachings = teachings;
	}
	
	@OneToMany(mappedBy="personal",targetEntity=Recruit.class,cascade=CascadeType.ALL)
	public Set<Recruit> getRecruits() {
		return recruits;
	}
	public void setRecruits(Set<Recruit> recruits) {
		this.recruits = recruits;
	}
	
	
	
}
