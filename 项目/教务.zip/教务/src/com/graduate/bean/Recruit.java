package com.graduate.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="recruit")
public class Recruit {

	private int id;
	private String name;
	private String site;
	private String salary;
	private Company company;
	private String time;
	private String responsibility;
	private String classify;
	private Job personal;
	private String require;
	private String change;
	private String demand;
	
	
	
	
	public Recruit() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Recruit(String name, String salary, Company company) {
		super();
		this.name = name;
		this.salary = salary;
		this.company = company;
	}
	@Id
	@Column(name="recruit_id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@Column(name="recruit_name")
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Column(name="recruit_site")
	public String getSite() {
		return site;
	}
	public void setSite(String site) {
		this.site = site;
	}
	@Column(name="recruit_salary")
	public String getSalary() {
		return salary;
	}
	public void setSalary(String salary) {
		this.salary = salary;
	}
	@ManyToOne
	@JoinColumn(name="recruit_company")
	public Company getCompany() {
		return company;
	}
	public void setCompany(Company company) {
		this.company = company;
	}
	@Column(name="recruit_time")
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	@Column(name="recruit_responsibility")
	public String getResponsibility() {
		return responsibility;
	}
	public void setResponsibility(String responsibility) {
		this.responsibility = responsibility;
	}
	@Column(name="recruit_classify")
	public String getClassify() {
		return classify;
	}
	public void setClassify(String classify) {
		this.classify = classify;
	}
	@ManyToOne
	@JoinColumn(name="recruit_personal")
	public Job getPersonal() {
		return personal;
	}
	public void setPersonal(Job personal) {
		this.personal = personal;
	}
	
	@Column(name="recruit_require")
	public String getRequire() {
		return require;
	}
	public void setRequire(String require) {
		this.require = require;
	}
	
	@Column(name="recruit_change")
	public String getChange() {
		return change;
	}
	public void setChange(String change) {
		this.change = change;
	}
	
	@Column(name="recruit_demand")
	public String getDemand() {
		return demand;
	}
	public void setDemand(String demand) {
		this.demand = demand;
	}
	
	
	
	
	
}
