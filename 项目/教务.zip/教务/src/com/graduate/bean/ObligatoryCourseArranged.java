package com.graduate.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "obligatoryCourseArranged")
public class ObligatoryCourseArranged {

	private int ocaId;
	private int tcId;
	private int courseId;
	private int acId;

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int getOcaId() {
		return ocaId;
	}

	public void setOcaId(int ocaId) {
		this.ocaId = ocaId;
	}

	public int getTcId() {
		return tcId;
	}

	public void setTcId(int tcId) {
		this.tcId = tcId;
	}

	public int getCourseId() {
		return courseId;
	}

	public void setCourseId(int courseId) {
		this.courseId = courseId;
	}

	public int getAcId() {
		return acId;
	}

	public void setAcId(int acId) {
		this.acId = acId;
	}

	@Override
	public String toString() {
		return "ObligatoryCourseArranged [ocaId=" + ocaId + ", tcId=" + tcId + ", courseId=" + courseId + ", acId="
				+ acId + "]";
	}

}
