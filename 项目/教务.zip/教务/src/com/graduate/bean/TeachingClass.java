package com.graduate.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "teachingClass")
public class TeachingClass {

	private int tcId;
	private String tcName;
//	private int courseId;
	private Courses course;
	private String tcpNum;
//	private int crId;   // 教室号
	private Classroom classroom;
	private String tcComponent;
	private String tId;
//	private int tsId; // 排课号
	private TeachingSchedule teachingSchedule;
	private int inputted;
	private int containRetake;  //1 yes, 0 no
	private int tcCapacity;     // 容量
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int getTcId() {
		return tcId;
	}
	public void setTcId(int tcId) {
		this.tcId = tcId;
	}
	public String getTcName() {
		return tcName;
	}
	public void setTcName(String tcName) {
		this.tcName = tcName;
	}
	public String getTcpNum() {
		return tcpNum;
	}
	public void setTcpNum(String tcpNum) {
		this.tcpNum = tcpNum;
	}
	public String getTcComponent() {
		return tcComponent;
	}
	public void setTcComponent(String tcComponent) {
		this.tcComponent = tcComponent;
	}
	public String gettId() {
		return tId;
	}
	public void settId(String tId) {
		this.tId = tId;
	}
	public int getInputted() {
		return inputted;
	}
	public void setInputted(int inputted) {
		this.inputted = inputted;
	}
	public int getContainRetake() {
		return containRetake;
	}
	public void setContainRetake(int containRetake) {
		this.containRetake = containRetake;
	}
	public int getTcCapacity() {
		return tcCapacity;
	}
	public void setTcCapacity(int tcCapacity) {
		this.tcCapacity = tcCapacity;
	}
	
	@ManyToOne
	@JoinColumn(name = "courseId")
	public Courses getCourse() {
		return course;
	}
	public void setCourse(Courses course) {
		this.course = course;
	}
	
	@ManyToOne
	@JoinColumn(name = "crId")
	public Classroom getClassroom() {
		return classroom;
	}
	public void setClassroom(Classroom classroom) {
		this.classroom = classroom;
	}
	
	@ManyToOne
	@JoinColumn(name = "tsId")
	public TeachingSchedule getTeachingSchedule() {
		return teachingSchedule;
	}
	public void setTeachingSchedule(TeachingSchedule teachingSchedule) {
		this.teachingSchedule = teachingSchedule;
	}
	

}
