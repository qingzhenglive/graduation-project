package com.graduate.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "changeCourseApplication")
public class ChangeCourseApplication {

	private int ccaId;
	private int courseId;
	private int tcId;        //教学班号  teachingClassId
	private String appTime;  // 申请时间
	private Teacher teacher;

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int getCcaId() {
		return ccaId;
	}

	public void setCcaId(int ccaId) {
		this.ccaId = ccaId;
	}

	public int getCourseId() {
		return courseId;
	}

	public void setCourseId(int courseId) {
		this.courseId = courseId;
	}

	public int getTcId() {
		return tcId;
	}

	public void setTcId(int tcId) {
		this.tcId = tcId;
	}

	public String getAppTime() {
		return appTime;
	}

	public void setAppTime(String appTime) {
		this.appTime = appTime;
	}

	
	@ManyToOne
	@JoinColumn(name = "teacherId")
	public Teacher getTeacher() {
		return teacher;
	}

	public void setTeacher(Teacher teacher) {
		this.teacher = teacher;
	}

	@Override
	public String toString() {
		return "ChangeCourseApplication [ccaId=" + ccaId + ", courseId=" + courseId + ", tcId=" + tcId + ", appTime="
				+ appTime + ", teacher=" + teacher + "]";
	}

	


}
