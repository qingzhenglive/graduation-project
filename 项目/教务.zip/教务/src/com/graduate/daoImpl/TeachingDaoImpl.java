package com.graduate.daoImpl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.stereotype.Repository;

import com.graduate.bean.Recruit;
import com.graduate.bean.Teaching;
import com.graduate.dao.TeachingDao;
@Repository
public class TeachingDaoImpl  extends BaseDaoImpl implements TeachingDao {

	
	//	查询所有的的招募信息
	 public List<Teaching> getAllTeaching() {
		 String hql="from Teaching";
		 List<Teaching> list = getSession().createQuery(hql).list();
		return list;
		
	}

	 //分页查询所有的视频信息
	@Override
	public List<Teaching> getAllTeachingByPage(int currentPage, int sum) {
		Session session=getSession();
		String hql="from Teaching";
		Query query=session.createQuery(hql);
		query.setFirstResult((currentPage-1)*sum);
		query.setMaxResults(sum);
		List <Teaching>list = query.list();
		return list;
	}

	@Override
	public List<Teaching> getPartAttributeTeachingByPage(int currentPage, int sum) {
		Session session=getSession();
		String hql="select new Teaching(T.id,T.name,T.watcher,T.describe,T.images) from Teaching T";
		Query query=session.createQuery(hql);
		query.setFirstResult((currentPage-1)*sum);
		query.setMaxResults(sum);
		List <Teaching>list = query.list();
		return list;
	}

	@Override
	public Teaching getTeachingById(int teachingId) {
		Session session=getSession();
		String hql="from Teaching t where t.id=?";
		Query query=session.createQuery(hql);
		query.setParameter(0, teachingId);
		Teaching  T = (Teaching) query.uniqueResult();
		return T;
	}

	@Override
	public void saveTeaching(Teaching teaching) {
		Session session=getSession();
		session.save(teaching);
		
	}
}
