package com.graduate.daoImpl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.stereotype.Repository;

import com.graduate.bean.Comment;
import com.graduate.bean.Recruit;
import com.graduate.dao.CommentDao;
@Repository
public class CommentDaoImpl extends BaseDaoImpl implements CommentDao  {


	//	根据课堂的Id获得分页的评论
	@Override
	public List<Comment> getPageCommentByTeachingId(int id, int currentPage, int sum) {
		Session session=getSession();
		String hql="from Comment c where c.teaching.id=?";
		Query query=session.createQuery(hql);
		query.setParameter(0, id);
		query.setFirstResult((currentPage-1)*sum);
		query.setMaxResults(sum);
		List <Comment>list = query.list();
		return list;
	}

	@Override
	public void InsertComment(Comment comment) {
		Session session=getSession();
		session.save(comment);
		
	}
}
