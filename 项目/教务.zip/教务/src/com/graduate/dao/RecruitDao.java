package com.graduate.dao;

import java.util.List;

import com.graduate.bean.Recruit;

public interface RecruitDao {

	//查询所有的的招募信息
	 List<Recruit> getAllRecruit();
	 //根据地区查询招募信息
	 List<Recruit> getAllRecruitBySite(String site);
	 //根据类别查询招募信息
	 List<Recruit> getRecruitByClassify(String classify);
	//根据分页查询招募信息
	 List<Recruit> getRecruitByPage(int currentpage, int sum);
	 //根据RecruitId获得招募详情
	 Recruit getRecruitByRecruitId(int id);
	//查询部分属性的招募信息
	 List <Recruit> getRecruitPartAttribute();
	 //根据公司名字查询
	 List<Recruit> getRecruitByCompany(String name,int currentpage,int sum);
	
}
