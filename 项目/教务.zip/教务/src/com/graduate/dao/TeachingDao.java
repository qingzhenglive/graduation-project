package com.graduate.dao;

import java.util.List;

import com.graduate.bean.Recruit;
import com.graduate.bean.Teaching;

public interface TeachingDao {

	//	查询所有的的招募信息
	 List<Teaching> getAllTeaching();
	//	分页查询所有的视频信息
	 List<Teaching> getAllTeachingByPage(int currentpage, int sum);
	 //分页查询部分课堂属性
	 List<Teaching> getPartAttributeTeachingByPage(int currentPage,int sum);
	 //根据Id查询课堂
	 Teaching  getTeachingById(int teachingId);
	 //根据Id查询课堂
	 void  saveTeaching(Teaching teaching);
}
