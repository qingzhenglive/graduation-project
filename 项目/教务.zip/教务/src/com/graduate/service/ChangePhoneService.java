package com.graduate.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.graduate.dao.ChangePhoneDao;


@Service
@Transactional(readOnly = false)
public class ChangePhoneService {

	@Autowired
	private ChangePhoneDao changePhoneDao;
	
	/*
	 * 调用更新联系方式的方法
	 */
	public void changePhone(String snum,String phone) {
		changePhoneDao.update(snum, phone);
	}
	
	/*
	 * 调用返回用户名的方法
	 */
	public String selectPswBySnum(String snum) {
		return changePhoneDao.select(snum);
	}
	/*
	 * 调用更新密码的方法
	 */
	public void changePsw(String snum,String psw) {
		changePhoneDao.updatePsw(snum, psw);
	}
	

	
}
