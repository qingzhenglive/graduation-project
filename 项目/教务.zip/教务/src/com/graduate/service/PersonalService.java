package com.graduate.service;

import java.util.List;

import com.graduate.bean.Job;
import com.graduate.bean.Recruit;
import com.graduate.bean.Undergraduate;

public interface PersonalService {

	 //按年份查询工作的毕业生
	 List<Job> getAllJobPeopleByYear(String year);
	 //按年份查询考研的毕业生
	 List<Undergraduate> getAllUnderGratuatePeopleByYear(String year);
}

