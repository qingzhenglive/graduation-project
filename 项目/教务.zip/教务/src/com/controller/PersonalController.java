package com.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.graduate.bean.Job;
import com.graduate.bean.Recruit;
import com.graduate.bean.Undergraduate;
import com.graduate.dao.PersonalDao;
import com.graduate.service.PersonalService;
@Controller
public class PersonalController{

	@Autowired
	private PersonalService personalService;

	
	@RequestMapping("/getAllPeopleByYear")
	public ModelAndView getAllPeopleByYear(HttpServletRequest request) {
		String year = request.getParameter("year");
		String year2 = request.getParameter("year2");
		ModelAndView modelAndView=new ModelAndView();
		
			List<Job> list = personalService.getAllJobPeopleByYear(year);
			modelAndView.addObject("PeopleByYear", list);
			modelAndView.addObject("year", year);
			modelAndView.addObject("one", "姓名");
			modelAndView.addObject("two", "工作单位");
			modelAndView.addObject("three","工作岗位");
			modelAndView.addObject("four", "薪      资");
			modelAndView.setViewName("/workTable.jsp");
			return modelAndView;
	}
	
	@RequestMapping("/getAllUndergraduateByYear")
	public ModelAndView getAllUndergraduateByYear(HttpServletRequest request) {
		    String year = request.getParameter("year");
			List<Undergraduate> list = personalService.getAllUnderGratuatePeopleByYear(year);
			ModelAndView modelAndView=new ModelAndView();
			modelAndView.addObject("PeopleByYear", list);
			modelAndView.addObject("one", "序      号");
			modelAndView.addObject("two", "姓      名");
			modelAndView.addObject("three","年      级");
			modelAndView.addObject("four", "录取学校");
			modelAndView.addObject("year", year);
			modelAndView.setViewName("/undergraduateTable.jsp");
			return modelAndView;
	
	}
}
