package com.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.graduate.service.ChangePhoneService;



@Controller
public class ChangePswController {

	@Autowired
	private ChangePhoneService changePhoneService;
	//同时包含字母和数字
	private static String LETTER_DIGIT_REGEX="^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{8}$";
	
	/*
	 * 判断字符串中是否同时包含字母和数字
	 */
	public static boolean isLetterDigit(String str) {
		return str.matches(LETTER_DIGIT_REGEX);
	}
	/*
	 * 判断原密码是否正确
	 */
//	@RequestMapping("/checkPsw")
//	public void checkPsw(HttpServletRequest request,HttpServletResponse response,@RequestParam("password")String password,HttpSession session) throws IOException {
//		//Student student=(Student) session.getAttribute("user");
//		System.out.println("原密码"+password);
//		//String snum=student.getSnum();
//		String psw=changePhoneService.selectPswBySnum(snum);
//		PrintWriter out=response.getWriter();
//		if(psw.equals(password)) {
//			out.print(true);
//		}else {
//			out.print(false);
//		}
//	}
	
	/*
	 * 判断新密码是否符合要求
	 */
	@RequestMapping("/according")
	public void accordingWith(HttpServletResponse response,@RequestParam("password")String password) throws IOException {
		PrintWriter out=response.getWriter();
		System.out.println("一次");
		System.out.println(password);
		if(isLetterDigit(password)==true) {
			out.print(true);
		}else {
			out.print(false);
		}
	}
	
	/*
	 * 判断两次输入新密码不一致
	 */
	@RequestMapping("/affirm")
	public void newPswIsAccording(HttpServletResponse response,@RequestParam(value="password",required=false)String password,@RequestParam(value="newpassword",required=false)String newpsw) throws IOException {
		PrintWriter out=response.getWriter();
		System.out.println("两次");
		System.out.println(password);
		System.out.println(newpsw);
		if(password.equals(newpsw)) {
			out.print(true);
		}else {
			out.print(false);
		}
	}
	
	/*
	 * 更新数据库的密码
	 
	@RequestMapping("/updatePsw")
	public String changePsw(@RequestParam("password")String psw,@RequestParam("newpsw")String password,@RequestParam("newpassword")String newpsw,HttpServletRequest request) {
		Student student=(Student) request.getSession().getAttribute("user");
		String snum=student.getSnum();
		if(password!=null&&password.equals(newpsw)) {
			changePhoneService.changePsw(snum, password);
			return "personal";
		}else {
			request.setAttribute("psw", psw);//原密码
			request.setAttribute("newpsw", password);//新密码
			request.setAttribute("newpassword", newpsw);//第二次输入新密码
			request.setAttribute("msg", "密码不一致");
			return "changepsw";
		}
		
	}*/
}



