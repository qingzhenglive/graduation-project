package com.controller;

import java.util.List;

import org.springframework.stereotype.Controller;

import com.graduate.bean.Company;
import com.graduate.bean.Recruit;
import com.graduate.dao.CompanyDao;
@Controller
public class CompanyController{

	//根据用户Id获得公司
	public List<Company> getCompanyByPeopleId(int id){
		String hql="from Job";
		
		return null;
		
	}
}
