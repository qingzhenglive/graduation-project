   // JS实现选项卡切换
    window.onload = function(){
    
    var myUl = document.getElementById("tabv");//一个节点
    var myLi = myUl.getElementsByTagName("div");    //数组
    var myDiv = document.getElementsByClassName("showdiv")[0].children; //数组

     myLi[0].className="on";
      myDiv[0].className = "show";
    for(var i = 0; i<myLi.length;i++){
        myLi[i].index = i;
        myLi[i].onclick = function(){
            for(var j = 0; j < myLi.length; j++){
                myLi[j].className="off";
                myDiv[j].className = "hide";
            }
            this.className = "on";
            myDiv[this.index].className = "show";
            console.log(i);
        }
      }
    }