package com.teacher.service;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bean.TeacherTimetable;
import com.bean.TeachingClass;
import com.teacher.dao.TeacherTimetableDaoImpl;

@Service
@Transactional
public class TeacherTimetableServiceImpl {

	@Resource
	private TeacherTimetableDaoImpl teacherTimetableDaoImpl;
	
	
	
	// 找到老师所有的上课单元。
	public List<TeacherTimetable> listTimetablesByTeacherId(String tId,String year, int term){
		
		return teacherTimetableDaoImpl.findTimetablesByTeacherId(tId, year, term);
	}
	
	
	// 调课申请页面分页查找 可以调整的课 
	public List<TeacherTimetable> listTimetablesByPageAndTeacherId(int pageNo, int pageSize, String tId){
		
		return teacherTimetableDaoImpl.findTimetablesByPageAndTeacherId(pageNo, pageSize, tId);
	}
	
	public int countTimetablesByPageAndTeacherId(String tId) throws Exception {
		
		return teacherTimetableDaoImpl.findCountTimetablesByPageAndTeacherId(tId);
	}
	
	// w
	public List<TeacherTimetable> listTimetablesByPageAndTeacherIdAndConstraints(int pageNo, int pageSize, String tId, int week){
		
		if(week == 0) return teacherTimetableDaoImpl.findTimetablesByPageAndTeacherId(pageNo, pageSize, tId);
		else return teacherTimetableDaoImpl.findTimetablesByPageAndTeacherIdAndWeek(pageNo, pageSize, tId, week);
	}

	public int countTimetablesByeTacherIdAndConstrains(String tId, int week) throws Exception{
		
		if(week == 0) return teacherTimetableDaoImpl.findCountTimetablesByPageAndTeacherId(tId);
		else return teacherTimetableDaoImpl.findCountTimetablesByTeacherIdAndWeek(tId, week);
	}
	
	public TeacherTimetable uniTeacherTimetableById(int ttId) {
		return teacherTimetableDaoImpl.findTeacherTimetableById(ttId);
	}
	
}
