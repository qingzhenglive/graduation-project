package com.teacher.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bean.Courses;
import com.bean.TeachingClass;
import com.teacher.dao.TeachingClassDaoImpl;

@Service
@Transactional
public class TeachingClassServiceImpl {

	@Resource
	private TeachingClassDaoImpl teachingClassDaoImpl;
	
	public List<Courses> listTaughtCoursesByTeacherId(String tId){
		return teachingClassDaoImpl.findTaughtCoursesByTeacherId(tId);
	}
	
	public List<Courses> listTaughtCoursesByPageAndTeacherIdAndConstraints(int pageNo, int pageSize, String tId,String year, int term) {
		List<Courses> courses;
		if (year.equals("default") && term == 0) {
			courses = teachingClassDaoImpl.findTaughtCoursesByPageAndTeacherId(pageNo, pageSize, tId);
		} else if (year.equals("default") && term != 0) {
			courses = teachingClassDaoImpl.findTaughtCoursesByPageAndTeacherIdAndTerm(pageNo, pageSize, tId, term);
		} else if (!year.equals("default") && term == 0) {
			courses = teachingClassDaoImpl.findTaughtCoursesByPageAndTeacherIdAndYear(pageNo, pageSize, tId, year);
		} else {
			courses = teachingClassDaoImpl.findTaughtCoursesByPageAndTeacherIdAndYearAndTerm(pageNo, pageSize, tId, year, term);
		}
		return courses;
	
	}

	public int countTaughtCoursesByTeacherIdAndConstraints(String tId, String year, int term) throws Exception {

		int rtn = 0;
		if (year.equals("default") && term == 0) {
			rtn = teachingClassDaoImpl.findCountTaughtCoursesById(tId);
		} else if (year.equals("default") && term != 0) {
			rtn = teachingClassDaoImpl.findCountCoursesByTeacherIdAndTerm(tId, term);
		} else if (!year.equals("default") && term == 0) {
			rtn = teachingClassDaoImpl.findCountTaughtCoursesByTeacherIdAndYear(tId, year);
		} else {
			rtn = teachingClassDaoImpl.findCountTaughtCoursesByTeacherIdAndYearAndTerm(tId, year, term);
		}
		return rtn;

	}
	
	
	// year 和 term 不会为空, 没有意义  if courseId 是0  则表示全部
	public List<TeachingClass> listTeachingClassesByPageAndTeacherIdAndConstraints(int pageNo, int pageSize, String tId,String year, int term,
			int courseId) {
		List<TeachingClass> teachingClasses;
		if(courseId == 0) {
			teachingClasses = teachingClassDaoImpl.findTeachingClassesByPageAndTeacherId(pageNo, pageSize, tId, year, term);
		} else teachingClasses = teachingClassDaoImpl.findTeachingClassesByPageAndTeacherIdAndCourse(pageNo, pageSize, tId, year, term, courseId);
		return teachingClasses;
	}
	
	public int countTeachingClassesByPageAndTeacherIdAndConstraints(String tId,String year, int term,
			int courseId) throws Exception {
		int rtn;
		if(courseId == 0) {
			rtn = teachingClassDaoImpl.findCountTeachingClassesByTeacherId(tId, year, term);
		} else rtn = teachingClassDaoImpl.findCountTeachingClassesByTeacherIdAndCourse(tId, year, term, courseId);
		
		return rtn;
		
	}
	
	
	public TeachingClass uniTeachingClassById(int id) {
		return teachingClassDaoImpl.findTeachingClassById(id);
	}
	
	public void inputTeacingClassFinishById(int tcId) {
		teachingClassDaoImpl.updateTeachingClassInputtedFinishById(tcId);
	}
	
	
	// 找到教师 所有的教学班 ， 在TimeTabeDao里会有处理
	public List<TeachingClass> listTeachingClassesByTeacherId(String tId,String year, int term){
		return teachingClassDaoImpl.findTeachingClassesByTeacherId(tId, year, term);
	}
}
