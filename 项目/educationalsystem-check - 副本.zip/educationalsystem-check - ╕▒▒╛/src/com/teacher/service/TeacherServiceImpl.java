package com.teacher.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bean.Teacher;
import com.teacher.dao.TeacherDaoImpl;

@Service
@Transactional
public class TeacherServiceImpl {   // 单个对象用uni

	@Resource
	private TeacherDaoImpl teacherDaoImpl;
	
	public Teacher uniTeacherById(String id) {
		return teacherDaoImpl.findTeacherById(id);
	}
	
	public void changeTeacherBasicInfo(Teacher teacher) {
		teacherDaoImpl.updateTeacher(teacher);
	}
	
	public List<Teacher> listTeachersByInstitute(String institute){
		
		return teacherDaoImpl.findTeachersByInstitute(institute);
	}
}
