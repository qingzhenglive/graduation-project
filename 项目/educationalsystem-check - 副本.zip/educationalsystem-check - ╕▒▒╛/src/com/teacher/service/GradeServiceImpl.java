package com.teacher.service;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bean.Grade;
import com.bean.Student;
import com.bean.TeachingClass;
import com.teacher.dao.GradeDaoImpl;

@Service
@Transactional
public class GradeServiceImpl {


	@Resource
	private GradeDaoImpl gradeDaoImpl;
	public List<Grade> listGradesByStudentsAndTeachingClass(List<Student> students, int tcId) throws Exception {
		return gradeDaoImpl.findGradesByStudentsAndTeachingClass(students, tcId);
	}
	
	public float calculateAvgScoreByTeachingClass(int tcId) throws Exception {
		
		float sum = 0;
		List<Grade> grades = gradeDaoImpl.findGradesByTeachingClass(tcId);
		
		for(Grade g : grades) {
			sum += g.getScore();
		}
		int cnt = gradeDaoImpl.findCountGradesByTeachingClass(tcId);
		
		return sum / cnt;
	}
	
	public float calculatePassRateByTeachingClass(int tcId) {
		
		List<Grade> grades = gradeDaoImpl.findGradesByTeachingClass(tcId);
		float passedG = 0;
		float unPassedG = 0;
		for(Grade g : grades) {
			if(g.getScore() >= 60) passedG ++;
			else unPassedG ++;
		}
		return passedG / (passedG + unPassedG);
	}
	
	public List<float[]> calculatePassRateAndAvgScoreByTeachingClasses(List<TeachingClass> teachingClasses) throws Exception {
		List<float[]> passRateAndAvgScores = new ArrayList<>();
		for(TeachingClass tc:teachingClasses) {
			float[] rateAndAvg = {calculatePassRateByTeachingClass(tc.getTcId()), calculateAvgScoreByTeachingClass(tc.getTcId())};
			passRateAndAvgScores.add(rateAndAvg);
		}
		return passRateAndAvgScores;
	}
	
	public void saveGrade(Grade g) {
		gradeDaoImpl.insertGrade(g);
	}
	
	
}
