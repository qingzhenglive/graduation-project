package com.teacher.service;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bean.ChangeCourseApplication;
import com.teacher.dao.ChangeCourseApplicationDaoImpl;

@Service
@Transactional
public class ChangeCourseApplicationServiceImpl {

	@Resource
	private ChangeCourseApplicationDaoImpl changeCourseApplicationDaoImpl;
	
	public void saveChangeCourseApplication(ChangeCourseApplication c) {
		changeCourseApplicationDaoImpl.insertChangeCourseApplication(c);
	}
}
