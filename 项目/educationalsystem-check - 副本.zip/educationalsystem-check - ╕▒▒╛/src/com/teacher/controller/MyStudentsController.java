package com.teacher.controller;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.bean.Courses;
import com.bean.Student;
import com.bean.Teacher;
import com.bean.TeachingClass;
import com.teacher.service.StudentServiceImpl;
import com.teacher.service.TeachingClassServiceImpl;
import com.teacher.util.Page;

@Controller
public class MyStudentsController {

	
	@Resource
	private TeachingClassServiceImpl teachingClassServiceImpl;
	
	@Resource
	private StudentServiceImpl studentServiceImpl;
	
	@RequestMapping("/preStudentsProfile")  // 第一次进入到 teachingClasses
	public String preMyTeachingClasses(HttpServletRequest request, HttpSession session) throws Exception {
		
		// 获取 teacher
		Teacher teacher = (Teacher) session.getAttribute("user"); 
		String tId = teacher.gettId();
		
		// 设置当前学期和时间 (第一次进入默认)  此处应该获得系统时间判断year 和 学期
		String year = "2016-2017"; 
		int term = 1;
		int pageNo = 1;
		int courseId = 0;  // 默认是全部课程
		
		// 调用 serviceImpl 查询当前年份和学习的所有课程的教学班
		List<TeachingClass> teachingClasses = teachingClassServiceImpl.listTeachingClassesByPageAndTeacherIdAndConstraints(pageNo, Page.PageSize, tId, year, term, courseId);
		int totalCount = teachingClassServiceImpl.countTeachingClassesByPageAndTeacherIdAndConstraints(tId, year, term, courseId);
		Page<TeachingClass> page = new Page<TeachingClass>();
		page.setPageNum(pageNo);
		page.setList(teachingClasses);
		page.setPageSize(Page.PageSize);
		page.setTotalCount(totalCount);

		request.setAttribute("page", page);
		request.setAttribute("pageNum", pageNo); // 有什么用
		
		List<Courses> allCourses = teachingClassServiceImpl.listTaughtCoursesByTeacherId(tId);
		session.setAttribute("allCourses", allCourses);
		
		// 设置默认
		request.setAttribute("defaultSelectedYear", year);
		request.setAttribute("defaultSelectedTerm", term);
		request.setAttribute("defaultSelectedcourseId", courseId);
		request.setAttribute("firstPageNum", (pageNo - 1) / 5 * 5 + 1);
		
		return "ii-studentList-profile";
	}
	
	@RequestMapping("/selectStudentsProfile")  // 点击查找按钮 
	public String selectMyTeachingClasses(HttpServletRequest request, HttpSession session) throws Exception {
		
		// 获取 teacher
		Teacher teacher = (Teacher) session.getAttribute("user"); 
		String tId = teacher.gettId();
		
		// 设置当前学期和时间
		String year = request.getParameter("year");
		System.out.println("获得的term:" + request.getParameter("term"));
		int term = Integer.parseInt(request.getParameter("term"));
		int pageNo = 1;
		int courseId = Integer.parseInt(request.getParameter("courseId"));  // 默认是全部课程
		
		// 调用 serviceImpl 查询当前年份和学习的所有课程的教学班
		List<TeachingClass> teachingClasses = teachingClassServiceImpl.listTeachingClassesByPageAndTeacherIdAndConstraints(pageNo, Page.PageSize, tId, year, term, courseId);
		int totalCount = teachingClassServiceImpl.countTeachingClassesByPageAndTeacherIdAndConstraints(tId, year, term, courseId);
		Page<TeachingClass> page = new Page<TeachingClass>();
		page.setPageNum(pageNo);
		page.setList(teachingClasses);
		page.setPageSize(Page.PageSize);
		page.setTotalCount(totalCount);

		request.setAttribute("page", page);
		request.setAttribute("pageNum", pageNo);
		
		// 表单回显
		request.setAttribute("defaultSelectedYear", year);
		request.setAttribute("defaultSelectedTerm", term);
		request.setAttribute("defaultSelectedcourseId", courseId);
		request.setAttribute("firstPageNum", (pageNo - 1) / 5 * 5 + 1);
		return "ii-studentList-profile";
	}
	
	@RequestMapping("/jumpStudentsProfile")  // 点击上一页，下一页，或者某个具体的页 
	public String jumpMyTeachingClasses(HttpServletRequest request, HttpSession session) throws Exception {
		
		// 获取 teacher
		Teacher teacher = (Teacher) session.getAttribute("user"); 
		String tId = teacher.gettId();
		
		// 设置当前学期和时间
		String year = request.getParameter("year");
		int term = Integer.parseInt(request.getParameter("term"));
		int pageNo = Integer.parseInt(request.getParameter("pageNum"));
		int courseId = Integer.parseInt(request.getParameter("courseId"));  // 默认是全部课程
		
		// 调用 serviceImpl 查询当前年份和学习的所有课程的教学班
		List<TeachingClass> teachingClasses = teachingClassServiceImpl.listTeachingClassesByPageAndTeacherIdAndConstraints(pageNo, Page.PageSize, tId, year, term, courseId);
		int totalCount = teachingClassServiceImpl.countTeachingClassesByPageAndTeacherIdAndConstraints(tId, year, term, courseId);
		Page<TeachingClass> page = new Page<TeachingClass>();
		page.setPageNum(pageNo);
		page.setList(teachingClasses);
		page.setPageSize(Page.PageSize);
		page.setTotalCount(totalCount);

		request.setAttribute("page", page);
		request.setAttribute("pageNum", pageNo);
		
		// 表单回显
		request.setAttribute("defaultSelectedYear", year);
		request.setAttribute("defaultSelectedTerm", term);
		request.setAttribute("defaultSelectedcourseId", courseId);
		request.setAttribute("firstPageNum", (pageNo - 1) / 5 * 5 + 1);
		return "ii-studentList-profile";
	}
	
	
	
	
	@RequestMapping("/viewStudents")   // 此页面为固定的展示页面，不需要查找
	public String viewTeachingClasses(HttpServletRequest request, HttpSession session) throws Exception {
		
		
		// 获得 teachingClass 
		int tcId = Integer.parseInt(request.getParameter("tcId"));
		TeachingClass teachingClass = teachingClassServiceImpl.uniTeachingClassById(tcId);
		String year = teachingClass.getTeachingSchedule().gettYear();
		int term = teachingClass.getCourse().getCterm();
		
		
		
		int pageNo = 1;
	
		
		
		// 调用 serviceImpl 查询当前教学班的所有的学生
		List<Student> students = studentServiceImpl.listStudentsByPageAndTeachingClass(pageNo, Page.PageSize, tcId);
		int totalCount = studentServiceImpl.countStudentsByTeachingClass(tcId);
				
		Page<Student> page = new Page<Student>();
		page.setPageNum(pageNo);
		page.setList(students);
		page.setPageSize(Page.PageSize);
		page.setTotalCount(totalCount);

		request.setAttribute("page", page);
		request.setAttribute("pageNum", pageNo); // 有什么用
		
//		List<Courses> allCourses = teachingClassServiceImpl.listTaughtCoursesByTeacherId(tId);
//		session.setAttribute("allCourses", allCourses);
		
		// 设置默认
		request.setAttribute("defaultSelectedYear", year);
		request.setAttribute("defaultSelectedTerm", term);
		request.setAttribute("defaultSelectedTeachingClass", teachingClass);
		request.setAttribute("tcId", tcId);
		request.setAttribute("firstPageNum", (pageNo - 1) / 5 * 5 + 1);
		
		return "ii-studentList";
	}
	
	@RequestMapping("/jumpStudentsPage")
	public String jumpStudentsPage(HttpServletRequest request, HttpSession session) throws Exception {
		// 获取 teacher
		Teacher teacher = (Teacher) session.getAttribute("user"); 
		String tId = teacher.gettId();
		
		// 获得 teachingClass 
		int tcId = Integer.parseInt(request.getParameter("tcId"));
		TeachingClass teachingClass = teachingClassServiceImpl.uniTeachingClassById(tcId);
		String year = teachingClass.getTeachingSchedule().gettYear();
		int term = teachingClass.getCourse().getCterm();
		
		
		// 获得pageNum
		int pageNo = Integer.parseInt(request.getParameter("pageNum"));
	
		
		
		// 调用 serviceImpl 查询当前教学班的所有的学生
		List<Student> students = studentServiceImpl.listStudentsByPageAndTeachingClass(pageNo, Page.PageSize, tcId);
		int totalCount = studentServiceImpl.countStudentsByTeachingClass(tcId);
				
		Page<Student> page = new Page<Student>();
		page.setPageNum(pageNo);
		page.setList(students);
		page.setPageSize(Page.PageSize);
		page.setTotalCount(totalCount);

		request.setAttribute("page", page);
		request.setAttribute("pageNum", pageNo); // 有什么用
		
		List<Courses> allCourses = teachingClassServiceImpl.listTaughtCoursesByTeacherId(tId);
		session.setAttribute("allCourses", allCourses);
		
		// 设置默认
		request.setAttribute("defaultSelectedYear", year);
		request.setAttribute("defaultSelectedTerm", term);
		request.setAttribute("defaultSelectedTeachingClass", teachingClass);
		request.setAttribute("tcId", tcId);
		request.setAttribute("firstPageNum", (pageNo - 1) / 5 * 5 + 1);
		
		return "ii-studentList";
	}
}
