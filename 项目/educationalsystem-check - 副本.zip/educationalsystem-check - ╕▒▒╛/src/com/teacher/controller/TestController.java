package com.teacher.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class TestController {

	@RequestMapping("/test")
	public void test(HttpServletRequest request) {
		
		for(int pageNum = 1; pageNum <= 20; ++pageNum) {
			int p = (pageNum - 1) / 5 * 5 + 1;
			System.out.println("pageNum = " + pageNum + " 应该在第 " + p + " 页");
		}
	}
}
