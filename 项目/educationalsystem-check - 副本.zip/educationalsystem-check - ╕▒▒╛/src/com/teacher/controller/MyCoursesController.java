package com.teacher.controller;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.bean.Courses;
import com.bean.Student;
import com.bean.Teacher;
import com.bean.TeachingClass;
import com.teacher.service.TeacherServiceImpl;
import com.teacher.service.TeachingClassServiceImpl;
import com.teacher.util.Page;

@Controller
public class MyCoursesController {

	
	@Resource
	private TeacherServiceImpl teacherServiceImpl;
	
	@Resource
	private TeachingClassServiceImpl teachingClassServiceImpl;
	
	
	@RequestMapping("/preMyCourses") // 第一次进入Mycourses
	public String preMyCourses(HttpServletRequest request, HttpSession session) throws Exception {
		Teacher teacher = (Teacher) session.getAttribute("user");
		String tId = teacher.gettId();
		int pageNo = 1;
		String year = "default";
		int term = 0;
		List<Courses> courses = teachingClassServiceImpl.listTaughtCoursesByPageAndTeacherIdAndConstraints(1, Page.PageSize, tId, year, term);
		int totalCount = teachingClassServiceImpl.countTaughtCoursesByTeacherIdAndConstraints(tId, year, term);
		
		Page<Courses> page = new Page<Courses>();
		page.setList(courses);
		page.setPageNum(pageNo);
		page.setPageSize(Page.PageSize);
		page.setTotalCount(totalCount);

		request.setAttribute("page", page);
		request.setAttribute("pageNum", pageNo);

		request.setAttribute("defaultSelectedYear", year);
		request.setAttribute("defaultSelectedTerm", term);
		request.setAttribute("firstPageNum", (pageNo - 1) / 5 * 5 + 1);
		
		return "ii-myCourses";
	}
	
	@RequestMapping("/selectMyCourses")
	public String selectMyCourses(HttpServletRequest request, HttpSession session) throws Exception {
		Teacher teacher = (Teacher) session.getAttribute("user");
		String tId = teacher.gettId();
		int pageNo = 1;
		String year = request.getParameter("year");
		int term = Integer.parseInt(request.getParameter("term"));
		
		List<Courses> courses = teachingClassServiceImpl.listTaughtCoursesByPageAndTeacherIdAndConstraints(1, Page.PageSize, tId, year, term);
		int totalCount = teachingClassServiceImpl.countTaughtCoursesByTeacherIdAndConstraints(tId, year, term);
		
		Page<Courses> page = new Page<Courses>();
		page.setList(courses);
		page.setPageNum(pageNo);
		page.setPageSize(Page.PageSize);
		page.setTotalCount(totalCount);

		request.setAttribute("page", page);
		request.setAttribute("pageNum", pageNo);

		request.setAttribute("defaultSelectedYear", year);
		request.setAttribute("defaultSelectedTerm", term);
		request.setAttribute("firstPageNum", (pageNo - 1) / 5 * 5 + 1);
		
		return "ii-myCourses";
	}
	
	@RequestMapping("/jumpMyCoursesPage")
	public String jumpMyCoursesPage(HttpServletRequest request, HttpSession session) throws Exception {
		// 获取 teacher
		Teacher teacher = (Teacher) session.getAttribute("user"); 
		String tId = teacher.gettId();
		
		// 获得默认参数
		String year = request.getParameter("year");
		int term = Integer.parseInt(request.getParameter("term"));
		int pageNo = Integer.parseInt(request.getParameter("pageNum"));
	
		
		
		List<Courses> courses = teachingClassServiceImpl.listTaughtCoursesByPageAndTeacherIdAndConstraints(pageNo, Page.PageSize, tId, year, term);
		int totalCount = teachingClassServiceImpl.countTaughtCoursesByTeacherIdAndConstraints(tId, year, term);
		
				
		Page<Courses> page = new Page<Courses>();
		page.setPageNum(pageNo);
		page.setList(courses);
		page.setPageSize(Page.PageSize);
		page.setTotalCount(totalCount);

		request.setAttribute("page", page);
		request.setAttribute("pageNum", pageNo); // 有什么用
		
		
		// 设置默认
		request.setAttribute("defaultSelectedYear", year);
		request.setAttribute("defaultSelectedTerm", term);
		request.setAttribute("firstPageNum", (pageNo - 1) / 5 * 5 + 1);
		return "ii-myCourses";
	}
	
}
