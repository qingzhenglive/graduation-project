package com.teacher.controller;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.bean.Courses;
import com.bean.ResultProportion;
import com.bean.Teacher;
import com.teacher.service.ResultProportionServiceImpl;
import com.teacher.service.TeacherServiceImpl;
import com.teacher.service.TeachingClassServiceImpl;
import com.teacher.util.Page;

@Controller
public class ResultProportionController {

	@Resource
	private TeacherServiceImpl teacherServiceImpl;
	
	@Resource
	private TeachingClassServiceImpl teachingClassServiceImpl;
	
	@Resource
	private ResultProportionServiceImpl resultProportionServiceImpl;
	
	@RequestMapping("/preResultProportion") // 第一次进入
	public String preMyCourses(HttpServletRequest request, HttpSession session) throws Exception {
		Teacher teacher = (Teacher) session.getAttribute("user");
		String tId = teacher.gettId();
		int pageNo = 1;
		String year = "default";
		int term = 0;
		List<Courses> courses = teachingClassServiceImpl.listTaughtCoursesByPageAndTeacherIdAndConstraints(1, Page.PageSize, tId, year, term);
		int totalCount = teachingClassServiceImpl.countTaughtCoursesByTeacherIdAndConstraints(tId, year, term);
		
		Page<Courses> page = new Page<Courses>();
		page.setList(courses);
		page.setPageNum(pageNo);
		page.setPageSize(Page.PageSize);
		page.setTotalCount(totalCount);

		request.setAttribute("page", page);
		request.setAttribute("pageNum", pageNo);

		request.setAttribute("defaultSelectedYear", year);
		request.setAttribute("defaultSelectedTerm", term);
		request.setAttribute("firstPageNum", (pageNo - 1) / 5 * 5 + 1);
		return "ir-resultProportion";
	}
	
	@RequestMapping("/selectResultProportion")
	public String selectMyCourses(HttpServletRequest request, HttpSession session) throws Exception {
		Teacher teacher = (Teacher) session.getAttribute("user");
		String tId = teacher.gettId();
		int pageNo = 1;
		String year = request.getParameter("year");
		int term = Integer.parseInt(request.getParameter("term"));
		
		List<Courses> courses = teachingClassServiceImpl.listTaughtCoursesByPageAndTeacherIdAndConstraints(1, Page.PageSize, tId, year, term);
		int totalCount = teachingClassServiceImpl.countTaughtCoursesByTeacherIdAndConstraints(tId, year, term);
		
		Page<Courses> page = new Page<Courses>();
		page.setList(courses);
		page.setPageNum(pageNo);
		page.setPageSize(Page.PageSize);
		page.setTotalCount(totalCount);

		request.setAttribute("page", page);
		request.setAttribute("pageNum", pageNo);

		request.setAttribute("defaultSelectedYear", year);
		request.setAttribute("defaultSelectedTerm", term);
		request.setAttribute("firstPageNum", (pageNo - 1) / 5 * 5 + 1);
		
		return "ir-resultProportion";
	}
	
	@RequestMapping("/jumpResultProportion")
	public String jumpResultProportionPage(HttpServletRequest request, HttpSession session) throws Exception {
		// 获取 teacher
		Teacher teacher = (Teacher) session.getAttribute("user"); 
		String tId = teacher.gettId();
		
		// 获得默认参数
		String year = request.getParameter("year");
		int term = Integer.parseInt(request.getParameter("term"));
		int pageNo = Integer.parseInt(request.getParameter("pageNum"));
	
		
		
		List<Courses> courses = teachingClassServiceImpl.listTaughtCoursesByPageAndTeacherIdAndConstraints(pageNo, Page.PageSize, tId, year, term);
		int totalCount = teachingClassServiceImpl.countTaughtCoursesByTeacherIdAndConstraints(tId, year, term);
		
				
		Page<Courses> page = new Page<Courses>();
		page.setPageNum(pageNo);
		page.setList(courses);
		page.setPageSize(Page.PageSize);
		page.setTotalCount(totalCount);

		request.setAttribute("page", page);
		request.setAttribute("pageNum", pageNo); // 有什么用
		
		
		// 设置默认
		request.setAttribute("defaultSelectedYear", year);
		request.setAttribute("defaultSelectedTerm", term);
		request.setAttribute("firstPageNum", (pageNo - 1) / 5 * 5 + 1);
		
		return "ir-resultProportion";
	}
	
	@RequestMapping("/updateResultProportion")
	public String updateResultProportion(HttpServletRequest request, HttpSession session) throws Exception {
		String year = request.getParameter("year");
		int term = Integer.parseInt(request.getParameter("term"));
		int pageNo = Integer.parseInt(request.getParameter("pageNum"));
		
		Teacher teacher = (Teacher) session.getAttribute("user"); 
		String tId = teacher.gettId();
		
		

		List<Courses> courses = teachingClassServiceImpl.listTaughtCoursesByPageAndTeacherIdAndConstraints(pageNo, Page.PageSize, tId, year, term);
		int totalCount = teachingClassServiceImpl.countTaughtCoursesByTeacherIdAndConstraints(tId, year, term);
		
		Page<Courses> page = new Page<Courses>();
		page.setPageNum(pageNo);
		page.setList(courses);
		page.setPageSize(Page.PageSize);
		page.setTotalCount(totalCount);
		request.setAttribute("page", page);
		
		// 设置 resultProportion
		for(int i = 1; i <= 5; ++i) {
			String rpId = request.getParameter("rpId" + i);
			if(rpId != null) {  // 如果前台没有这个列表项，就是获得的就是 null，如果有但没有值就是"";
				ResultProportion resultProportion = resultProportionServiceImpl.uniResultProportionById(Integer.parseInt(rpId));
				String dailyProportion = request.getParameter("dailyProportion" + i);
				String midtermProportion = request.getParameter("midtermProportion" + i);
				String finalProportion = request.getParameter("finalProportion" + i);
				String expProportion = request.getParameter("expProportion" + i);
				String quizProportion = request.getParameter("quizProportion" + i);
				
				// 如果前台获得的是""， 就换成 0，虽然前端和数据库已经控制单仍可能出现bug
				resultProportion.setDailyProportion(dailyProportion == "" ? 0 : Integer.parseInt(dailyProportion));	
				resultProportion.setMidtermProportion(midtermProportion == "" ? 0 : Integer.parseInt(midtermProportion));	
				resultProportion.setFinalProportion(finalProportion == "" ? 0 : Integer.parseInt(finalProportion));	
				resultProportion.setExpProportion(expProportion == "" ? 0 : Integer.parseInt(expProportion));	
				resultProportion.setQuizProportion(quizProportion == "" ? 0 : Integer.parseInt(quizProportion));	
				resultProportionServiceImpl.changeResultProportion(resultProportion);
			} else break;
		}
		
		
		request.setAttribute("defaultSelectedYear", year);
		request.setAttribute("defaultSelectedTerm", term);
		request.setAttribute("pageNum", pageNo); 
		request.setAttribute("firstPageNum", (pageNo - 1) / 5 * 5 + 1);
		
		return "ir-resultProportion";
		
	}
}
