package com.teacher.controller;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.bean.ChangeCourseApplication;
import com.bean.Classroom;
import com.bean.Teacher;
import com.bean.TeacherTimetable;
import com.teacher.service.ChangeCourseApplicationServiceImpl;
import com.teacher.service.ClassRoomServiceImpl;
import com.teacher.service.CourseServiceImpl;
import com.teacher.service.TeacherServiceImpl;
import com.teacher.service.TeacherTimetableServiceImpl;
import com.teacher.service.TeachingClassServiceImpl;
import com.teacher.util.Page;

@Controller
public class ChangeCourseApplicationController {

	@Resource
	private TeachingClassServiceImpl teachingClassServiceImpl; 
	
	@Resource
	CourseServiceImpl courseServiceImpl;
	
	@Resource
	private TeacherTimetableServiceImpl teacherTimetableServiceImpl;
	
	@Resource
	private TeacherServiceImpl teacherServiceImpl;
	
	@Resource
	private ClassRoomServiceImpl classRoomServiceImpl;
	
	@Resource
	private ChangeCourseApplicationServiceImpl changeCourseApplicationServiceImpl; 
	
	@RequestMapping("/preChangeCourse")  // 第一次进入到 ChangeCourse
	public String preChangeCourse(HttpServletRequest request, HttpSession session) throws Exception {
		
		// 获取 teacher
		Teacher teacher = (Teacher) session.getAttribute("user"); 
		String tId = teacher.gettId();
		
		// 设置当前学期和时间 (第一次进入默认)  此处应该获得系统时间判断year 和 学期
		int week = 0; 
		int pageNo = 1;
		
		List<TeacherTimetable> willBeChangedTimetables = teacherTimetableServiceImpl.listTimetablesByPageAndTeacherIdAndConstraints(pageNo, Page.PageSize, tId, week);
		int totalCount = teacherTimetableServiceImpl.countTimetablesByeTacherIdAndConstrains(tId, week);
		
		Page<TeacherTimetable> page = new Page<TeacherTimetable>();
		page.setList(willBeChangedTimetables);
		page.setPageNum(pageNo);
		page.setPageSize(Page.PageSize);
		page.setTotalCount(totalCount);

		request.setAttribute("page", page);
		request.setAttribute("pageNum", pageNo);

		request.setAttribute("defaultSelectedWeek", week);
		request.setAttribute("firstPageNum", (pageNo - 1) / 5 * 5 + 1);
		
		
		return "changeCourseApplication";
	}
	
	@RequestMapping("/selectChangeCourse")  // 点击查找按钮 
	public String selectChangeCourse(HttpServletRequest request, HttpSession session) throws Exception {
		// 获取 teacher
		Teacher teacher = (Teacher) session.getAttribute("user"); 
		String tId = teacher.gettId();
		
		// 设置当前学期和时间 (第一次进入默认)  此处应该获得系统时间判断year 和 学期
		int week = Integer.parseInt(request.getParameter("week"));
		int pageNo = 1;
		
		List<TeacherTimetable> willBeChangedTimetables = teacherTimetableServiceImpl.listTimetablesByPageAndTeacherIdAndConstraints(pageNo, Page.PageSize, tId, week);
		int totalCount = teacherTimetableServiceImpl.countTimetablesByeTacherIdAndConstrains(tId, week);
		
		Page<TeacherTimetable> page = new Page<TeacherTimetable>();
		page.setList(willBeChangedTimetables);
		page.setPageNum(pageNo);
		page.setPageSize(Page.PageSize);
		page.setTotalCount(totalCount);

		request.setAttribute("page", page);
		request.setAttribute("pageNum", pageNo);

		request.setAttribute("defaultSelectedWeek", week);
		request.setAttribute("firstPageNum", (pageNo - 1) / 5 * 5 + 1);
		
		return "changeCourseApplication";
	}
	
	@RequestMapping("/jumpChangeCourse")  // 跳转页面
	public String jumpChangeCourse(HttpServletRequest request, HttpSession session) throws Exception {
		
		// 获取 teacher
		Teacher teacher = (Teacher) session.getAttribute("user"); 
		String tId = teacher.gettId();
		
		// 设置当前学期和时间 (第一次进入默认)  此处应该获得系统时间判断year 和 学期
		int week = Integer.parseInt(request.getParameter("week"));
		int pageNo = Integer.parseInt(request.getParameter("pageNum"));;
		
		List<TeacherTimetable> willBeChangedTimetables = teacherTimetableServiceImpl.listTimetablesByPageAndTeacherIdAndConstraints(pageNo, Page.PageSize, tId, week);
		int totalCount = teacherTimetableServiceImpl.countTimetablesByeTacherIdAndConstrains(tId, week);
		
		Page<TeacherTimetable> page = new Page<TeacherTimetable>();
		page.setList(willBeChangedTimetables);
		page.setPageNum(pageNo);
		page.setPageSize(Page.PageSize);
		page.setTotalCount(totalCount);

		request.setAttribute("page", page);
		request.setAttribute("pageNum", pageNo);

		request.setAttribute("defaultSelectedWeek", week);
		request.setAttribute("firstPageNum", (pageNo - 1) / 5 * 5 + 1);
		
		return "changeCourseApplication";
	}
	
	@RequestMapping("/changeCourseApplicationDetails")  // 跳转页面
	public String changeCourseApplicationDetails(HttpServletRequest request, HttpSession session) throws Exception {
		
		// 获取 teacher
		Teacher teacher = (Teacher) session.getAttribute("user"); 
		String tId = teacher.gettId();
		
		int ttId = Integer.parseInt(request.getParameter("ttId"));
		TeacherTimetable teacherTimetable = teacherTimetableServiceImpl.uniTeacherTimetableById(ttId);
		
		List<Teacher> teachers = teacherServiceImpl.listTeachersByInstitute("软件学院");
		List<Classroom>classRooms = classRoomServiceImpl.listAllClassRooms();

		
		request.setAttribute("ttId", ttId);
		request.setAttribute("teachers", teachers);
		request.setAttribute("classRooms", classRooms);
		request.setAttribute("teacherTimetable", teacherTimetable);
		
		
		return "changeCourseApplication-details";
	}
	
	
	@RequestMapping("/subChangeCourseApplication")  // 跳转页面
	public String subChangeCourseApplication(HttpServletRequest request, HttpSession session) throws Exception {
		
		// 获取 teacher
		Teacher teacher = (Teacher) session.getAttribute("user"); 
		String originalTId = teacher.gettId();
		String newTId = request.getParameter("newTId");
		SimpleDateFormat formatter= new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date(System.currentTimeMillis());
		String appTime = formatter.format(date);
		int ttId = Integer.parseInt(request.getParameter("ttId"));
		int originalWeek = Integer.parseInt(request.getParameter("originalWeek"));
		int newWeek = Integer.parseInt(request.getParameter("newWeek"));
		String originalTime = request.getParameter("originalTime");
		String newTime = request.getParameter("newTime");
		int originalRnum = Integer.parseInt(request.getParameter("originalRnum"));
		int newRnum = Integer.parseInt(request.getParameter("newRnum"));
		String reason = request.getParameter("reason");
		
		ChangeCourseApplication c = new ChangeCourseApplication(appTime, originalTId, newTId, ttId, originalWeek, newWeek, originalTime, newTime, originalRnum, newRnum, reason, 0);
		System.out.println("c:" + c);
		changeCourseApplicationServiceImpl.saveChangeCourseApplication(c);
		
		return "redirect:/preIndex";
	}
	
	
}
