package com.teacher.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.bean.Teacher;
import com.teacher.service.TeacherServiceImpl;

@Controller
public class PreEnterController {
	
	@Resource
	private TeacherServiceImpl teacherServiceImpl;
	

	@RequestMapping("/preIndex")
	public String preIndex(HttpSession session) {
		Teacher user = teacherServiceImpl.uniTeacherById("1");
		System.out.println("user:" + user);
		session.setAttribute("user", user);
		return "personalCenter";
	}
}
