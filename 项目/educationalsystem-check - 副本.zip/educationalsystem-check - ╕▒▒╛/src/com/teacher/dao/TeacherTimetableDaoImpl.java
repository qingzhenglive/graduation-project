package com.teacher.dao;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import com.bean.TeacherTimetable;
import com.bean.TeachingClass;
import com.student.util.BaseDao;

@Repository
public class TeacherTimetableDaoImpl extends BaseDao<TeacherTimetable>{

	@Resource
	private TeachingClassDaoImpl teachingClassDaoImpl;
	
	// 找到老师所有的上课单元。
	public List<TeacherTimetable> findTimetablesByTeacherId(String tId,String year, int term){
		
		List<TeacherTimetable> timetables = new ArrayList<TeacherTimetable>();
		
		List<TeachingClass> teachingClasses = teachingClassDaoImpl.findTeachingClassesByTeacherId(tId, year, term);
		
		for(TeachingClass tc : teachingClasses) {
			for(TeacherTimetable tt : tc.getTeacherTimeTables()) {
				timetables.add(tt);
			}
		}
		return timetables;
	}
	
	
	// 调课申请页面:分页查找所有的具体的上课
	public List<TeacherTimetable> findTimetablesByPageAndTeacherId(int pageNo, int pageSize, String tId){
		
		String hql = "from TeacherTimetable tt where tt.teachingClass.teacher.tId = ?";
		
		return super.findByPage(hql, pageNo, pageSize, tId);
	}
	
	public int findCountTimetablesByPageAndTeacherId(String tId) throws Exception {
		
		String hql = "select count(*) from TeacherTimetable tt where tt.teachingClass.teacher.tId = ?";
		return (int) super.findCount(hql, tId);
	}
	
	// w
	public List<TeacherTimetable> findTimetablesByPageAndTeacherIdAndWeek(int pageNo, int pageSize, String tId, int week){
		
		String hql = "from TeacherTimetable tt where tt.teachingClass.teacher.tId = ? and tt.ttWeek = ?";
		
		return super.findByPage(hql, pageNo, pageSize, tId, week);
	}

	public int findCountTimetablesByTeacherIdAndWeek(String tId, int week) throws Exception{
		
		String hql = "select count(*) from TeacherTimetable tt where tt.teachingClass.teacher.tId = ? and tt.ttWeek = ?";
		return (int) super.findCount(hql, tId, week);
	}
	
	public TeacherTimetable findTeacherTimetableById(int ttId) {
		return super.get(TeacherTimetable.class, ttId);
	}
}
