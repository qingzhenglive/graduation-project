package com.teacher.dao;

import org.springframework.stereotype.Repository;

import com.bean.ResultProportion;
import com.student.util.BaseDao;

@Repository
public class ResultProportionDaoImpl extends BaseDao<ResultProportion>{
	
	public ResultProportion findResultProportionById(int rpId) {
		
		return super.get(ResultProportion.class, rpId);
		
	}
	
	
	public void updataResultProportion(ResultProportion resultProportion) {
		super.update(resultProportion);
	}

	
}
