package com.teacher.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.bean.Student;
import com.student.util.BaseDao;

@Repository
public class StudentDaoImpl extends BaseDao<Student>{

	public List<Student> findStudentsByPage(int pageNo, int pageSize){
		
		String hql = "from Student";
		return super.findByPage(hql, pageNo, pageSize);
	}
	
	public int findCountStudents() throws Exception {
		
		String hql = "select count(*) from Student";
		return (int) super.findCount(hql);
	}
	
	//ytc
	public List<Student> findStudentsByPageAndTeachingClass(int pageNo, int pageSize, int tcId){
		
		String hql = "select distinct tt.snum from Timetable tt where tt.tcId.tcId = ?";
		return super.findByPage(hql, pageNo, pageSize, tcId);
		
	}
	
	public int findCountStudentsByTeachingClass(int tcId) throws Exception{
		
		String hql = "select count(distinct tt.snum) from Timetable tt where tt.tcId.tcId = ?";
		return (int) super.findCount(hql, tcId);
		
	}
	
	// 从grade 中查找有成绩的学生
	public List<Student> findHasGradeStudentsByPageAndTeachingClass(int pageNo, int pageSize, int tcId) {
		System.out.println("print:");
		String hql = "select g.snum from Grade g where g.teachingClass.tcId = ?";
		
		List<Student> rtn = super.findByPage(hql, pageNo, pageSize, tcId);
		return rtn;
	}
	
	// 从grade 中计算有成绩的学生的人数
	public int findCountHasGradeStudentsByTeachingClass(int tcId) throws Exception {
		String hql = "select count(*) from Grade g where g.teachingClass.tcId = ?";
		return (int) super.findCount(hql, tcId);
	}
	
	public List<Student> findHasntGradeStudentsByPageAndTeachingClass(int pageNo, int pageSize, int tcId){
		
		String hql = "select distinct t.snum "
				+ "from Timetable t  "
				+ "where t.tcId.tcId = ? "
				+ "and t.snum not in"
				+ "(select g.snum "
				+ "from Grade g "
				+ "where g.teachingClass.tcId = ?)";
		
		return super.findByPage(hql, pageNo, pageSize, tcId, tcId);
	}
	
	public int findCountHasntGradeStudentsByTeachingClass(int tcId) throws Exception {
		
		String hql = "select count(distinct t.snum) "
				+ "from Timetable t "
				+ "where t.tcId.tcId = ?  "
				+ "and t.snum not in "
				+ "(select g.snum "
				+ "from Grade g "
				+ "where g.teachingClass.tcId = ?)";
		
		return (int) super.findCount(hql, tcId, tcId);
	}
	
	
	public Student findStudentById(String studentId) throws Exception {
		
		String hql = "from Student s where s.snum = ?";
		return super.findOne(hql, studentId);
		
	}
}
