package com.teacher.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.bean.Courses;
import com.bean.Teaching;
import com.bean.TeachingClass;
import com.student.util.BaseDao;


//找某个老师所教的课程
//找某个老师的教学班

@Repository
public class TeachingClassDaoImpl extends BaseDao<TeachingClass>{
	
	public List<Courses> findTaughtCoursesByTeacherId(String tId){
		String hql = "from TeachingClass tc where tc.teacher.tId = ?";
		List<TeachingClass> teachingClasses = super.find(hql, tId);
		Map<Integer, TeachingClass> maps = new HashMap<Integer,TeachingClass>();
		List<Courses> courses = new ArrayList<Courses>();
		// 去掉重复
		for(TeachingClass tc : teachingClasses) {
			Courses c = tc.getCourse();
			int cnum = c.getCnum();
			if(!maps.containsKey(cnum)) {
				maps.put(cnum, tc);
				courses.add(c);
			}
		}
		return courses;
		
	}
	

	// 分页查找老师所授的课程
	public List<Courses> findTaughtCoursesByPageAndTeacherId(int pageNo, int pageSize,String tId) {
		
		System.out.println("findAlltaughtCoursesByPageAndId..");
		
		String hql = "from TeachingClass tc where tc.teacher.tId = ?";
		List<TeachingClass> teachingClasses = super.findByPage(hql, pageNo, pageSize, tId);
		Map<Integer, TeachingClass> maps = new HashMap<Integer,TeachingClass>();
		List<Courses> courses = new ArrayList<Courses>();
		// 去掉重复
		for(TeachingClass tc : teachingClasses) {
			Courses c = tc.getCourse();
			int cnum = c.getCnum();
			if(!maps.containsKey(cnum)) {
				maps.put(cnum, tc);
				courses.add(c);
			}
		}
		
		System.out.println("courses : " + courses);
		return courses;
	}
	
	public int findCountTaughtCoursesById(String tId) throws Exception {
		
		System.out.println("findAlltaughtCoursesByPageAndId..");
		
		String hql = "select count(distinct tc.course) from TeachingClass tc where tc.teacher.tId = ?";

		return (int) super.findCount(hql, tId);
	}
	
	
	
	//y
	public List<Courses> findTaughtCoursesByPageAndTeacherIdAndYear(int pageNo, int pageSize,String tId, String year) {
		
		System.out.println("findAlltaughtCoursesByPageAndId..");
		
		String hql = "from TeachingClass tc where tc.teacher.tId = ?"
				+ "and tc.teachingSchedule.tYear = ?";
		List<TeachingClass> teachingClasses = super.findByPage(hql, pageNo, pageSize, tId, year);
		Map<Integer, TeachingClass> maps = new HashMap<Integer,TeachingClass>();
		List<Courses> courses = new ArrayList<Courses>();
		// 去掉重复
		for(TeachingClass tc : teachingClasses) {
			Courses c = tc.getCourse();
			int cnum = c.getCnum();
			if(!maps.containsKey(cnum)) {
				maps.put(cnum, tc);
				courses.add(c);
			}
		}
		return courses;
	}
	
	public int findCountTaughtCoursesByTeacherIdAndYear(String tId, String year) throws Exception {
		
		String hql = "select count(distinct tc.course) from TeachingClass tc where tc.teacher.tId = ?"
				+ "and tc.teachingSchedule.tYear = ?";
		return (int) super.findCount(hql, tId, year);
	}
	
	//t
	public List<Courses> findTaughtCoursesByPageAndTeacherIdAndTerm(int pageNo, int pageSize,String tId,int term) {
		
		System.out.println("findAlltaughtCoursesByPageAndId..");
		
		String hql = "from TeachingClass tc where tc.teacher.tId = ?"
				+ "and tc.course.cterm = ?";
		List<TeachingClass> teachingClasses = super.findByPage(hql, pageNo, pageSize, tId,term);
		Map<Integer, TeachingClass> maps = new HashMap<Integer,TeachingClass>();
		List<Courses> courses = new ArrayList<Courses>();
		// 去掉重复
		for(TeachingClass tc : teachingClasses) {
			Courses c = tc.getCourse();
			int cnum = c.getCnum();
			if(!maps.containsKey(cnum)) {
				maps.put(cnum, tc);
				courses.add(c);
			}
		}
		return courses;
	}
	
	public int findCountCoursesByTeacherIdAndTerm(String tId,int term) throws Exception {
		
		System.out.println("findAlltaughtCoursesByPageAndId..");
		
		String hql = "select count(distinct tc.course) from TeachingClass tc where tc.teacher.tId = ?"
				+ "and tc.course.cterm = ?";
		
		
		return (int) super.findCount(hql, tId,term);
	}
	
	
	//yt
	
	public List<Courses> findTaughtCoursesByPageAndTeacherIdAndYearAndTerm(int pageNo, int pageSize,String tId,String year, int term) {
		
		System.out.println("findAlltaughtCoursesByPageAndId..");
		
		String hql = "from TeachingClass tc where tc.teacher.tId = ?"
				+ "and tc.teachingSchedule.tYear = ? and tc.course.cterm = ?";
		
		List<TeachingClass> teachingClasses = super.findByPage(hql, pageNo, pageSize, tId, year, term);
		Map<Integer, TeachingClass> maps = new HashMap<Integer,TeachingClass>();
		List<Courses> courses = new ArrayList<Courses>();
		// 去掉重复
		for(TeachingClass tc : teachingClasses) {
			Courses c = tc.getCourse();
			int cnum = c.getCnum();
			if(!maps.containsKey(cnum)) {
				maps.put(cnum, tc);
				courses.add(c);
			}
		}
		return courses;
	}
	
	public int findCountTaughtCoursesByTeacherIdAndYearAndTerm(String tId,String year, int term) throws Exception {
		
		System.out.println("findAlltaughtCoursesByPageAndId..");
		
		String hql = "select count(distinct tc.course) from TeachingClass tc where tc.teacher.tId = ?"
				+ "and tc.teachingSchedule.tYear = ? and tc.course.cterm = ? ";
		
		return (int) super.findCount(hql, tId,year, term);
	}
	
	
	
	// 教学班自身
	// 如果从课程页跳进来，课程会自动选择，学年学期会匹配。
	// 如果直接进来, 学年学期为最新当前学年学期，课程为 全部
	// 所以在查找的时候 学年和学期不会为空。
	
	
	/*
	 * 直接点进来的情况，学年学期为最新，课程为 全部。
	 */
	public List<TeachingClass> findTeachingClassesByPageAndTeacherId(int pageNo, int pageSize, String tId,String year, int term){
		
		String hql = "from TeachingClass tc where tc.teacher.tId = ? and tc.teachingSchedule.tYear = ?"
				+ "and tc.course.cterm = ?";
		return super.findByPage(hql, pageNo, pageSize, tId, year, term);
	}
	
	// 找到教师 所有的教学班 ， 在TimeTabeDao里会有处理
	public List<TeachingClass> findTeachingClassesByTeacherId(String tId,String year, int term){
		
		String hql = "from TeachingClass tc where tc.teacher.tId = ? and tc.teachingSchedule.tYear = ?"
				+ "and tc.course.cterm = ?";
		return super.find(hql, tId, year, term);
	}
	
	public int findCountTeachingClassesByTeacherId(String tId, String year, int term) throws Exception {
		
		String hql = "select count(*) from TeachingClass tc where tc.teacher.tId = ? and tc.teachingSchedule.tYear = ?"
				+ "and tc.course.cterm = ?";
		return (int) super.findCount(hql,tId, year, term);
	}
	
	
	// 选择课程或者 从其他页面跳转进来的情况
	public List<TeachingClass> findTeachingClassesByPageAndTeacherIdAndCourse(int pageNo, int pageSize, String tId,String year, int term,
		int courseId){
		
		String hql = "from TeachingClass tc where tc.teacher.tId = ? and tc.teachingSchedule.tYear = ?"
				+ "and tc.course.cterm = ? and tc.course.cnum = ?";
		return super.findByPage(hql, pageNo, pageSize, tId, year, term, courseId);
	}
	
	
	public int findCountTeachingClassesByTeacherIdAndCourse(String tId, String year, int term, int courseId) throws Exception {
		
		String hql = "select count(*) from TeachingClass tc where tc.teacher.tId = ? and tc.teachingSchedule.tYear = ?"
				+ "and tc.course.cterm = ? and tc.course.cnum = ?";
		return (int) super.findCount(hql,tId, year, term, courseId);
	}
	
	public TeachingClass findTeachingClassById(int id) {
		return super.get(TeachingClass.class, id);
	}
	
	public void updateTeachingClassInputtedFinishById(int tcId) {
		super.get(TeachingClass.class, tcId).setInputted(1);
	}
	
	
}
