package com.teacher.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.bean.Grade;
import com.bean.Student;
import com.student.util.BaseDao;

@Repository
public class GradeDaoImpl extends BaseDao<Grade>{
	
	
	public List<Grade> findGradesByStudentsAndTeachingClass(List<Student> students, int tcId) throws Exception {
		
		
		List<Grade> grades = new ArrayList<Grade>();
		
		for(Student s: students) {
			System.out.println(s.getClass());
			Grade g = findGradeByStudentAndTeachingClass(s.getSnum(), tcId);
			grades.add(g);
		}
		return grades;
	}
	
	
	public Grade findGradeByStudentAndTeachingClass(String studentId, int tcId) throws Exception {
		
		
		String hql = "from Grade g where g.snum.snum = ? and g.teachingClass.tcId = ?";
		return super.findOne(hql, studentId, tcId);
	}
	
	
	public List<Grade> findGradesByTeachingClass(int tcId) {
		
		String hql = "from Grade g where g.teachingClass.tcId = ?";
		return super.find(hql, tcId);
		
	}
	
	public int findCountGradesByTeachingClass(int tcId) throws Exception {
		
		String hql = "select count(*) from Grade g where g.teachingClass.tcId = ?";
		
		return (int) super.findCount(hql, tcId);
	}
	
	public void insertGrade(Grade g) {
		super.save(g);
	}
}
