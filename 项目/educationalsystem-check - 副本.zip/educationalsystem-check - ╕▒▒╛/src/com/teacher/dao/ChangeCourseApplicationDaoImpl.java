package com.teacher.dao;

import org.springframework.stereotype.Repository;

import com.bean.ChangeCourseApplication;
import com.student.util.BaseDao;

@Repository
public class ChangeCourseApplicationDaoImpl extends BaseDao<ChangeCourseApplication> {

	public void insertChangeCourseApplication(ChangeCourseApplication c) {
		super.save(c);
	}
	
}
