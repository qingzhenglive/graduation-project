package com.student.login.dao;

import javax.annotation.Resource;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Repository;

import com.bean.Job;
import com.bean.Student;
import com.bean.Teacher;
import com.bean.Undergraduate;

/**
 * 
 * @desc:登录操作 校验密码是否正确
 * @author chunhui
 * @date:Feb 19, 20201:20:37 PM
 */
@Repository
public class LoginDao {

	@Resource
	private SessionFactory sessionFactory;

	/*
	 * 查询学号为xxx的密码并返回
	 */
	public String selectPswBySnum(String username) {
		Session session = this.sessionFactory.getCurrentSession();
		Query query = session.createQuery("select stu.psw from Student stu where stu.snum=?");
		query.setParameter(0, username);
		return (String) query.list().get(0);
	}

	/*
	 * 查询是否存在某个学生
	 */
	public Student selectBySnum(String username) {
		Session session = this.sessionFactory.getCurrentSession();
		Query query = session.createQuery("from Student stu where stu.snum=?");
		query.setParameter(0, username);
		return (Student) query.list().get(0);
	}

	/*
	 * 查询职工号为xxx的密码并返回
	 */
	public String selectPswByTnum(String username) {
		Session session = this.sessionFactory.getCurrentSession();
		Query query = session.createQuery("select tu.psw from Teacher tu where tu.tnum=?");
		query.setParameter(0, username);
		return (String) query.list().get(0);
	}

	/*
	 * 查询是否存在某个教师
	 */
	public Teacher selectByTnum(String username) {
		Session session = this.sessionFactory.getCurrentSession();
		Query query = session.createQuery("From Teacher t where t.tnum=?");
		query.setParameter(0, username);
		return (Teacher) query.list().get(0);
	}

	/*
	 * 查询就业学生学号为xxx的密码并返回
	 */
	public String selectPswByJob(int username) {
		Session session = this.sessionFactory.getCurrentSession();
		Query query = session.createQuery("select j.psw from Job j where j.id=?");
		query.setParameter(0, username);
		return (String) query.list().get(0);
	}

	/*
	 * 查询是否存在某个就业学生
	 */
	public Job selectByJob(int username) {
		Session session = this.sessionFactory.getCurrentSession();
		Query query = session.createQuery("From Job j where j.id=?");
		query.setParameter(0, username);
		return (Job) query.list().get(0);
	}

	/*
	 * 查询考研学生学号为xxx的密码并返回
	 */
	public String selectPswByGra(int username) {
		Session session = this.sessionFactory.getCurrentSession();
		Query query = session.createQuery("select u.psw from Undergraduate u where u.id=?");
		query.setParameter(0, username);
		return (String) query.list().get(0);
	}

	/*
	 * 查询是否存在某个考研生
	 */
	public Undergraduate selectByGra(int username) {
		Session session = this.sessionFactory.getCurrentSession();
		Query query = session.createQuery("From Undergraduate u where u.id=?");
		query.setParameter(0, username);
		return (Undergraduate) query.list().get(0);
	}
}
