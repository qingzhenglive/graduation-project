package com.student.login.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.student.login.service.LoginService;

@Controller
public class LoginController {
	@Resource
	private LoginService LoginService;
	
	@RequestMapping("/login")
	public String login(@RequestParam(value="username",required=false) String name,@RequestParam(value="password",required=false) String psw,
			@RequestParam(value="role",required=false)String role,HttpServletRequest request) {
		int flag =LoginService.isTrueByNameOrPsw(name, psw, role);
		if(flag==0) {
			request.setAttribute("username", name);
			System.out.println("成功执行");
			return "schedule";
		}else {
			return "error";
		}
	}
}
