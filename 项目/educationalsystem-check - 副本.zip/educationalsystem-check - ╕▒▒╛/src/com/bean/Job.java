package com.bean;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="job")
public class Job {
	private int id;
	private String psw;
	private String exprience;
	private String motto;
	private String post;
	private String salary;
	private String name;
	private String photo;
	private String sclass;
	private Company company;
	private  Set<Recruit> recruits=new HashSet<Recruit>();
	
	@Id
	@Column(name="job_id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@Column(name="job_salary")
	public String getSalary() {
		return salary;
	}
	public void setSalary(String salary) {
		this.salary = salary;
	}
	@ManyToOne
	@JoinColumn(name="job_company")
	public Company getCompany() {
		return company;
	}
	public void setCompany(Company company) {
		this.company = company;
	}
	@Column(name="job_exprience")
	public String getExprience() {
		return exprience;
	}
	public void setExprience(String exprience) {
		this.exprience = exprience;
	}
	@Column(name="job_motto")
	public String getMotto() {
		return motto;
	}
	public void setMotto(String motto) {
		this.motto = motto;
	}
	@Column(name="job_post")
	public String getPost() {
		return post;
	}
	public void setPost(String post) {
		this.post = post;
	}


	@Column(name="job_name")
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	@Column(name="job_sclass")
	public String getSclass() {
		return sclass;
	}
	public void setSclass(String sclass) {
		this.sclass = sclass;
	}
	
	@Column(name="job_photo")
	public String getPhoto() {
		return photo;
	}
	public void setPhoto(String photo) {
		this.photo = photo;
	}
	
	@OneToMany(mappedBy="personal",targetEntity=Recruit.class,cascade=CascadeType.ALL)
	public Set<Recruit> getRecruits() {
		return recruits;
	}
	public void setRecruits(Set<Recruit> recruits) {
		this.recruits = recruits;
	}
	public String getPsw() {
		return psw;
	}
	public void setPsw(String psw) {
		this.psw = psw;
	}
	
	
	
}
