package com.bean;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "administrativeClass")
public class AdministrativeClass {

	private int adId;
	private String adGrade;
	private String adHeadMaster;
	private int adTotalNum;
	private String adClass;
	
	private Set<Student> students = new HashSet<Student>();

	

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int getAdId() {
		return adId;
	}

	public void setAdId(int adId) {
		this.adId = adId;
	}

	public String getAdGrade() {
		return adGrade;
	}

	public void setAdGrade(String adGrade) {
		this.adGrade = adGrade;
	}

	public String getAdHeadMaster() {
		return adHeadMaster;
	}

	public void setAdHeadMaster(String adHeadMaster) {
		this.adHeadMaster = adHeadMaster;
	}

	public int getAdTotalNum() {
		return adTotalNum;
	}

	public void setAdTotalNum(int adTotalNum) {
		this.adTotalNum = adTotalNum;
	}

	public String getAdClass() {
		return adClass;
	}

	public void setAdClass(String adClass) {
		this.adClass = adClass;
	}

	
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "classes")
	public Set<Student> getStudents() {
		return students;
	}

	public void setStudents(Set<Student> students) {
		this.students = students;
	}

	@Override
	public String toString() {
		return "AdministrativeClass [adId=" + adId + ", adGrade=" + adGrade + ", adHeadMaster=" + adHeadMaster
				+ ", adTotalNum=" + adTotalNum + ", adClass=" + adClass + "]";
	}
}
