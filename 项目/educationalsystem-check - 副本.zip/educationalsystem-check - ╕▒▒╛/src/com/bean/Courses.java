package com.bean;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * 
 * @desc:全部课程表
 * @author chunhui
 * @date:Feb 18, 20203:13:41 PM
 */
/*
 * 课程号 课程名字 学分 开课学期 开课学院 课程性质
 */
@Entity
@Table(name = "courses")
public class Courses {

	private int cnum;
	private String cname;
	private float credit;
	private int cterm;
	private String college;
	private String type;
	private Set<Student> students = new HashSet<Student>();
	private ResultProportion resultProportion;   
	private TeachingSchedule teachingSchedule;    
	private Set<TeachingClass> teachingClasses = new HashSet<TeachingClass>();

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int getCnum() {
		return cnum;
	}

	public void setCnum(int cnum) {
		this.cnum = cnum;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public float getCredit() {
		return credit;
	}

	public void setCredit(float credit) {
		this.credit = credit;
	}

	public int getCterm() {
		return cterm;
	}

	public void setCterm(int cterm) {
		this.cterm = cterm;
	}

	public String getCollege() {
		return college;
	}

	public void setCollege(String college) {
		this.college = college;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	@ManyToMany(mappedBy = "courses")
	public Set<Student> getStudents() {
		return students;
	}

	public void setStudents(Set<Student> students) {
		this.students = students;
	}
	
	@OneToOne(mappedBy = "course")
	public ResultProportion getResultProportion() {
		return resultProportion;
	}

	public void setResultProportion(ResultProportion resultProportion) {
		this.resultProportion = resultProportion;
	}

	@OneToOne(mappedBy = "course")
	public TeachingSchedule getTeachingSchedule() {
		return teachingSchedule;
	}

	public void setTeachingSchedule(TeachingSchedule teachingSchedule){
		this.teachingSchedule = teachingSchedule;
	}

	@Override
	public String toString() {
		return "Courses [cnum=" + cnum + ", cname=" + cname + "]";
	}

	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "courseID")
	public Set<TeachingClass> getTeachingClasses() {
		return teachingClasses;
	}

	public void setTeachingClasses(Set<TeachingClass> teachingClasses) {
		this.teachingClasses = teachingClasses;
	}
	
	
	
}
