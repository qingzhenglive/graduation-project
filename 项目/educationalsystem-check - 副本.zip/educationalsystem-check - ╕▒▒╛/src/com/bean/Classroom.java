package com.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * 
 * @desc:教室表
 * @author chunhui
 * @date:Feb 18, 20203:18:47 PM
 */
/*
 *教室编号 教室名称 具体地点
 */
@Entity
@Table(name = "classroom")
public class Classroom {

	private int rnum;
	private String rname;
	private String place;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int getRnum() {
		return rnum;
	}

	public void setRnum(int rnum) {
		this.rnum = rnum;
	}

	public String getRname() {
		return rname;
	}

	public void setRname(String rname) {
		this.rname = rname;
	}

	public String getPlace() {
		return place;
	}

	public void setPlace(String place) {
		this.place = place;
	}

}
