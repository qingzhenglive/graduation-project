package com.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "teacherTimetable")
public class TeacherTimetable {

	private int ttId;
	private TeachingClass teachingClass;
	private Classroom classroom;
	private int ttWeek;
	private String ttTime;
	private String ttName;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int getTtId() {
		return ttId;
	}

	public void setTtId(int ttId) {
		this.ttId = ttId;
	}



	public String getTtTime() {
		return ttTime;
	}

	public void setTtTime(String ttTime) {
		this.ttTime = ttTime;
	}

	public String getTtName() {
		return ttName;
	}

	public void setTtName(String ttName) {
		this.ttName = ttName;
	}


	@ManyToOne
	@JoinColumn(name = "tcId")
	public TeachingClass getTeachingClass() {
		return teachingClass;
	}

	public void setTeachingClass(TeachingClass teachingClass) {
		this.teachingClass = teachingClass;
	}

	@ManyToOne
	@JoinColumn(name = "crId")  //?????
	public Classroom getClassroom() {
		return classroom;
	}

	public void setClassroom(Classroom classroom) {
		this.classroom = classroom;
	}

	@Override
	public String toString() {
		return "TeacherTimetable [ttId=" + ttId + ", teachingClass=" + teachingClass + ", classroom=" + classroom
				+ ", ttWeek=" + ttWeek + ", ttTime=" + ttTime + ", ttName=" + ttName + "]";
	}

	public int getTtWeek() {
		return ttWeek;
	}

	public void setTtWeek(int ttWeek) {
		this.ttWeek = ttWeek;
	}

}
