package com.bean;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="undergraduate")
public class Undergraduate {
	
	private int id;
	private String psw;
	private String shool;
	private String name;
	private String photo;
	private String sclass;
	private Set<Teaching> Teachings=new HashSet<Teaching>();
	
	@Id
	@Column(name="undergraduate_id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@Column(name="undergraduate_shool")
	public String getShool() {
		return shool;
	}
	public void setShool(String shool) {
		this.shool = shool;
	}
	@Column(name="undergraduate_name")
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Column(name="undergraduate_photo")
	public String getPhoto() {
		return photo;
	}
	public void setPhoto(String photo) {
		this.photo = photo;
	}
	@Column(name="undergraduate_sclass")
	public String getSclass() {
		return sclass;
	}
	public void setSclass(String sclass) {
		this.sclass = sclass;
	}
	@OneToMany(mappedBy="lecturer",targetEntity=Teaching.class,cascade=CascadeType.ALL)
	public Set<Teaching> getTeachings() {
		return Teachings;
	}
	public void setTeachings(Set<Teaching> teachings) {
		Teachings = teachings;
	}
	public String getPsw() {
		return psw;
	}
	public void setPsw(String psw) {
		this.psw = psw;
	}
	
	
	
	

}
