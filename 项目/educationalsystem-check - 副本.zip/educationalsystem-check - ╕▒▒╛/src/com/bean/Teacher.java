package com.bean;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "teacher")
public class Teacher {

	private String tId;
	private String tname;
	private String gender;
	private String tnation;
	private String tbirthday;
	private String tpolitical;
	private String phone;
	private String email;
	private String qualification;   // 学历
	private String degree;  // 学位
	private String title;   // 职称
	private String fschool;
	private String tmajor;
	private String teachingInstitute;
	private String password;
	private Set<ChangeCourseApplication> changeCourseApplications = new HashSet<ChangeCourseApplication>();
	 
	@Id
	@GeneratedValue(generator = "myGenerator")
	@GenericGenerator(name = "myGenerator", strategy = "assigned")
	public String gettId() {
		return tId;
	}
	public void settId(String tId) {
		this.tId = tId;
	}
	
	public String getTname() {
		return tname;
	}
	public void setTname(String tname) {
		this.tname = tname;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getTnation() {
		return tnation;
	}
	public void setTnation(String tnation) {
		this.tnation = tnation;
	}
	public String getTbirthday() {
		return tbirthday;
	}
	public void setTbirthday(String tbirthday) {
		this.tbirthday = tbirthday;
	}
	public String getTpolitical() {
		return tpolitical;
	}
	public void setTpolitical(String tpolitical) {
		this.tpolitical = tpolitical;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getQualification() {
		return qualification;
	}
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	public String getDegree() {
		return degree;
	}
	public void setDegree(String degree) {
		this.degree = degree;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getFschool() {
		return fschool;
	}
	public void setFschool(String fschool) {
		this.fschool = fschool;
	}
	public String getTmajor() {
		return tmajor;
	}
	public void setTmajor(String tmajor) {
		this.tmajor = tmajor;
	}
	public String getTeachingInstitute() {
		return teachingInstitute;
	}
	public void setTeachingInstitute(String teachingInstitute) {
		this.teachingInstitute = teachingInstitute;
	}
	@Column(name = "psw")
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "teacherId")
	public Set<ChangeCourseApplication> getChangeCourseApplications() {
		return changeCourseApplications;
	}
	public void setChangeCourseApplications(Set<ChangeCourseApplication> changeCourseApplications) {
		this.changeCourseApplications = changeCourseApplications;
	}
	
	
	@Override
	public String toString() {
		return "Teacher [tId=" + tId + ", tname=" + tname + ", gender=" + gender + ", tnation=" + tnation
				+ ", tbirthday=" + tbirthday + ", tpolitical=" + tpolitical + ", phone=" + phone + ", email=" + email
				+ ", qualification=" + qualification + ", degree=" + degree + ", title=" + title + ", fschool="
				+ fschool + ", tmajor=" + tmajor + ", teachingInstitute=" + teachingInstitute + ", password=" + password
				+ "]";
	}
	
	
}
