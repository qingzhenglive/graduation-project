package com.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * 
 * @desc:成绩表
 * @author chunhui
 * @date:Feb 18, 20203:22:37 PM
 */
/*
 * 成绩编号 学号 课程号 教师编号 成绩 成绩性质 绩点
 */
@Entity
@Table(name = "grade")
public class Grade {
	private int id;
	private Student snum;
	private Courses cnum;
	private Teacher tnum;
	private float score;
	private String type;
	private float point;
	private int midtermScore;
	private int finalScore;
	private int dailyScore;
	private int expScore;
	private int quizScore;
	private TeachingClass teachingClass;
	
	public Grade() {
		
	}
	
	public Grade(Student snum, Courses cnum, Teacher tnum, float score, String type, float point, int midtermScore,
			int finalScore, int dailyScore, int expScore, int quizScore, TeachingClass teachingClass) {
		super();
		this.snum = snum;
		this.cnum = cnum;
		this.tnum = tnum;
		this.score = score;
		this.type = type;
		this.point = point;
		this.midtermScore = midtermScore;
		this.finalScore = finalScore;
		this.dailyScore = dailyScore;
		this.expScore = expScore;
		this.quizScore = quizScore;
		this.teachingClass = teachingClass;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@ManyToOne
	@JoinColumn(name = "snum")
	public Student getSnum() {
		return snum;
	}

	public void setSnum(Student snum) {
		this.snum = snum;
	}

	@ManyToOne
	@JoinColumn(name = "cnum")
	public Courses getCnum() {
		return cnum;
	}

	public void setCnum(Courses cnum) {
		this.cnum = cnum;
	}

	@ManyToOne
	@JoinColumn(name = "tnum")
	public Teacher getTnum() {
		return tnum;
	}

	public void setTnum(Teacher tnum) {
		this.tnum = tnum;
	}

	public float getScore() {
		return score;
	}

	public void setScore(float score) {
		this.score = score;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public float getPoint() {
		return point;
	}

	public void setPoint(float point) {
		this.point = point;
	}

	public int getMidtermScore() {
		return midtermScore;
	}

	public void setMidtermScore(int midtermScore) {
		this.midtermScore = midtermScore;
	}

	public int getFinalScore() {
		return finalScore;
	}

	public void setFinalScore(int finalScore) {
		this.finalScore = finalScore;
	}

	public int getDailyScore() {
		return dailyScore;
	}

	public void setDailyScore(int dailyScore) {
		this.dailyScore = dailyScore;
	}

	public int getExpScore() {
		return expScore;
	}

	public void setExpScore(int expScore) {
		this.expScore = expScore;
	}

	public int getQuizScore() {
		return quizScore;
	}

	public void setQuizScore(int quizScore) {
		this.quizScore = quizScore;
	}

	@ManyToOne
	@JoinColumn(name = "tcId")
	public TeachingClass getTeachingClass() {
		return teachingClass;
	}

	public void setTeachingClass(TeachingClass teachingClass) {
		this.teachingClass = teachingClass;
	}

	@Override
	public String toString() {
		return "Grade [id=" + id + ", snum=" + snum + ", midtermScore=" + midtermScore + ", finalScore=" + finalScore
				+ ", dailyScore=" + dailyScore + ", expScore=" + expScore + ", quizScore=" + quizScore + "]";
	}

}
