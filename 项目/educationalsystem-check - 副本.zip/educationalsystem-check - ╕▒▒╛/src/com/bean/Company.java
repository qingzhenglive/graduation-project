package com.bean;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="company")
public class Company {

	
	private int id;
	private String name;
	private String site;
	private String logo;
	private String instruction;
	private String type;
	private Set<Recruit> recruits=new  HashSet<Recruit>();
	private Set<Job> personals=new HashSet<Job>();
	
	@Id
	@Column(name="company_id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@Column(name="company_name")
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Column(name="company_site")
	public String getSite() {
		return site;
	}
	public void setSite(String site) {
		this.site = site;
	}
	@Column(name="company_logo")
	public String getLogo() {
		return logo;
	}
	public void setLogo(String logo) {
		this.logo = logo;
	}
	
	@Column(name="company_instruction")
	public String getInstruction() {
		return instruction;
	}
	public void setInstruction(String instruction) {
		this.instruction = instruction;
	}
	@Column(name="company_type")
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	@OneToMany(mappedBy="company",targetEntity=Recruit.class,cascade=CascadeType.ALL)
	public Set<Recruit> getRecruits() {
		return recruits;
	}
	public void setRecruits(Set<Recruit> recruits) {
		this.recruits = recruits;
	}
	
	@OneToMany(mappedBy="company",targetEntity=Job.class,cascade=CascadeType.ALL)
	public Set<Job> getPersonals() {
		return personals;
	}
	public void setPersonals(Set<Job> personals) {
		this.personals = personals;
	}
	
	
	
}
