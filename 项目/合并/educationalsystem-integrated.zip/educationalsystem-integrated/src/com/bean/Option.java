package com.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * 
 *@desc:选课页面展示信息 封装成的实体
 *@author chunhui
 *@date:Feb 29, 20205:31:14 PM
 */
@Entity
@Table(name="optionCourse")
public class Option {
	private int id;
	private Courses course;
	private Teacher teacher;
	private int selectedNumber;
	private int sum;
	private int week;
	private int day;
	private String time;
	private Classroom classroom;
	private TeachingClass teachingClass;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@ManyToOne
	@JoinColumn(name = "cnum")
	public Courses getCourse() {
		return course;
	}
	public void setCourse(Courses course) {
		this.course = course;
	}
	@ManyToOne
	@JoinColumn(name = "tnum")
	public Teacher getTeacher() {
		return teacher;
	}
	public void setTeacher(Teacher teacher) {
		this.teacher = teacher;
	}
	public int getSelectedNumber() {
		return selectedNumber;
	}
	public void setSelectedNumber(int selectedNumber) {
		this.selectedNumber = selectedNumber;
	}
	public int getSum() {
		return sum;
	}
	public void setSum(int sum) {
		this.sum = sum;
	}
	public int getWeek() {
		return week;
	}
	public void setWeek(int week) {
		this.week = week;
	}
	public int getDay() {
		return day;
	}
	public void setDay(int day) {
		this.day = day;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	@ManyToOne
	@JoinColumn(name = "rnum")
	public Classroom getClassroom() {
		return classroom;
	}
	public void setClassroom(Classroom classroom) {
		this.classroom = classroom;
	}
	@ManyToOne
	@JoinColumn(name = "tcId")
	public TeachingClass getTeachingClass() {
		return teachingClass;
	}
	public void setTeachingClass(TeachingClass teachingClass) {
		this.teachingClass = teachingClass;
	}
	
	

}
