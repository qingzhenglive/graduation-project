package com.bean;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="teaching")
public class Teaching implements Serializable{
	
	private int id;
	private String name;
	private String video;
	private String summary;
	private int  watcher;
	private Undergraduate lecturer;
	private String type;
	private String describe;
	private String images;
	private Set <Comment> Comments=new HashSet<Comment>();
	
	
	
	
	public Teaching() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Teaching(int id, String name, int watcher, String describe, String images) {
		super();
		this.id = id;
		this.name = name;
		this.watcher = watcher;
		this.describe = describe;
		this.images = images;
	}

	@Id
	@Column(name="teach_id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@Column(name="teach_name")
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Column(name="teach_video")
	public String getVideo() {
		return video;
	}
	public void setVideo(String video) {
		this.video = video;
	}
	@Column(name="teach_summary")
	public String getSummary() {
		return summary;
	}
	public void setSummary(String summary) {
		this.summary = summary;
	}
	@ManyToOne
	@JoinColumn(name="teach_lecturer")
	public Undergraduate getLecturer() {
		return lecturer;
	}
	public void setLecturer(Undergraduate lecturer) {
		this.lecturer = lecturer;
	}
	
	@OneToMany(mappedBy="teaching",targetEntity=Comment.class,cascade=CascadeType.ALL)
	public Set<Comment> getComments() {
		return Comments;
	}
	public void setComments(Set<Comment> comments) {
		Comments = comments;
	}
	@Column(name="teach_watcher")
	public int getWatcher() {
		return watcher;
	}
	public void setWatcher(int watcher) {
		this.watcher = watcher;
	}
	
	@Column(name="teach_type")
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	@Column(name="teach_describe")
	public String getDescribe() {
		return describe;
	}
	public void setDescribe(String describe) {
		this.describe = describe;
	}
	@Column(name="teach_images")
	public String getImages() {
		return images;
	}
	public void setImages(String images) {
		this.images = images;
	}
	@Override
	public String toString() {
		return "Teaching [id=" + id + ", name=" + name + ", video=" + video + ", summary=" + summary + ", watcher="
				+ watcher + ", lecturer=" + lecturer + ", type=" + type + ", describe=" + describe + ", images="
				+ images + ", Comments=" + Comments + "]";
	}
	
	
	
}
