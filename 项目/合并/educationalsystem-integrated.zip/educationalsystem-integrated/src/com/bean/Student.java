package com.bean;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

/**
 * 
 * @desc:学生表
 * @author chunhui
 * @date:Feb 18, 20203:10:31 PM
 */
/*
 * 学号 密码 姓名 性别 年级 班级 出生年月 政治面貌 入学年份 籍贯 联系方式 专业
 */
@Entity
@Table(name="student")
public class Student {

	private String snum;
	private String psw;
	private String sname;
	private String sex;
	private String grade;
	private AdministrativeClass classes; 
	private String birthday;
	private String political;
	private String admission;
	private String hometown;
	private String phone;
	private String major;
	private Set<Courses> courses = new HashSet<Courses>();
	private List<Comment> comments=new ArrayList<Comment>();
	@Id
	@GeneratedValue(generator = "mine")
	@GenericGenerator(name = "mine", strategy = "assigned")
	public String getSnum() {
		return snum;
	}

	public void setSnum(String snum) {
		this.snum = snum;
	}

	public String getPsw() {
		return psw;
	}

	public void setPsw(String psw) {
		this.psw = psw;
	}


	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	@ManyToOne
	@JoinColumn(name = "classes")
	public AdministrativeClass getClasses() {
		return classes;
	}

	public void setClasses(AdministrativeClass classes) {
		this.classes = classes;
	}

	@ManyToMany
	@JoinTable(name = "grade", joinColumns = @JoinColumn(name = "snum"), inverseJoinColumns = @JoinColumn(name = "cnum"))
	public Set<Courses> getCourses() {
		return courses;
	}

	public void setCourses(Set<Courses> courses) {
		this.courses = courses;
	}

	@OneToMany(mappedBy="student",targetEntity=Comment.class,cascade=CascadeType.ALL)
	public List<Comment> getComments() {
		return comments;
	}

	public void setComments(List<Comment> comments) {
		this.comments = comments;
	}

	public String getBirthday() {
		return birthday;
	}

	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}

	public String getPolitical() {
		return political;
	}

	public void setPolitical(String political) {
		this.political = political;
	}

	public String getAdmission() {
		return admission;
	}

	public void setAdmission(String admission) {
		this.admission = admission;
	}

	public String getHometown() {
		return hometown;
	}

	public void setHometown(String hometown) {
		this.hometown = hometown;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getMajor() {
		return major;
	}

	public void setMajor(String major) {
		this.major = major;
	}
	
}
