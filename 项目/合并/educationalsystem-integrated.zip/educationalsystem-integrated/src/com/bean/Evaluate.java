package com.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * 
 * @desc:评价表
 * @author chunhui
 * @date:Feb 18, 20204:24:41 PM
 */
/*
 * 评价编号 学号 教师编号 分数
 */
@Entity
@Table(name = "evaluate")
public class Evaluate {

	private int id;
	private Student snum;
	private Teacher tnum;
	private float score;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@ManyToOne
	@JoinColumn(name = "snum")
	public Student getSnum() {
		return snum;
	}

	public void setSnum(Student snum) {
		this.snum = snum;
	}

	@ManyToOne
	@JoinColumn(name = "tnum")
	public Teacher getTnum() {
		return tnum;
	}

	public void setTnum(Teacher tnum) {
		this.tnum = tnum;
	}

	public float getScore() {
		return score;
	}

	public void setScore(float score) {
		this.score = score;
	}

}
