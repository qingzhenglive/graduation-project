package com.bean;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "teachingSchedule")
public class TeachingSchedule {

	private int tsId;
//	private int courseId;
	private Courses course;
	private String tYear;
	private int duration;
	private int totalHours;
	private int totalTcNum;
//	private int groupLeader;
//	private Teacher groupLeader;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int getTsId() {
		return tsId;
	}
	public void setTsId(int tsId) {
		this.tsId = tsId;
	}
	public String gettYear() {
		return tYear;
	}
	public void settYear(String tYear) {
		this.tYear = tYear;
	}
	
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}
	public int getTotalHours() {
		return totalHours;
	}
	public void setTotalHours(int totalHours) {
		this.totalHours = totalHours;
	}
	public int getTotalTcNum() {
		return totalTcNum;
	}
	public void setTotalTcNum(int totalTcNum) {
		this.totalTcNum = totalTcNum;
	}
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "courseId")
	public Courses getCourse() {
		return course;
	}
	public void setCourse(Courses course) {
		this.course = course;
	}
//	public Teacher getGroupLeader() {
//		return groupLeader;
//	}
//	public void setGroupLeader(Teacher groupLeader) {
//		this.groupLeader = groupLeader;
//	}
	
	
}
