package com.bean;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "resultProportion")
public class ResultProportion {

	private int rpId;
	private Courses course;
	private int midtermProportion;
	private int finalProportion;
	private int dailyProportion;
	private int expProportion;
	private int quizProportion;

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	
	public int getRpId() {
		return rpId;
	}

	public void setRpId(int rpId) {
		this.rpId = rpId;
	}

	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "courseId")
	public Courses getCourse() {
		return course;
	}

	public void setCourse(Courses course) {
		this.course = course;
	}
	
	public int getMidtermProportion() {
		return midtermProportion;
	}

	public void setMidtermProportion(int midtermProportion) {
		this.midtermProportion = midtermProportion;
	}

	public int getFinalProportion() {
		return finalProportion;
	}

	public void setFinalProportion(int finalProportion) {
		this.finalProportion = finalProportion;
	}

	public int getDailyProportion() {
		return dailyProportion;
	}

	public void setDailyProportion(int dailyProportion) {
		this.dailyProportion = dailyProportion;
	}

	public int getExpProportion() {
		return expProportion;
	}

	public void setExpProportion(int expProportion) {
		this.expProportion = expProportion;
	}

	public int getQuizProportion() {
		return quizProportion;
	}

	public void setQuizProportion(int quizProportion) {
		this.quizProportion = quizProportion;
	}

	@Override
	public String toString() {
		return "ResultProportion [rpId=" + rpId + ", course=" + course + ", midtermProportion=" + midtermProportion
				+ ", finalProportion=" + finalProportion + ", dailyProportion=" + dailyProportion + ", expProportion="
				+ expProportion + ", quizProportion=" + quizProportion + "]";
	}


	
}
