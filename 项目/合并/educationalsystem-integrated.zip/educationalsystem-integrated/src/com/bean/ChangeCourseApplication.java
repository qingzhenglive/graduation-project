package com.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "changeCourseApplication")
public class ChangeCourseApplication {

	private int ccaId;
	private String appTime;  // 申请时间
	private String originalTId;
	private String newTId;
	private int ttId;
	private int originalWeek;
	private int newWeek;
	private String originalTime;
	private String newTime;
	private int originalRnum;
	private int newRnum;
	private String reason;
	private int isApproved;
	

	
	public ChangeCourseApplication() {
		super();
	}

	public ChangeCourseApplication(String appTime, String originalTId, String newTId, int ttId,
			int originalWeek, int newWeek, String originalTime, String newTime, int originalRnum, int newRnum,
			String reason, int isApproved) {
		super();
		this.appTime = appTime;
		this.originalTId = originalTId;
		this.newTId = newTId;
		this.ttId = ttId;
		this.originalWeek = originalWeek;
		this.newWeek = newWeek;
		this.originalTime = originalTime;
		this.newTime = newTime;
		this.originalRnum = originalRnum;
		this.newRnum = newRnum;
		this.reason = reason;
		this.isApproved = isApproved;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int getCcaId() {
		return ccaId;
	}

	public void setCcaId(int ccaId) {
		this.ccaId = ccaId;
	}


	public String getAppTime() {
		return appTime;
	}

	public void setAppTime(String appTime) {
		this.appTime = appTime;
	}

	public String getOriginalTId() {
		return originalTId;
	}

	public void setOriginalTId(String originalTId) {
		this.originalTId = originalTId;
	}

	public String getNewTId() {
		return newTId;
	}

	public void setNewTId(String newTId) {
		this.newTId = newTId;
	}

	public int getTtId() {
		return ttId;
	}

	public void setTtId(int ttId) {
		this.ttId = ttId;
	}

	public int getOriginalWeek() {
		return originalWeek;
	}

	public void setOriginalWeek(int originalWeek) {
		this.originalWeek = originalWeek;
	}

	public int getNewWeek() {
		return newWeek;
	}

	public void setNewWeek(int newWeek) {
		this.newWeek = newWeek;
	}

	public String getOriginalTime() {
		return originalTime;
	}

	public void setOriginalTime(String originalTime) {
		this.originalTime = originalTime;
	}

	public String getNewTime() {
		return newTime;
	}

	public void setNewTime(String newTime) {
		this.newTime = newTime;
	}

	public int getOriginalRnum() {
		return originalRnum;
	}

	public void setOriginalRnum(int originalRnum) {
		this.originalRnum = originalRnum;
	}

	public int getNewRnum() {
		return newRnum;
	}

	public void setNewRnum(int newRnum) {
		this.newRnum = newRnum;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public int getIsApproved() {
		return isApproved;
	}

	public void setIsApproved(int isApproved) {
		this.isApproved = isApproved;
	}

	@Override
	public String toString() {
		return "ChangeCourseApplication [ccaId=" + ccaId + ", appTime=" + appTime + ", originalTId="
				+ originalTId + ", newTId=" + newTId + ", ttId=" + ttId + ", originalWeek=" + originalWeek
				+ ", newWeek=" + newWeek + ", originalTime=" + originalTime + ", newTime=" + newTime + ", originalRnum="
				+ originalRnum + ", newRnum=" + newRnum + ", reason=" + reason + ", isApproved=" + isApproved + "]";
	}


	


}
