package com.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * 
 * @desc:课表
 * @author chunhui
 * @date:Feb 18, 20203:19:54 PM
 */
/*
 * 课表编号 学号 课程号 教师编号 星期几上课 具体时间 开课年份 教学周 上课教室编号  教学班号
 */
@Entity
@Table(name = "timetable")
public class Timetable {
	private int id;
	private Student snum;
	private Courses cnum;
	private Teacher tnum;
	private int day;
	private String time;
	private String year;
	private int week;
	private Classroom rnum;
	private TeachingClass tcId;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@ManyToOne
	@JoinColumn(name = "snum")
	public Student getSnum() {
		return snum;
	}

	public void setSnum(Student snum) {
		this.snum = snum;
	}

	@ManyToOne
	@JoinColumn(name = "cnum")
	public Courses getCnum() {
		return cnum;
	}

	public void setCnum(Courses cnum) {
		this.cnum = cnum;
	}

	@ManyToOne
	@JoinColumn(name = "tnum")
	public Teacher getTnum() {
		return tnum;
	}

	public void setTnum(Teacher tnum) {
		this.tnum = tnum;
	}

	public int getDay() {
		return day;
	}

	public void setDay(int day) {
		this.day = day;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public int getWeek() {
		return week;
	}

	public void setWeek(int week) {
		this.week = week;
	}

	@ManyToOne
	@JoinColumn(name = "rnum")
	public Classroom getRnum() {
		return rnum;
	}

	public void setRnum(Classroom rnum) {
		this.rnum = rnum;
	}
	@ManyToOne
	@JoinColumn(name = "tcId")
	public TeachingClass getTcId() {
		return tcId;
	}

	public void setTcId(TeachingClass tcId) {
		this.tcId = tcId;
	}
	

}
