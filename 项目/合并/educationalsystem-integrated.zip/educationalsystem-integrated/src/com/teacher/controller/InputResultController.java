package com.teacher.controller;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.bean.Courses;
import com.bean.Grade;
import com.bean.ResultProportion;
import com.bean.Student;
import com.bean.Teacher;
import com.bean.TeachingClass;
import com.teacher.service.GradeServiceImpl;
import com.teacher.service.StudentServiceImpl;
import com.teacher.service.TeachingClassServiceImpl;
import com.teacher.util.Page;

@Controller
public class InputResultController {

	@Resource
	private TeachingClassServiceImpl teachingClassServiceImpl; 
	
	
	@Resource
	private StudentServiceImpl studentServiceImpl;
	
	@Resource
	private GradeServiceImpl gradeServiceImpl;
	
	@RequestMapping("/preInputResult")  // 第一次进入到 teachingClasses
	public String preMyTeachingClasses(HttpServletRequest request, HttpSession session) throws Exception {
		
		// 获取 teacher
		Teacher teacher = (Teacher) session.getAttribute("user"); 
		String tId = teacher.gettId();
		
		// 设置当前学期和时间 (第一次进入默认)  此处应该获得系统时间判断year 和 学期
		String year = "2016-2017"; 
		int term = 1;
		int pageNo = 1;
		int courseId = 0;  // 默认是全部课程
		
		// 调用 serviceImpl 查询当前年份和学习的所有课程的教学班
		List<TeachingClass> teachingClasses = teachingClassServiceImpl.listTeachingClassesByPageAndTeacherIdAndConstraints(pageNo, Page.PageSize, tId, year, term, courseId);
		int totalCount = teachingClassServiceImpl.countTeachingClassesByPageAndTeacherIdAndConstraints(tId, year, term, courseId);
		Page<TeachingClass> page = new Page<TeachingClass>();
		page.setPageNum(pageNo);
		page.setList(teachingClasses);
		page.setPageSize(Page.PageSize);
		page.setTotalCount(totalCount);

		request.setAttribute("page", page);
		request.setAttribute("pageNum", pageNo); // 有什么用
		
		List<Courses> allCourses = teachingClassServiceImpl.listTaughtCoursesByTeacherId(tId);
		session.setAttribute("allCourses", allCourses);
		
		// 设置默认
		request.setAttribute("defaultSelectedYear", year);
		request.setAttribute("defaultSelectedTerm", term);
		request.setAttribute("defaultSelectedcourseId", courseId);
		request.setAttribute("firstPageNum", (pageNo - 1) / 5 * 5 + 1);
		
		return "ir-inputResults-profile";
	}
	
	
	
	
	@RequestMapping("/selectInputResult")  // 点击查找按钮 
	public String selectMyTeachingClasses(HttpServletRequest request, HttpSession session) throws Exception {
		
		// 获取 teacher
		Teacher teacher = (Teacher) session.getAttribute("user"); 
		String tId = teacher.gettId();
		
		// 设置当前学期和时间
		String year = request.getParameter("year");
		System.out.println("获得的term:" + request.getParameter("term"));
		int term = Integer.parseInt(request.getParameter("term"));
		int pageNo = 1;
		int courseId = Integer.parseInt(request.getParameter("courseId"));  // 默认是全部课程
		
		// 调用 serviceImpl 查询当前年份和学习的所有课程的教学班
		List<TeachingClass> teachingClasses = teachingClassServiceImpl.listTeachingClassesByPageAndTeacherIdAndConstraints(pageNo, Page.PageSize, tId, year, term, courseId);
		int totalCount = teachingClassServiceImpl.countTeachingClassesByPageAndTeacherIdAndConstraints(tId, year, term, courseId);
		Page<TeachingClass> page = new Page<TeachingClass>();
		page.setPageNum(pageNo);
		page.setList(teachingClasses);
		page.setPageSize(Page.PageSize);
		page.setTotalCount(totalCount);

		request.setAttribute("page", page);
		request.setAttribute("pageNum", pageNo);
		
		// 表单回显
		request.setAttribute("defaultSelectedYear", year);
		request.setAttribute("defaultSelectedTerm", term);
		request.setAttribute("defaultSelectedcourseId", courseId);
		request.setAttribute("firstPageNum", (pageNo - 1) / 5 * 5 + 1);
		return "ir-inputResults-profile";
	}
	
	@RequestMapping("/jumpInputResult")  // 点击上一页，下一页，或者某个具体的页 
	public String jumpMyTeachingClasses(HttpServletRequest request, HttpSession session) throws Exception {
		
		// 获取 teacher
		Teacher teacher = (Teacher) session.getAttribute("user"); 
		String tId = teacher.gettId();
		
		// 设置当前学期和时间
		String year = request.getParameter("year");
		int term = Integer.parseInt(request.getParameter("term"));
		int pageNo = Integer.parseInt(request.getParameter("pageNum"));
		int courseId = Integer.parseInt(request.getParameter("courseId"));  // 默认是全部课程
		
		// 调用 serviceImpl 查询当前年份和学习的所有课程的教学班
		List<TeachingClass> teachingClasses = teachingClassServiceImpl.listTeachingClassesByPageAndTeacherIdAndConstraints(pageNo, Page.PageSize, tId, year, term, courseId);
		int totalCount = teachingClassServiceImpl.countTeachingClassesByPageAndTeacherIdAndConstraints(tId, year, term, courseId);
		Page<TeachingClass> page = new Page<TeachingClass>();
		page.setPageNum(pageNo);
		page.setList(teachingClasses);
		page.setPageSize(Page.PageSize);
		page.setTotalCount(totalCount);

		request.setAttribute("page", page);
		request.setAttribute("pageNum", pageNo);
		
		// 表单回显
		request.setAttribute("defaultSelectedYear", year);
		request.setAttribute("defaultSelectedTerm", term);
		request.setAttribute("defaultSelectedcourseId", courseId);
		request.setAttribute("firstPageNum", (pageNo - 1) / 5 * 5 + 1);
		return "ir-inputResults-profile";
	}
	
	
	@RequestMapping("/viewInputResultDetail")   // 此页面为固定的展示页面，不需要查找
	public String viewTeachingClasses(HttpServletRequest request, HttpSession session) throws Exception {
		
		
		// 获得 teachingClass 
		int tcId = Integer.parseInt(request.getParameter("tcId"));
		TeachingClass teachingClass = teachingClassServiceImpl.uniTeachingClassById(tcId);
		String year = teachingClass.getTeachingSchedule().gettYear();
		int term = teachingClass.getCourse().getCterm();
		
		int pageNo = 1;
	
		// 调用 serviceImpl 查询当前教学班没有成绩的学生
		List<Student> students = studentServiceImpl.listHasntGradeStudentsByPageAndTeachingClass(pageNo, Page.PageSize, tcId);
		
		List<Grade> grades = gradeServiceImpl.listGradesByStudentsAndTeachingClass(students, tcId);
		
		int totalCount = studentServiceImpl.countHasntGradeStudentsByTeachingClass(tcId);
				
		Page<Student> page = new Page<Student>();
		page.setPageNum(pageNo);
		page.setList(students);
		page.setPageSize(Page.PageSize);
		page.setTotalCount(totalCount);

		request.setAttribute("page", page);
		request.setAttribute("pageNum", pageNo); // 有什么用
		
		
		// 设置默认
		request.setAttribute("grades", grades);
		request.setAttribute("defaultSelectedYear", year);
		request.setAttribute("defaultSelectedTerm", term);
		request.setAttribute("defaultSelectedTeachingClass", teachingClass);
		request.setAttribute("tcId", tcId);
		request.setAttribute("firstPageNum", (pageNo - 1) / 5 * 5 + 1);
		
		return "ir-inputResults-details";
	}
	
	
	@RequestMapping("/jumpInputResultDetail")
	public String umpInputResultDetail(HttpServletRequest request, HttpSession session) throws Exception {
		
		// 获得 teachingClass 
		int tcId = Integer.parseInt(request.getParameter("tcId"));
		TeachingClass teachingClass = teachingClassServiceImpl.uniTeachingClassById(tcId);
		String year = teachingClass.getTeachingSchedule().gettYear();
		int term = teachingClass.getCourse().getCterm();
		
		int pageNo = 1;
	
		// 调用 serviceImpl 查询当前教学班没有成绩的学生
		List<Student> students = studentServiceImpl.listHasntGradeStudentsByPageAndTeachingClass(pageNo, Page.PageSize, tcId);
		
		List<Grade> grades = gradeServiceImpl.listGradesByStudentsAndTeachingClass(students, tcId);
		
		int totalCount = studentServiceImpl.countHasntGradeStudentsByTeachingClass(tcId);
				
		Page<Student> page = new Page<Student>();
		page.setPageNum(pageNo);
		page.setList(students);
		page.setPageSize(Page.PageSize);
		page.setTotalCount(totalCount);

		request.setAttribute("page", page);
		request.setAttribute("pageNum", pageNo); // 有什么用
		
		
		// 设置默认
		request.setAttribute("grades", grades);
		request.setAttribute("defaultSelectedYear", year);
		request.setAttribute("defaultSelectedTerm", term);
		request.setAttribute("defaultSelectedTeachingClass", teachingClass);
		request.setAttribute("tcId", tcId);
		request.setAttribute("firstPageNum", (pageNo - 1) / 5 * 5 + 1);
		
		return "ir-inputResults-details";
	}
	
	
	// 提交成绩，保证之前的所有参数都要有, 先修改再查询,如果resultProportion中没有某个成绩，那么列表就不会有此列.
	@RequestMapping("/submitInputResultDetail")
	public String submitInputResultDetail(HttpServletRequest request, HttpSession session) throws Exception {
		// 获得 teachingClass 
		int tcId = Integer.parseInt(request.getParameter("tcId"));
		TeachingClass teachingClass = teachingClassServiceImpl.uniTeachingClassById(tcId);
		String year = teachingClass.getTeachingSchedule().gettYear();
		int term = teachingClass.getCourse().getCterm();
		ResultProportion rp = teachingClass.getCourse().getResultProportion();
		
		
		int pageNo = 1;
	
		
		
		// 对现存的每一行进行处理
		for(int i = 1; i <= 5; ++i) {
			
			String studentId = request.getParameter("studentId" + i);
			if(studentId == null) break;
			Student s = studentServiceImpl.uniStudentById(studentId);
			int dailyScore = (request.getParameter("dailyScore" + i) == null ? 0 : Integer.parseInt(request.getParameter("dailyScore" + i)));
			int midtermScore = (request.getParameter("midtermScore" + i) == null ? 0 : Integer.parseInt(request.getParameter("midtermScore" + i)));
			int finalScore = (request.getParameter("finalScore" + i) == null ? 0 : Integer.parseInt(request.getParameter("finalScore" + i)));
			int expScore = (request.getParameter("expScore" + i) == null ? 0 : Integer.parseInt(request.getParameter("expScore" + i)));
			int quizScore = (request.getParameter("quizScore" + i) == null ? 0 : Integer.parseInt(request.getParameter("quizScore" + i)));
			float p = 3.2f;  // 先自己填的 需要计算
			float score = dailyScore * rp.getDailyProportion() + midtermScore * rp.getMidtermProportion() + finalScore * rp.getFinalProportion()
						+ expScore * rp.getExpProportion() + quizScore * rp.getQuizProportion();
			String type = request.getParameter("type" + i);
			Grade grade = new Grade(s,teachingClass.getCourse(),teachingClass.getTeacher(),score / 100f, type ,p, midtermScore, finalScore, dailyScore, expScore,
					quizScore, teachingClass);
			gradeServiceImpl.saveGrade(grade);  // 保存
			
		}
		
		
		// 调用 serviceImpl 查询当前教学班没有成绩的学生
		List<Student> students = studentServiceImpl.listHasntGradeStudentsByPageAndTeachingClass(pageNo, Page.PageSize, tcId);
		
		List<Grade> grades = gradeServiceImpl.listGradesByStudentsAndTeachingClass(students, tcId);
		
		int totalCount = studentServiceImpl.countHasntGradeStudentsByTeachingClass(tcId);
		
		if(totalCount == 0) teachingClassServiceImpl.inputTeacingClassFinishById(tcId);  // 如果，所有的学生都录入完成，设置字段为1
				
				
		Page<Student> page = new Page<Student>();
		page.setPageNum(pageNo);
		page.setList(students);
		page.setPageSize(Page.PageSize);
		page.setTotalCount(totalCount);

		request.setAttribute("page", page);
		request.setAttribute("pageNum", pageNo); // 有什么用
		
		
		// 设置默认
		request.setAttribute("grades", grades);
		request.setAttribute("defaultSelectedYear", year);
		request.setAttribute("defaultSelectedTerm", term);
		request.setAttribute("defaultSelectedTeachingClass", teachingClass);
		request.setAttribute("tcId", tcId);
		request.setAttribute("firstPageNum", (pageNo - 1) / 5 * 5 + 1);
		
		return "ir-inputResults-details";
	}
}
