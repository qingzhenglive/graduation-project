package com.teacher.controller;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.web.bind.annotation.RequestMapping;

import com.bean.Courses;
import com.bean.Teacher;
import com.bean.TeachingClass;
import com.teacher.service.CourseServiceImpl;
import com.teacher.service.TeachingClassServiceImpl;
import com.teacher.util.Page;

public class TeachingClassResultController {

	
	@Resource
	private TeachingClassServiceImpl teachingClassServiceImpl; 
	
	@Resource
	CourseServiceImpl courseServiceImpl;
	
	@RequestMapping("/preMyTeachingClassResult")  // 第一次进入到 teachingClasses
	public String preMyTeachingClasses(HttpServletRequest request, HttpSession session) throws Exception {
		
		// 获取 teacher
		Teacher teacher = (Teacher) session.getAttribute("user"); 
		String tId = teacher.gettId();
		
		// 设置当前学期和时间 (第一次进入默认)  此处应该获得系统时间判断year 和 学期
		String year = "2016-2017"; 
		int term = 1;
		int pageNo = 1;
		int courseId = 0;  // 默认是全部课程
		
		// 调用 serviceImpl 查询当前年份和学习的所有课程的教学班
		List<TeachingClass> teachingClasses = teachingClassServiceImpl.listTeachingClassesByPageAndTeacherIdAndConstraints(pageNo, Page.PageSize, tId, year, term, courseId);
		int totalCount = teachingClassServiceImpl.countTeachingClassesByPageAndTeacherIdAndConstraints(tId, year, term, courseId);
		Page<TeachingClass> page = new Page<TeachingClass>();
		page.setPageNum(pageNo);
		page.setList(teachingClasses);
		page.setPageSize(Page.PageSize);
		page.setTotalCount(totalCount);

		request.setAttribute("page", page);
		request.setAttribute("pageNum", pageNo); // 有什么用
		
		List<Courses> allCourses = teachingClassServiceImpl.listTaughtCoursesByTeacherId(tId);
		session.setAttribute("allCourses", allCourses);
		
		// 设置默认
		request.setAttribute("defaultSelectedYear", year);
		request.setAttribute("defaultSelectedTerm", term);
		request.setAttribute("defaultSelectedcourseId", courseId);
		request.setAttribute("firstPageNum", (pageNo - 1) / 5 * 5 + 1);
		
		return "ii-teachingClass";
	}
	
	@RequestMapping("/viewTeachingClassResult")  
	public String viewTeachingClasses(HttpServletRequest request, HttpSession session) throws Exception {
		
		// 获取 teacher
		Teacher teacher = (Teacher) session.getAttribute("user"); 
		String tId = teacher.gettId();
		
		// 设置当前学期和时间 (第一次进入默认)  此处应该获得系统时间判断year 和 学期
		int courseId = Integer.parseInt(request.getParameter("courseId"));  // 此时是从课程页面点进来之前获得的courseId;
		Courses course = courseServiceImpl.uniCourseById(courseId);
		String year = course.getTeachingSchedule().gettYear(); 
		int term = course.getCterm();
		int pageNo = 1;
	
		
		// 调用 serviceImpl 查询当前年份和学习的所有课程的教学班
		List<TeachingClass> teachingClasses = teachingClassServiceImpl.listTeachingClassesByPageAndTeacherIdAndConstraints(pageNo, Page.PageSize, tId, year, term, courseId);
		int totalCount = teachingClassServiceImpl.countTeachingClassesByPageAndTeacherIdAndConstraints(tId, year, term, courseId);
		Page<TeachingClass> page = new Page<TeachingClass>();
		page.setPageNum(pageNo);
		page.setList(teachingClasses);
		page.setPageSize(Page.PageSize);
		page.setTotalCount(totalCount);

		request.setAttribute("page", page);
		request.setAttribute("pageNum", pageNo); // 有什么用
		
		List<Courses> allCourses = teachingClassServiceImpl.listTaughtCoursesByTeacherId(tId);
		session.setAttribute("allCourses", allCourses);
		
		// 设置默认
		request.setAttribute("defaultSelectedYear", year);
		request.setAttribute("defaultSelectedTerm", term);
		request.setAttribute("defaultSelectedcourseId", courseId);
		request.setAttribute("firstPageNum", (pageNo - 1) / 5 * 5 + 1);
		
		return "ii-teachingClass";
	}
	
	@RequestMapping("/selectTeachingClassResult")  // 点击查找按钮 
	public String selectMyTeachingClasses(HttpServletRequest request, HttpSession session) throws Exception {
		
		// 获取 teacher
		Teacher teacher = (Teacher) session.getAttribute("user"); 
		String tId = teacher.gettId();
		
		// 设置当前学期和时间
		String year = request.getParameter("year");
		System.out.println("获得的term:" + request.getParameter("term"));
		int term = Integer.parseInt(request.getParameter("term"));
		int pageNo = 1;
		int courseId = Integer.parseInt(request.getParameter("courseId"));  // 默认是全部课程
		
		// 调用 serviceImpl 查询当前年份和学习的所有课程的教学班
		List<TeachingClass> teachingClasses = teachingClassServiceImpl.listTeachingClassesByPageAndTeacherIdAndConstraints(pageNo, Page.PageSize, tId, year, term, courseId);
		int totalCount = teachingClassServiceImpl.countTeachingClassesByPageAndTeacherIdAndConstraints(tId, year, term, courseId);
		Page<TeachingClass> page = new Page<TeachingClass>();
		page.setPageNum(pageNo);
		page.setList(teachingClasses);
		page.setPageSize(Page.PageSize);
		page.setTotalCount(totalCount);

		request.setAttribute("page", page);
		request.setAttribute("pageNum", pageNo);
		
		// 表单回显
		request.setAttribute("defaultSelectedYear", year);
		request.setAttribute("defaultSelectedTerm", term);
		request.setAttribute("defaultSelectedcourseId", courseId);
		request.setAttribute("firstPageNum", (pageNo - 1) / 5 * 5 + 1);
		return "ii-teachingClass";
	}
	
	@RequestMapping("/jumpTeachingClassResult")  // 点击上一页，下一页，或者某个具体的页 
	public String jumpMyTeachingClasses(HttpServletRequest request, HttpSession session) throws Exception {
		
		// 获取 teacher
		Teacher teacher = (Teacher) session.getAttribute("user"); 
		String tId = teacher.gettId();
		
		// 设置当前学期和时间
		String year = request.getParameter("year");
		System.out.println("获得的term:" + request.getParameter("term"));
		int term = Integer.parseInt(request.getParameter("term"));
		int pageNo = Integer.parseInt(request.getParameter("pageNum"));
		int courseId = Integer.parseInt(request.getParameter("courseId"));  // 默认是全部课程
		
		// 调用 serviceImpl 查询当前年份和学习的所有课程的教学班
		List<TeachingClass> teachingClasses = teachingClassServiceImpl.listTeachingClassesByPageAndTeacherIdAndConstraints(pageNo, Page.PageSize, tId, year, term, courseId);
		int totalCount = teachingClassServiceImpl.countTeachingClassesByPageAndTeacherIdAndConstraints(tId, year, term, courseId);
		Page<TeachingClass> page = new Page<TeachingClass>();
		page.setPageNum(pageNo);
		page.setList(teachingClasses);
		page.setPageSize(Page.PageSize);
		page.setTotalCount(totalCount);

		request.setAttribute("page", page);
		request.setAttribute("pageNum", pageNo);
		
		// 表单回显
		request.setAttribute("defaultSelectedYear", year);
		request.setAttribute("defaultSelectedTerm", term);
		request.setAttribute("defaultSelectedcourseId", courseId);
		request.setAttribute("firstPageNum", (pageNo - 1) / 5 * 5 + 1);
		return "ii-teachingClass";
	}
}
