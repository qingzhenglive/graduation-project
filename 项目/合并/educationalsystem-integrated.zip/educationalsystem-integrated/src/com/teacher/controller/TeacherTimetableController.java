package com.teacher.controller;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.bean.Teacher;
import com.bean.TeacherTimetable;
import com.teacher.service.CourseServiceImpl;
import com.teacher.service.TeacherTimetableServiceImpl;
import com.teacher.service.TeachingClassServiceImpl;

@Controller
public class TeacherTimetableController {

	@Resource
	private TeachingClassServiceImpl teachingClassServiceImpl; 
	
	@Resource
	CourseServiceImpl courseServiceImpl;
	
	@Resource
	private TeacherTimetableServiceImpl teacherTimetableServiceImpl;
	
	@RequestMapping("/preTeacherTimetable")  // 第一次进入到 teachingClasses
	public String preMyTeachingClasses(HttpServletRequest request, HttpSession session) throws Exception {
		
		// 获取 teacher
		Teacher teacher = (Teacher) session.getAttribute("user"); 
		String tId = teacher.gettId();
		
		// 设置当前学期和时间 (第一次进入默认)  此处应该获得系统时间判断year 和 学期
		String year = "2016-2017"; 
		int term = 1;
		
		List<TeacherTimetable> timetables = teacherTimetableServiceImpl.listTimetablesByTeacherId(tId, year, term);
		
		// 设置默认 
	
		
		List<String[][]> tables = new ArrayList<String[][]>();
		// 一行共有7个元素，每个元素是三元组
		String[][] row1 = new String[7][3];
		String[][] row2 = new String[7][3];
		String[][] row3 = new String[7][3];
		String[][] row4 = new String[7][3];
		String[][] row5 = new String[7][3];
		
		for(TeacherTimetable tt : timetables) {
			int row = calculateRow(tt.getTtTime());
			int col = tt.getTtWeek();
			System.out.println(tt.getTtName() + "应在第" + row +"行，第" + col + "列");
			String[] s = new String[3];  
			s[0] = tt.getTeachingClass().getTcName();     // 课程，地点，时间
			s[1] = tt.getClassroom().getPlace() + " " + tt.getClassroom().getRname();
			s[2] = tt.getTtTime();
			
			if(row == 1) {
				row1[col-1] = s;
			} 
			if(row == 2) {
				row2[col-1] = s;
			} 
			if(row == 3) {
				row3[col-1] = s;
			} 
			if(row == 4) {
				row4[col-1] = s;
			} 
			if(row == 5) {
				row5[col-1] = s;
			} 
		}
		
		tables.add(row1);
		tables.add(row2);
		tables.add(row3);
		tables.add(row4);
		tables.add(row5);
		
		
		request.setAttribute("tables", tables);
		request.setAttribute("defaultSelectedYear", year);
		request.setAttribute("defaultSelectedTerm", term);
		
		return "ii-teacherTimeTable";
	}
	
	@RequestMapping("/selectTeacherTimetable")  // 点击查找按钮 
	public String selectMyTeachingClasses(HttpServletRequest request, HttpSession session) throws Exception {
		
		// 获取 teacher
		Teacher teacher = (Teacher) session.getAttribute("user"); 
		String tId = teacher.gettId();
		
		// 设置当前学期和时间 (第一次进入默认)  此处应该获得系统时间判断year 和 学期
		String year = request.getParameter("year");
		int term = Integer.parseInt(request.getParameter("term"));
		
		List<TeacherTimetable> timetables = teacherTimetableServiceImpl.listTimetablesByTeacherId(tId, year, term);
		
		// 设置默认 
		List<String[][]> tables = new ArrayList<String[][]>();
		// 一行共有7个元素，每个元素是三元组
		String[][] row1 = new String[7][3];
		String[][] row2 = new String[7][3];
		String[][] row3 = new String[7][3];
		String[][] row4 = new String[7][3];
		String[][] row5 = new String[7][3];
		
		for(TeacherTimetable tt : timetables) {
			int row = calculateRow(tt.getTtTime());
			int col = tt.getTtWeek();
			System.out.println(tt.getTtName() + "应在第" + row +"行，第" + col + "列");
			String[] s = new String[3];  
			s[0] = tt.getTeachingClass().getTcName();     // 课程，地点，时间
			s[1] = tt.getClassroom().getPlace() + " " + tt.getClassroom().getRname();
			s[2] = tt.getTtTime();
			
			if(row == 1) {
				row1[col-1] = s;
			} 
			if(row == 2) {
				row2[col-1] = s;
			} 
			if(row == 3) {
				row3[col-1] = s;
			} 
			if(row == 4) {
				row4[col-1] = s;
			} 
			if(row == 5) {
				row5[col-1] = s;
			} 
		}
		
		tables.add(row1);
		tables.add(row2);
		tables.add(row3);
		tables.add(row4);
		tables.add(row5);
		
		request.setAttribute("tables", tables);
		request.setAttribute("defaultSelectedYear", year);
		request.setAttribute("defaultSelectedTerm", term);
		
		return "ii-teacherTimeTable";
	}
	
	public int calculateRow(String time) {
		char a = time.charAt(0);
		char b = time.charAt(1);
		
		if(a == '8') return 1;
		if(a == '9') return 2;
		if(a == '1' && b == '4') return 3;
		if(a == '1' && b == '5') return 4;
		if(a == '1' && b == '9') return 5;
		return 0;
	}
}
