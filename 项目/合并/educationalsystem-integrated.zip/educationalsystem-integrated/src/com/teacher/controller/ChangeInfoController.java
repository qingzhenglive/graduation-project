package com.teacher.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.bean.Teacher;
import com.teacher.service.TeacherServiceImpl;

@Controller
public class ChangeInfoController {

	@Resource
	private TeacherServiceImpl teacherServiceImpl;
	
	@RequestMapping("/changeBasicInfo")
	public String changeTeacherBasicInfo(HttpServletRequest request, HttpSession session) {
		Teacher teacher = (Teacher) session.getAttribute("user");
		String tId = request.getParameter("tId");
		String tname = request.getParameter("tname");
		String gender  = request.getParameter("gender");
		String tnation = request.getParameter("tnation");
		String tbirthday = request.getParameter("tbirthday");
		String tpolitical = request.getParameter("tpolitical");
		String phone = request.getParameter("phone");
		String email = request.getParameter("email");
		String qualification = request.getParameter("qualification");   // 学历
		String degree = request.getParameter("degree");  // 学位
		String title = request.getParameter("title");   // 职称
		String fschool = request.getParameter("fschool");
		String tmajor = request.getParameter("tmajor");
		String teachingInstitute = request.getParameter("teachingInstitute");
		teacher.settId(tId);
		teacher.setTname(tname);
		teacher.setGender(gender);
		teacher.setTnation(tnation);
		teacher.setTbirthday(tbirthday);
		teacher.setTpolitical(tpolitical);
		teacher.setPhone(phone);
		teacher.setEmail(email);
		teacher.setQualification(qualification);
		teacher.setDegree(degree);
		teacher.setTitle(title);
		teacher.setFschool(fschool);
		teacher.setTmajor(tmajor);
		teacher.setTeachingInstitute(teachingInstitute);
		teacherServiceImpl.changeTeacherBasicInfo(teacher);
		return "personalCenter";
	}
	
	
	@RequestMapping("/changePwd")
	public String changeTeacherPwd(HttpServletRequest request, HttpSession session) {
		System.out.println("changeTeacherPwd()...");
		Teacher teacher = (Teacher) session.getAttribute("user");
		String presentPwd = teacher.getPassword();
		String oldPwd = request.getParameter("oldPwd");
		String newPwd = request.getParameter("newPwd");
		String confirmPwd = request.getParameter("confirmPwd");
		
		if(oldPwd.equals(presentPwd) && newPwd.equals(confirmPwd)) {  // 表单合法
			teacher.setPassword(newPwd);
			teacherServiceImpl.changeTeacherBasicInfo(teacher);
		}
		System.out.println("oldPwd:" + oldPwd + "newPwd:" + newPwd + "confirmPwd:" + confirmPwd);
		
		
		return "personalCenter";
	}
	
}
