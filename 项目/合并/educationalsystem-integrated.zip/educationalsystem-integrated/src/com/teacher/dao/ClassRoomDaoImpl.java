package com.teacher.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.bean.Classroom;
import com.teacher.util.BaseDao;

@Repository
public class ClassRoomDaoImpl extends BaseDao<Classroom>{

	public List<Classroom> findAllClassrooms(){
		return super.findAll(Classroom.class);
	}
}
