package com.teacher.dao;

import org.springframework.stereotype.Repository;

import com.bean.Courses;
import com.teacher.util.BaseDao;

@Repository
public class CourseDaoImpl extends BaseDao<Courses>{

	public Courses findCourseById(int id) {
		return super.get(Courses.class, id);
	}
	
}
