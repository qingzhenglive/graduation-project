package com.teacher.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.bean.Teacher;
import com.teacher.util.BaseDao;


@Repository
public class TeacherDaoImpl extends BaseDao<Teacher>{

	public Teacher findTeacherById(String id) {
		return super.get(Teacher.class, id);
	}
	
	
	// 更改基本信息时
	public void updateTeacher(Teacher teacher) {
		super.update(teacher);
	}
	
	public List<Teacher> findTeachersByInstitute(String institute){
		
		String hql = "from Teacher t where t.teachingInstitute = ?";
		
		return super.find(hql, institute);
	}
}
