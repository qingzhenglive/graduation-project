package com.teacher.service;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bean.ResultProportion;
import com.teacher.dao.ResultProportionDaoImpl;

@Service
@Transactional
public class ResultProportionServiceImpl {

	@Resource
	private ResultProportionDaoImpl resultProportionDaoImpl;
	
	public ResultProportion uniResultProportionById(int rpId) {
		return resultProportionDaoImpl.findResultProportionById(rpId);
	}
	
	
	public void changeResultProportion(ResultProportion resultProportion) {
		resultProportionDaoImpl.updataResultProportion(resultProportion);
	}
	
}
