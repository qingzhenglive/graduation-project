package com.teacher.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bean.Student;
import com.teacher.dao.StudentDaoImpl;

@Service
@Transactional
public class StudentServiceImpl {

	
	@Resource
	private StudentDaoImpl studentDaoImpl;
	
	public List<Student> listStudentsByPageAndTeachingClass(int pageNo, int pageSize, int tcId){
		return studentDaoImpl.findStudentsByPageAndTeachingClass(pageNo, pageSize, tcId);
	}
	
	public int countStudentsByTeachingClass(int tcId) throws Exception{
		return studentDaoImpl.findCountStudentsByTeachingClass(tcId);
	}
	
	// 从grade 分页中查找有成绩的学生
	public List<Student> listHasGradeStudentsByPageAndTeachingClass(int pageNo, int pageSize, int tcId) {
		
		return studentDaoImpl.findHasGradeStudentsByPageAndTeachingClass(pageNo, pageSize, tcId);
	}
	
	// 从grade 中计算有成绩的学生的人数
	public int countHasGradeStudentsByTeachingClass(int tcId) throws Exception {
		return studentDaoImpl.findCountHasGradeStudentsByTeachingClass(tcId);
	}
	
	
	// 从grade 分页中查找有成绩的学生
	public List<Student> listHasntGradeStudentsByPageAndTeachingClass(int pageNo, int pageSize, int tcId) {
		
		return studentDaoImpl.findHasntGradeStudentsByPageAndTeachingClass(pageNo, pageSize, tcId);
	}
	
	// 从grade 中计算有成绩的学生的人数
	public int countHasntGradeStudentsByTeachingClass(int tcId) throws Exception {
		return studentDaoImpl.findCountHasntGradeStudentsByTeachingClass(tcId);
	}
	
	public Student uniStudentById(String studentId) throws Exception {
		return studentDaoImpl.findStudentById(studentId);
	}
}
