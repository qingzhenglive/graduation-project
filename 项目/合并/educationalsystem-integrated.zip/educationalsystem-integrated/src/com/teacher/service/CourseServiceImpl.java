package com.teacher.service;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bean.Courses;
import com.teacher.dao.CourseDaoImpl;

@Service
@Transactional
public class CourseServiceImpl {

	@Resource
	private CourseDaoImpl courseDaoImpl;
	
	public Courses uniCourseById(int id) {
		return courseDaoImpl.findCourseById(id);
	}
}
