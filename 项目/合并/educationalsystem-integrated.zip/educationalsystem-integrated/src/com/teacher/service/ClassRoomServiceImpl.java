package com.teacher.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bean.Classroom;
import com.teacher.dao.ClassRoomDaoImpl;

@Service
@Transactional
public class ClassRoomServiceImpl {

	@Resource
	private ClassRoomDaoImpl classRoomDaoImpl;
	
	public List<Classroom> listAllClassRooms(){
		return classRoomDaoImpl.findAllClassrooms();
	}
}
