package com.student.login.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.student.login.service.LoginService;

@Controller
public class LoginController {
	@Resource
	private LoginService LoginService;

	/*
	 * 登录
	 */
	@RequestMapping("/login")
	public String login(@RequestParam(value = "username", required = false) String name,
			@RequestParam(value = "password", required = false) String psw,
			@RequestParam(value = "role", required = false) String role, HttpServletRequest request) {
		HttpSession session = request.getSession();
		int flag = LoginService.isTrueByNameOrPsw(name, psw, role);
		if (flag == 0) {
			
			Object object = LoginService.returnObject(name, role);
			session.setAttribute("user", object);
			session.setAttribute("role", role);
			session.setAttribute("change", 0);
			session.setAttribute("tag", 0);
			session.setMaxInactiveInterval(24*60*1*60);
			session.setAttribute("evaluate", "false");
			if(role.equals("student")) {
				return "jump";
			} else if(role.equals("teacher")) {
				return "personalCenter";
			} else return "undergraduateTable";
			
		} else {
			request.setAttribute("flag", flag);
			return "login";
		}
	}

	/*
	 * 退出登录
	 */
	@RequestMapping("/withdrawlogin")
	public String withdrawLogin(HttpServletRequest request,HttpSession session) {
		session.setAttribute("user", null);
		session.invalidate();
		return "login";
	}
}
