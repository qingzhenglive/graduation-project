package com.student.login.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bean.Job;
import com.bean.Student;
import com.bean.Teacher;
import com.bean.Undergraduate;
import com.student.login.dao.LoginDao;

@Service
@Transactional(readOnly = true)
public class LoginService {

	@Resource
	private LoginDao loginDao;

	/*
	 * 获取用户登录的用户名、密码、角色；判断是否存在相应角色以及密码是否正确 返回值：0代表可以正确登录，1代表用户名不存在，2代表密码错误
	 */
	public int isTrueByNameOrPsw(String username, String password, String role) {
		if (role.equals("student")) {
			// 先判断有没有此学生
			List<Student> list = loginDao.selectBySnum(username);
			if (list.size() == 0)
				return 1;
			else {
				// 判断密码是否正确
				String psw = loginDao.selectPswBySnum(username);
				if (psw.equals(password)) {
					return 0;
				} else {
					return 2;
				}
			}
		} else if (role.equals("teacher")) {
			// 先判断有没有此教师
			List<Teacher> list = loginDao.selectByTnum(username);
			if (list.size() == 0)
				return 1;
			else {
				// 判断密码是否正确
				String psw = loginDao.selectPswByTnum(username);
				if (psw.equals(password)) {
					return 0;
				} else {
					return 2;
				}
			}
		} else {
			int name = Integer.parseInt(username);
			List<Job> list1 = loginDao.selectByJob(name);
			List<Undergraduate> list2 = loginDao.selectByGra(name);
			// 存在此就业学生
			if (list1.size() != 0) {
				String psw = loginDao.selectPswByJob(name);
				if (psw.equals(password)) {
					return 0;
				} else {
					return 2;
				}
			} else if (list2.size() != 0) {
				String psw = loginDao.selectPswByGra(name);
				if (psw.equals(password)) {
					return 0;
				} else {
					return 2;
				}
			} else {
				return 1;
			}
		}

	}

	/*
	 * 返回对象:学生、教师、考研生、就业生
	 */
	public Object returnObject(String username, String role) {
		if (role.equals("student")) {
			List<Student> list = loginDao.selectBySnum(username);
			return list.get(0);
		} else if (role.equals("teacher")) {
			List<Teacher> list = loginDao.selectByTnum(username);
			return list.get(0);
		} else {
			int name = Integer.parseInt(username);
			List<Job> list1 = loginDao.selectByJob(name);
			List<Undergraduate> list2 = loginDao.selectByGra(name);
			if (list1.size() != 0) {
				List<Job> list = loginDao.selectByJob(name);
				return list.get(0);
			}
			if (list2.size() != 0) {
				List<Undergraduate> list = loginDao.selectByGra(name);
				return list.get(0);
			} else {
				return null;
			}
		}

	}
}
