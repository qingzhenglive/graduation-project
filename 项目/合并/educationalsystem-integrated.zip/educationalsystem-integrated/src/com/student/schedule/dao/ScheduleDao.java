package com.student.schedule.dao;

import java.util.List;

import javax.annotation.Resource;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Repository;

import com.bean.Timetable;

@Repository
public class ScheduleDao {

	@Resource
	private SessionFactory sessionFactory;
	
	/*
	 * 查询课表 某个学生 某个年份的某个学期 第几周的课程
	 */
	public List<Timetable> select(String snum,String year,int term,int week){
		Session session=sessionFactory.getCurrentSession();
		Query query=session.createQuery("from Timetable t where t.snum.snum=? and t.year=? and t.cnum.cterm=? and t.week >= ?");
		query.setParameter(0, snum);
		query.setParameter(1, year);
		query.setParameter(2, term);
		query.setParameter(3, week);
		return query.list();
	}
}
