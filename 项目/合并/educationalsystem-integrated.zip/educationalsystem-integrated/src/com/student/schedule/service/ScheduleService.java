package com.student.schedule.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.bean.Timetable;
import com.student.schedule.dao.ScheduleDao;
import com.student.util.GetYearOrTerm;

@Service
public class ScheduleService {

	@Resource
	private ScheduleDao scheduleDao;
	
	/*
	 * 查询某个学生 当前年份的当前学期的第一周课程表
	 */
	public List<Timetable> selectBydefault(String snum){
		String year=GetYearOrTerm.getYear();
		int term =GetYearOrTerm.getTerm();
		return scheduleDao.select(snum, year, term, 1);
	}
	/*
	 * 按照所选要求查询课程表
	 */
	public List<Timetable> selectByRequired(String snum,String year,int term,int week){
		return scheduleDao.select(snum, year, term, week);
	}
}
