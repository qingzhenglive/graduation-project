package com.student.schedule.controller;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.bean.Student;
import com.bean.Timetable;
import com.student.schedule.service.ScheduleService;

@Controller
public class ScheduleController {

	@Resource
	private ScheduleService scheduleService;
	
	/*
	 * 调用默认课表
	 */
	@RequestMapping("/default")
	public String selectDefaultt(HttpServletRequest request,HttpSession session) {
		Student student=(Student) session.getAttribute("user");
		List<Timetable> list=scheduleService.selectBydefault(student.getSnum());
		request.setAttribute("timetable", list);
		return "schedule";
	}
	/*
	 * 调用按照所选要求查出来的课表
	 */
	@RequestMapping("/required")
	public String selectRequired(HttpServletRequest request,HttpSession session,@RequestParam(value="year",required=false)String year,
			@RequestParam(value="term",required=false)int term,@RequestParam(value="week",required=false) int week) {
		Student student=(Student) session.getAttribute("user");
		List<Timetable> list=scheduleService.selectByRequired(student.getSnum(), year, term, week);
		request.setAttribute("timetable", list);
		request.setAttribute("year", year);
		request.setAttribute("term", term);
		request.setAttribute("week", week);
		return "schedule";
	}

}
