package com.student.grade.dao;

import java.util.List;

import javax.annotation.Resource;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Repository;

import com.bean.Grade;

@Repository
public class GradeDao {

	@Resource
	private SessionFactory sessionFactory;
	
	/*
	 * 查询当前学生在 当前学年 当前学期的成绩 
	 */
	public List<Grade> select(String snum,String year,int term){
		Session session=sessionFactory.getCurrentSession();
		Query query=session.createQuery("from Grade g where g.cnum.cnum in(select t.cnum.cnum from Timetable t where t.year=? and t.cnum.cterm=? and t.snum.snum=?)");
		query.setParameter(0, year);
		query.setParameter(1, term);
		query.setParameter(2, snum);
		return query.list();
	}

}
