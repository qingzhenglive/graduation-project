package com.student.grade.service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.bean.Grade;
import com.student.grade.dao.GradeDao;

@Service
public class GradeService {

	@Resource
	private GradeDao gradeDao;
	
	/*
	 * 判断是否查询的当前学年的当前学期的成绩
	 */
	public List<Grade> selectGrade(String snum,String year,int term,String flag){
		SimpleDateFormat sfDateFormat=new SimpleDateFormat("yyyy,MM,dd");
		String format=sfDateFormat.format(new Date());
		String[] str=format.split(",");
		int nowYear=Integer.parseInt(str[0]);//当前的年份
		int nowMonth=Integer.parseInt(str[1]);//当前的月份
		if(nowMonth>=3&&nowMonth<=8) {
			int front=nowYear-1;
			if(term==2&&year.equals(front+"-"+nowYear)) {//当前学年的当前学期
				if(flag.equals("false")) {//没有评价教师
					return null;
				}
				else {//评价了
					List<Grade> list=gradeDao.select(snum, year, term);
					return list;
				}
			}
			else {//其他学期
				List<Grade> list=gradeDao.select(snum, year, term);
				return list;
			}
			
		}else if(nowMonth>=1&&nowMonth<=2) {
			int front=nowYear-1;
			if(term==1&&year.equals(front+"-"+nowYear)) {//当前学年的当前学期
				if(flag.equals("false")) {//没有评价教师
					return null;
				}
				else {//评价了
					List<Grade> list=gradeDao.select(snum, year, term);
					return list;
				}
			}
			else {//其他学期
				List<Grade> list=gradeDao.select(snum, year, term);
				return list;
			}	
		}else{
			int behind=nowYear+1;
			if(term==1&&year.equals(nowYear+"-"+behind)) {//当前学年的当前学期
				if(flag.equals("false")) {//没有评价教师
					return null;
				}
				else {//评价了
					List<Grade> list=gradeDao.select(snum, year, term);
					return list;
				}
			}
			else {//其他学期
				List<Grade> list=gradeDao.select(snum, year, term);
				return list;
			}	
		}
	}

}
