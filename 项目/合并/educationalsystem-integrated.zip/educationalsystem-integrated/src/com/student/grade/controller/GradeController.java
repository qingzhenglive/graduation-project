package com.student.grade.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.bean.Grade;
import com.bean.Student;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.draw.DottedLineSeparator;
import com.student.grade.service.GradeService;

@Controller
public class GradeController {

	@Resource
	private GradeService gradeService;
	private static List<Grade> list=new ArrayList<Grade>();
	// 定义全局的字体静态变量
	private static Font titlefont;
	private static Font headfont;
	private static Font keyfont;
	private static Font textfont;
    // 最大宽度
	private static int maxWidth = 520;
	// 静态代码块
    static {
        try {
            // 不同字体（这里定义为同一种字体：包含不同字号、不同style）
            BaseFont bfChinese = BaseFont.createFont("STSong-Light", "UniGB-UCS2-H", BaseFont.NOT_EMBEDDED);
            titlefont = new Font(bfChinese, 16, Font.BOLD);
            headfont = new Font(bfChinese, 14, Font.BOLD);
            keyfont = new Font(bfChinese, 10, Font.BOLD);
            textfont = new Font(bfChinese, 10, Font.NORMAL);
 
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    /**
     * 创建单元格(指定字体)
     * @param value
     * @param font
     * @return
     */
    public PdfPCell createCell(String value, Font font) {
        PdfPCell cell = new PdfPCell();
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setPhrase(new Phrase(value, font));
        return cell;
    }
    /**
     * 创建单元格（指定字体、水平..）
     * @param value
     * @param font
     * @param align
     * @return
     */
	public PdfPCell createCell(String value, Font font, int align) {
		PdfPCell cell = new PdfPCell();
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setHorizontalAlignment(align);
		cell.setPhrase(new Phrase(value, font));
		return cell;
	}
	 /**
     * 创建单元格（指定字体、水平居..、单元格跨x列合并、设置单元格内边距）
     * @param value
     * @param font
     * @param align
     * @param colspan
     * @param boderFlag
     * @return
     */
    public PdfPCell createCell(String value, Font font, int align, int colspan, boolean boderFlag) {
        PdfPCell cell = new PdfPCell();
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.setHorizontalAlignment(align);
        cell.setColspan(colspan);
        cell.setPhrase(new Phrase(value, font));
        cell.setPadding(3.0f);
        if (!boderFlag) {
            cell.setBorder(0);
            cell.setPaddingTop(15.0f);
            cell.setPaddingBottom(8.0f);
        } else if (boderFlag) {
            cell.setBorder(0);
            cell.setPaddingTop(0.0f);
            cell.setPaddingBottom(15.0f);
        }
        return cell;
    }
    /**
     * 创建指定列宽、列数的表格
     * @param widths
     * @return
     */
	public PdfPTable createTable(float[] widths) {
		PdfPTable table = new PdfPTable(widths);//参数为列数
		try {
			table.setTotalWidth(maxWidth);//表格的宽度
			table.setLockedWidth(true);//锁住宽度
			table.setHorizontalAlignment(Element.ALIGN_CENTER);//表格水平居中
			table.getDefaultCell().setBorder(1);//设置表格的默认边框
		} catch (Exception e) {
			e.printStackTrace();
		}
		return table;
	}
	 // 生成PDF文件
	public void generatePDF(Document document,HttpSession session) throws Exception {
		Student student=(Student) session.getAttribute("user");
    	// 段落
		Paragraph paragraph = new Paragraph(""+student.getSname()+"的成绩单！", titlefont);
		paragraph.setAlignment(1); //设置文字居中 0靠左   1，居中     2，靠右
		paragraph.setIndentationLeft(12); //设置左缩进
		paragraph.setIndentationRight(12); //设置右缩进
		paragraph.setFirstLineIndent(24); //设置首行缩进
		paragraph.setLeading(20f); //行间距
		paragraph.setSpacingBefore(5f); //设置段落上空白
		paragraph.setSpacingAfter(10f); //设置段落下空白

 
		// 点线
		Paragraph p2 = new Paragraph();
		p2.add(new Chunk(new DottedLineSeparator()));
 
		// 添加图片
		Image image = Image.getInstance("http://localhost:8081/educationalsystem/image/ruanjian.jpg");
		image.setAlignment(Image.ALIGN_CENTER);
		image.scalePercent(40); //依照比例缩放
 
		// 表格
		PdfPTable table = createTable(new float[] { 60, 60, 60, 60, 60, 60, 60});//参数为表格每一列的宽度
		table.addCell(createCell("成绩单", headfont, Element.ALIGN_LEFT, 7, false));
		table.addCell(createCell("课程名称", keyfont, Element.ALIGN_CENTER));
		table.addCell(createCell("课程性质", keyfont, Element.ALIGN_CENTER));
		table.addCell(createCell("成绩", keyfont, Element.ALIGN_CENTER));
		table.addCell(createCell("学分", keyfont, Element.ALIGN_CENTER));
		table.addCell(createCell("绩点", keyfont, Element.ALIGN_CENTER));
		table.addCell(createCell("开课学院", keyfont, Element.ALIGN_CENTER));
		table.addCell(createCell("开课教师", keyfont, Element.ALIGN_CENTER));
		Integer totalQuantity = 0;
		for (int i = 0; i < list.size(); i++) {
			table.addCell(createCell(list.get(i).getCnum().getCname(), textfont));
			table.addCell(createCell(list.get(i).getCnum().getType(), textfont));
			table.addCell(createCell(String.valueOf(list.get(i).getScore()), textfont));
			table.addCell(createCell(String.valueOf(list.get(i).getCnum().getCredit()), textfont));
			table.addCell(createCell(String.valueOf(list.get(i).getPoint()), textfont));
			table.addCell(createCell(list.get(i).getTnum().getTeachingInstitute(), textfont));
			table.addCell(createCell(list.get(i).getTnum().getTname(), textfont));
			totalQuantity ++;
		}
		table.addCell(createCell("总计", keyfont));
		table.addCell(createCell(String.valueOf(totalQuantity) + "项成绩", textfont));
		table.addCell(createCell("", textfont));
		table.addCell(createCell("", textfont));
		table.addCell(createCell("", textfont));
		table.addCell(createCell("", textfont));
		table.addCell(createCell("", textfont));
 
		document.add(paragraph);//添加段落
		document.add(p2);//添加点线
		document.add(table);//添加表格
		document.add(image);//添加图片
	}
 
	@RequestMapping("/grade")
	public String selectGrade(HttpServletRequest request,@RequestParam(value="year",required=false) String year,@RequestParam(value="term",required=false)String term,
			HttpSession session,HttpServletResponse response) throws IOException {
		if(year.equals("null")||term.equals("null")) {
			return "grade";
		}
		else {
			String flag=(String) session.getAttribute("evaluate");
			Student student=(Student) session.getAttribute("user");
			int afTerm=Integer.parseInt(term);
			System.out.println(student.getSnum());
			System.out.println(year);
			System.out.println(afTerm);
			System.out.println(flag);
			list=gradeService.selectGrade(student.getSnum(), year, afTerm, flag);
			if(list!=null) {
				session.setAttribute("year", year);
				session.setAttribute("term", afTerm);
				session.setAttribute("grade", list);
				return "grade";
			}
			else {
				response.getWriter()
				.write("<script>alert('Please evaluate the teacher first'); window.location='index.jsp' ;window.close();</script>");
				response.getWriter().flush();
				return "evaluate";
			}
		}
		
	}
	
	@RequestMapping("/pdfgrade")
	public String pdfGrade(HttpServletRequest request,HttpSession session) throws Exception {
		 // 1.新建document对象
        Document document = new Document(PageSize.A4);// 建立一个Document对象

        // 2.建立一个书写器(Writer)与document对象关联
        File file = new File("D:\\成绩单.pdf");
        file.createNewFile();
        PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(file));
      

        // 3.打开文档
        document.open();
		document.addTitle("Title@PDF-Java");// 标题
		document.addAuthor("Author@umiz");// 作者
		document.addSubject("Subject@iText pdf sample");// 主题
		document.addKeywords("Keywords@iTextpdf");// 关键字
		document.addCreator("Creator@umiz`s");// 创建者
		list=(List<Grade>) session.getAttribute("grade");
        // 4.向文档中添加内容
		if(list.size()!=0) {
		new GradeController().generatePDF(document,session);
		}

        // 5.关闭文档
        document.close();
		return "grade";
	}
	
	
}
