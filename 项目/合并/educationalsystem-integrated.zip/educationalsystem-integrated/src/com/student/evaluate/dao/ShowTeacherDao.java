package com.student.evaluate.dao;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Repository;

import com.bean.Evaluate;
import com.bean.Teacher;


@Repository
public class ShowTeacherDao {

	@Resource
	private SessionFactory sessionFactory;
	
	/*
	 * 查找评价页面中 当前学生在当前年份 当前学期要评价的教师
	 */
	public List<Teacher> select(String snum,String year,int term) {
		//要获取当前系统的时间
		Session session=sessionFactory.getCurrentSession();
		Query query=session.createQuery("select t.tnum.tId from Timetable t where t.year=? and t.cnum.cterm=? and t.snum.snum=?");
		query.setParameter(0, year);
		query.setParameter(1, term);
		query.setParameter(2, snum);
		List<Teacher> list=new ArrayList<Teacher>();
		for(int i=0;i<query.list().size();i++) {
			Query query2=session.createQuery("from Teacher t where t.tId=?");
			query2.setParameter(0, query.list().get(i));
			list.add((Teacher) query2.uniqueResult());
		}
		return list;
	}
	
	/* 
	 * 向评价表中插入评分数据
	 */
	public void save(Evaluate evaluate) {
		Session session=sessionFactory.getCurrentSession();
		session.save(evaluate);
		
	}
	
	public Teacher getTeacher(String tId) {
		Session session=sessionFactory.getCurrentSession();
		Query query=session.createQuery("from Teacher t where t.tId=?");
		query.setParameter(0, tId);
		return (Teacher) query.uniqueResult();
	}

}
