package com.student.evaluate.controller;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.bean.Student;
import com.bean.Teacher;
import com.student.evaluate.service.ShowTeacherService;

@Controller
public class ShowTeacherController {

	@Resource
	private ShowTeacherService showTeacherService;
	
	@RequestMapping("/teacher")
	public String selectTName(HttpServletRequest request,HttpSession session) {
		Student student=(Student) session.getAttribute("user");
		List<Teacher> list=showTeacherService.selectTeacher(student.getSnum());
		int size=list.size();
		request.getSession().setAttribute("list", list);
		request.getSession().setAttribute("size", size);
		return "evaluate";
	}

}
