package com.student.evaluate.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class CheckScoreController {

	/*
	 * 检查是否为10分制
	 */
	@SuppressWarnings("null")
	@RequestMapping("/check")
	public void checkScore(@RequestParam(value = "score", required = false) String score, HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		PrintWriter out=response.getWriter();
		int grade = 0;
		if(score !=null || !(score.equals(""))) {
			grade = Integer.parseInt(score);
			if (grade < 0 || grade > 10) {
				out.print("false");			
			} else {
				out.print("true");
				
			}
		} 
	    
	}

}
