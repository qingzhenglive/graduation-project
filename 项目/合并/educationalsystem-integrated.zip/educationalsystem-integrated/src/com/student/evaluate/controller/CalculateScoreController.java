package com.student.evaluate.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.bean.Evaluate;
import com.bean.Student;
import com.bean.Teacher;
import com.student.evaluate.service.ShowTeacherService;

@Controller
public class CalculateScoreController {

	@Resource
	private ShowTeacherService showTeacherService;
	//记录已经评价了的教师数量
	private static int sizeTeacher=0;
	
	/*
	 * 计算评价总分 并插入到表中
	 */
	@RequestMapping("/calculatesum")
	public String calculateScore(@RequestParam(value="teacher",required=false)String tId,@RequestParam(value="one",required=false)int one,
			@RequestParam(value="two",required=false)int two,@RequestParam(value="there",required=false)int there,@RequestParam(value="four",required=false)int four,
			@RequestParam(value="five",required=false)int five,@RequestParam(value="six",required=false)int six,@RequestParam(value="seven",required=false)int seven,
			@RequestParam(value="eight",required=false)int eight,@RequestParam(value="nine",required=false)int nine,@RequestParam(value="ten",required=false)int ten,
			HttpSession session) {
		Teacher teacher=showTeacherService.get(tId);
		Evaluate evaluate=new Evaluate();
		Student student=(Student)session.getAttribute("user");
		evaluate.setSnum(student);
		evaluate.setTnum(teacher);
		int sum=one+two+there+four+five+six+seven+eight+nine+ten;
		evaluate.setScore(sum);
		showTeacherService.saveEvaluate(evaluate);	
		Integer length=(Integer) session.getAttribute("size");
		sizeTeacher++;
		if(sizeTeacher==length) {
			session.setAttribute("evaluate", "true");
		}
		return "evaluate";
	}
}
