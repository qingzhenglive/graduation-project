package com.student.evaluate.service;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.bean.Evaluate;
import com.bean.Teacher;
import com.student.evaluate.dao.ShowTeacherDao;
import com.student.util.GetYearOrTerm;

@Service
public class ShowTeacherService {

	@Resource
	private ShowTeacherDao showTeacherDao;
	
	/*
	 * 调用查找教师的方法
	 */
	public List<Teacher> selectTeacher(String snum){
		//获取系统的当前学年 当前学期
		String year=GetYearOrTerm.getYear();
		int term=GetYearOrTerm.getTerm();
		List<Teacher> list=showTeacherDao.select(snum,year,term);
		return list;
	}
	/*
	 * 调用插入评分对象的方法
	 */
	public void saveEvaluate(Evaluate evaluate) {
		showTeacherDao.save(evaluate);
	}
	
	public Teacher get(String tId) {
		return showTeacherDao.getTeacher(tId);
	}
}
