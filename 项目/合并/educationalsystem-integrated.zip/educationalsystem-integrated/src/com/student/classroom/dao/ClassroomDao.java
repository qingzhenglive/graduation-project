package com.student.classroom.dao;

import java.util.List;

import javax.annotation.Resource;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Repository;

import com.bean.Classroom;

@Repository
public class ClassroomDao {

	@Resource
	private SessionFactory sessionFactory;
	
	/*
	 * 思路：先查询周次=“” 星期 =“” 时间in('' '') 在从教室表中排除即可
	 */
	
	public List<Classroom> select(int week,int day,String time){
		Session session=sessionFactory.getCurrentSession();
		Query query=session.createQuery("from Classroom c where c.rnum not in(select t.rnum from Timetable t where t.week>=? and t.day=? and t.time in(?,?))");
		query.setParameter(0, week);
		query.setParameter(1, day);
		if(time.equals("8:00-9:30")) {
			query.setParameter(2, "8:00-9:30");
			query.setParameter(3, "8:00-9:30");
		}
		if(time.equals("9:45-12:10")) {
			query.setParameter(2, "9:45-11:15");
			query.setParameter(3, "9:45-12:05");
		}
		if(time.equals("14:00-16:20")) {
			query.setParameter(2, "14:00-15:30");
			query.setParameter(3, "14:00-16:20");
		}
		if(time.equals("15:45-18:10")) {
			query.setParameter(2, "15:45-17:15");
			query.setParameter(3, "15:45-18:05");
		}
		if(time.equals("19:00-22:00")) {
			query.setParameter(2, "19:00-20:30");
			query.setParameter(3, "19:00-21:20");
		}
		return query.list();
	}

}
