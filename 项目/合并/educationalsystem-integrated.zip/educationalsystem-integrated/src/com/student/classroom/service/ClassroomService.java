package com.student.classroom.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.bean.Classroom;
import com.student.classroom.dao.ClassroomDao;

@Service
public class ClassroomService {
	
	@Resource
	private ClassroomDao classroomDao;

	/*
	 * 调用查询空闲教室的方法
	 */
	
	public List<Classroom> selectClassroom(int week,int day,String time){
		return classroomDao.select(week, day, time);
	}
}
