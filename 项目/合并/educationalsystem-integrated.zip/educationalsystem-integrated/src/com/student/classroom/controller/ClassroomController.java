package com.student.classroom.controller;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.bean.Classroom;
import com.student.classroom.service.ClassroomService;

@Controller
public class ClassroomController {

	@Resource
	private ClassroomService classroomService;
	
	@RequestMapping("/classroom")
	public String selectClassroom(HttpServletRequest request,@RequestParam(value="week",required=false) String week,@RequestParam(value="day",required=false) String day,
			@RequestParam(value="time",required=false)String time) {
		if(week.equals("null")||day.equals("null")||time.equals("null")) {
			return "classroom";
		}else {
			int afWeek=Integer.parseInt(week);
			int afDay=Integer.parseInt(day);
			List<Classroom>list=classroomService.selectClassroom(afWeek, afDay, time);
			request.setAttribute("listRoom", list);
			request.setAttribute("week", week);
			request.setAttribute("day", day);
			request.setAttribute("time", time);
			return "classroom";	
		}
	}

}
