package com.student.personal.dao;

import java.util.List;

import javax.annotation.Resource;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Repository;

import com.bean.Grade;

@Repository
public class ChangePhoneDao {

	@Resource
	private SessionFactory sessionFactory;
	
	/*
	 *更新学生表的联系方式
	 */
	
	public void update(String snum,String phone) {
		Session session=sessionFactory.getCurrentSession();
		Query query=session.createQuery("update Student set phone=? where snum=?");
		query.setParameter(0, phone);
		query.setParameter(1, snum);
		query.executeUpdate();
	}
	/*
	 * 根据学生的用户名查找密码
	 */
	public String select(String snum) {
		Session session=sessionFactory.getCurrentSession();
		Query query =session.createQuery("select stu.psw from Student stu where stu.snum=?");
		query.setParameter(0, snum);
		return (String) query.uniqueResult();
	}
	/*
	 * 更新密码
	 */
	public void updatePsw(String snum,String psw) {
		Session session=sessionFactory.getCurrentSession();
		Query query=session.createQuery("update Student set psw=? where snum=?");
		query.setParameter(0, psw);
		query.setParameter(1, snum);
		query.executeUpdate();
	}
	
	/*
	 * 在成绩表中查询当前用户的信息、用于计算加权、绩点
	 */
	@SuppressWarnings("unchecked")
	public List<Grade> selectPoint(String snum){
		Session session=sessionFactory.getCurrentSession();
		Query query=session.createQuery("from Grade g where g.snum.snum=?");
		query.setParameter(0, snum);
		return query.list();
	}
}
