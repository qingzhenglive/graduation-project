package com.student.personal.controller;

import java.io.IOException;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.bean.Student;
import com.student.personal.service.ChangePhoneService;

@Controller
public class ChangePhoneController {

	@Resource
	private ChangePhoneService changePhoneService;
	
	/*
	 * 更新学生联系方式
	 */
	@RequestMapping("/changePhone")
	public String change(@RequestParam(value="phone",required=false) String phone,HttpServletRequest request,HttpServletResponse response) throws IOException {
		Student student=(Student) request.getSession().getAttribute("user");
		String snum=student.getSnum();
		changePhoneService.changePhone(snum, phone);
		request.getSession().setAttribute("phone", phone);
		request.getSession().setAttribute("change", 1);
		return "personal";
	}

}
