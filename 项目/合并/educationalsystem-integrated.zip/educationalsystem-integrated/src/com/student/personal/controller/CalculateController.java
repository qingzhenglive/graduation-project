package com.student.personal.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.bean.Student;
import com.student.personal.service.ChangePhoneService;

@Controller
public class CalculateController {

	@Resource
	private ChangePhoneService changePhoneService;
	
	@RequestMapping("/calculate")
	public String calculate(HttpServletRequest request,HttpSession session) {
		Student student=(Student) session.getAttribute("user");
		System.out.println(student.getSnum());
		float weight=changePhoneService.calculateWeight(student.getSnum());
		float point=Math.round((changePhoneService.calculatePoint(student.getSnum()))*100)/100;
		request.getSession().setAttribute("weight", weight);
		request.getSession().setAttribute("point", point);
		return "personal";
	}
}
