package com.student.personal.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bean.Grade;
import com.student.personal.dao.ChangePhoneDao;

@Service
@Transactional(readOnly = false)
public class ChangePhoneService {

	@Resource
	private ChangePhoneDao changePhoneDao;
	
	/*
	 * 调用更新联系方式的方法
	 */
	public void changePhone(String snum,String phone) {
		changePhoneDao.update(snum, phone);
	}
	
	/*
	 * 调用返回用户名的方法
	 */
	public String selectPswBySnum(String snum) {
		return changePhoneDao.select(snum);
	}
	/*
	 * 调用更新密码的方法
	 */
	public void changePsw(String snum,String psw) {
		changePhoneDao.updatePsw(snum, psw);
	}
	
	/*
	 * 计算加权平均分
	 */
	
	public float calculateWeight(String snum) {
		float sum=0;//计算总学分
		float weight;//计算加权平均分
		float sumScore=0;//加权平均分中的 成绩*学分 之和
		List<Grade> list=changePhoneDao.selectPoint(snum);
		for(int i=0;i<list.size();i++) {
			Grade grade=list.get(i);
			sum+=grade.getCnum().getCredit();
			sumScore+=grade.getCnum().getCredit()*grade.getScore();
		}
		weight=sumScore/sum;
		return weight;
	}
	
	/*
	 * 计算绩点
	 */
	public float calculatePoint(String snum) {
		float sum=0;//计算总学分
		float point=0;//计算绩点
		float sumScore=0;//计算学分*绩点之和
		List<Grade> list=changePhoneDao.selectPoint(snum);
		for(int i=0;i<list.size();i++) {
			Grade grade=list.get(i);
			sum+=grade.getCnum().getCredit();
			sumScore+=grade.getCnum().getCredit()*grade.getPoint();
		}
		point=sumScore/sum;
		return point;
	}
}
