package com.student.course.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.bean.Option;
import com.bean.Page;
import com.bean.Student;
import com.student.course.service.CourseService;

@Controller
public class CourseController {
	@Resource
	private CourseService courseService;

	/**
	 * 
	 *@desc:展示可供选择的专业选修和必修课程
	 *@param request
	 *@param pageNum
	 *@param session
	 *@return
	 *@return:String
	 *@trhows
	 */
	@RequestMapping("/optional")
	public String selectOptional(HttpServletRequest request,@RequestParam(value="pageNum",required=false)String pageNum,HttpSession session) {
		int number=0;
		if(pageNum==null||pageNum.equals("")) {
			number=1;
		}else {
			number=Integer.parseInt(pageNum);
		}
		Student student=(Student) session.getAttribute("user");
		List<Option> list=courseService.findselectedAndRebuild(student.getSnum());
		Page<Option> page=new Page<>(list.size(), number);
		page.setList(list);
		page.setPrePageNum(number-1);
		page.setNextPageNum(number+1);
		request.setAttribute("tag", 1);
		session.setAttribute("page", page);
		return "course";
	}

	/**
	 * 
	 *@desc:展示已经选择了的课程
	 *@param request
	 *@return
	 *@return:String
	 *@trhows
	 */
	@RequestMapping("/already")
	public String withdrawAlready(HttpServletRequest request,HttpSession session,@RequestParam(value="pageNum",required=false)String pageNum) {
		int number=0;
		if(pageNum==null||pageNum.equals("")) {
			number=1;
		}else {
			number=Integer.parseInt(pageNum);
		}
		Student student=(Student) session.getAttribute("user");
		List<Option> list=courseService.findAlreadyCourse(student.getSnum());
		Page<Option> page=new Page<>(list.size(), number);
		page.setList(list);
		page.setPrePageNum(number-1);
		page.setNextPageNum(number+1);
		request.setAttribute("tag", 2);
		request.setAttribute("page", page);
		return "course";
	}
	
	/**
	 * 
	 *@desc:ajax检查学生选课是否冲突
	 *@param request
	 *@param list
	 *@return
	 *@return:String
	 * @throws IOException 
	 *@trhows
	 */
	@RequestMapping("/checkConflict")
	public void test(HttpServletRequest request,@RequestParam(value="choose",required=false) Option option,HttpSession session,HttpServletResponse response) throws IOException {
		Student student=(Student) session.getAttribute("user");
		System.out.println("执行冲突检测");
		boolean flag=courseService.checkIsConflict(student.getSnum(), option.getDay(), option.getTime());
		PrintWriter out=response.getWriter();
		if(flag==true) {
			out.print(true);
		}else {
			out.print(false);
		}
	}
	
	/**
	 * 
	 *@desc:将选的课插入到学生课表
	 *@return
	 *@return:String
	 *@trhows
	 */
	@RequestMapping("/insertTimetable")
	public String insertTimatable(HttpServletRequest request,HttpSession session,@RequestParam(value="choose",required=false)String[] list) {
		Student student=(Student) session.getAttribute("user");
		List<Option> listOptions=new ArrayList<Option>();
		for(int i=0;i<list.length;i++) {
			int id=Integer.parseInt(list[i]);
			Option option=courseService.getOption(id);
			listOptions.add(option);
		}
		courseService.insertTimetable(student.getSnum(), listOptions);
		return "course";
	}
	
	/**
	 * 退选 将选课信息从学生课表删除
	 */
	@RequestMapping("/deleteTimetable")
	public String deleteTimetable(HttpServletRequest request,HttpSession session,@RequestParam(value="choose",required=false)String[] list) {
		for(int i=0;i<list.length;i++) {
			int id=Integer.parseInt(list[i]);
			courseService.deleteTimetable(id);
		}
	
		return "course";
	}

}
