package com.student.course.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.bean.Option;
import com.bean.TeacherTimetable;
import com.bean.TeachingClass;
import com.bean.Timetable;
import com.student.course.dao.CourseDao;
import com.student.util.GetYearOrTerm;

@Service
public class CourseService {

	@Resource
	private CourseDao courseDao;
	
	/**
	 * 
	 *@desc:将查到的选课信息封装成list
	 *@param snum
	 *@return
	 *@return:List<Option>
	 *@trhows
	 */
	public List<Option> findselectedAndRebuild(String snum){
		//获取系统的当前学年 当前学期
		String year=GetYearOrTerm.getYear();
		int term =GetYearOrTerm.getTerm();
		//往list<Option>存数据
		List<Option> list=new ArrayList<Option>();
		List<TeachingClass> list1=courseDao.findSelected(year, term);
		List<TeachingClass> list2=courseDao.findRebuild(snum, year, term);
		int i,j;
		for(i=0;i<list1.size();i++) {
			TeachingClass teachingClass=list1.get(i);
			Set<TeacherTimetable> teacherSet=teachingClass.getTeacherTimeTables();
			for(TeacherTimetable tt: teacherSet) {
				Option option=new Option();
				option.setCourse(teachingClass.getCourse());
				option.setTeacher(teachingClass.getTeacher());		
				option.setSelectedNumber(teachingClass.getTcpNum());
				option.setSum(teachingClass.getTcCapacity());
				option.setWeek(teachingClass.getTeachingSchedule().getDuration());
				option.setDay(tt.getTtWeek());
				option.setTime(tt.getTtTime());
				option.setClassroom(tt.getClassroom());
				option.setTeachingClass(teachingClass);
				list.add(option);
			}
			
		}
		for(j=0;j<list2.size();j++) {
			TeachingClass teachingClass=list2.get(j);
			Set<TeacherTimetable> teacherSet=teachingClass.getTeacherTimeTables();
			for(TeacherTimetable tt: teacherSet) {
				Option option=new Option();
				option.setCourse(teachingClass.getCourse());
				option.setTeacher(teachingClass.getTeacher());		
				option.setSelectedNumber(teachingClass.getTcpNum());
				option.setSum(teachingClass.getTcCapacity());
				option.setWeek(teachingClass.getTeachingSchedule().getDuration());
				option.setDay(tt.getTtWeek());
				option.setTime(tt.getTtTime());
				option.setClassroom(tt.getClassroom());
				option.setTeachingClass(teachingClass);
				list.add(option);
			}
		}
		//把可选记录存到option表中
		for(int m=0;m<list.size();m++) {
			courseDao.save(list.get(m));
		}
		
		return list;
	}
	/**
	 * 
	 *@desc:检查是否冲突
	 *@param snum
	 *@param day
	 *@param time
	 *@return
	 *@return:boolean：true 代表冲突；false代表不冲突
	 *@trhows
	 */
	public boolean checkIsConflict(String snum,int day,String time) {
		//获取系统的当前学年 当前学期
		String year=GetYearOrTerm.getYear();
		int term =GetYearOrTerm.getTerm();
		List<Timetable> list=courseDao.select(snum, year, term, day, time);
		if(list.size()==0) {
			return false;
		}else {
			return true;
		}
	}
	/**
	 * 
	 *@desc:将选课插入到学生课表
	 *@param snum
	 *@param list
	 *@param year 当前学年
	 *@return:void
	 *@trhows
	 */
	public void insertTimetable(String snum,List<Option> list) {
		//获取系统的当前学年 当前学期
		String year=GetYearOrTerm.getYear();
		for(int i=0;i<list.size();i++) {
			Timetable timetable=new Timetable();
			Option option=list.get(i);
			timetable.setSnum(courseDao.findStudent(snum));
			timetable.setCnum(option.getCourse());
			timetable.setTnum(option.getTeacher());
			timetable.setDay(option.getDay());
			timetable.setTime(option.getTime());
			timetable.setWeek(option.getWeek());
			timetable.setRnum(option.getClassroom());
			timetable.setTcId(option.getTeachingClass());
			timetable.setYear(year);
			courseDao.saveTimetable(timetable);
		}
		
	}
	/**
	 * 
	 *@desc:返回选课信息
	 *@param snum
	 *@return
	 *@return:List<Option>
	 *@trhows
	 */
	public List<Option> findAlreadyCourse(String snum){
		//获取系统的当前学年 当前学期
		String year=GetYearOrTerm.getYear();
		List<Option> options=new ArrayList<Option>();
		List<Timetable> list=courseDao.findAlready(snum, year);
		for(int i=0;i<list.size();i++) {
			Timetable timetable=list.get(i);
			Option option=new Option();
			option.setId(timetable.getId());
			option.setCourse(timetable.getCnum());
			option.setTeacher(timetable.getTnum());
			option.setWeek(timetable.getWeek());
			option.setDay(timetable.getDay());
			option.setTime(timetable.getTime());
			option.setClassroom(timetable.getRnum());
			option.setTeachingClass(timetable.getTcId());
			options.add(option);
		}
		return options;
	}
	/**
	 * 
	 *@desc:删除某些选课信息
	 *@param snum
	 *@param list
	 *@return:void
	 *@trhows
	 */
	public void deleteTimetable(int id ) {
		//获取系统的当前学年 当前学期
		courseDao.deleteTimetable(id);
	
	}
	
	public Option getOption(int id) {
		return courseDao.selectOption(id);
	}
}
