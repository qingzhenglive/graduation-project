package com.student.course.dao;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Repository;

import com.bean.Evaluate;
import com.bean.Option;
import com.bean.Student;
import com.bean.TeachingClass;
import com.bean.Timetable;

@Repository
public class CourseDao {

	@Resource
	private SessionFactory sessionFactory;
	
	/**
	 * 
	 *@desc:查询可以选择的专业选修课程
	 *@param year
	 *@param term
	 *@return
	 *@return:List<TeachingClass>
	 *@trhows
	 */
	public List<TeachingClass> findSelected(String year,int term){
		Session session=sessionFactory.getCurrentSession();
		Query query1=session.createQuery("from TeachingClass t where t.tcpNum < t.tcCapacity and  t.course.cnum in "
				+ "(select ts.course.cnum from TeachingSchedule ts where ts.tYear=? and ts.course.cterm=? and ts.course.type=?)");
		query1.setParameter(0, year);
		query1.setParameter(1, term);
		query1.setParameter(2, "选修");
		query1.setFirstResult(0);
		query1.setMaxResults(4);
		return query1.list();
	}
	/**
	 * 
	 *@desc:查询可以重修的必修课程
	 *@param snum
	 *@param year
	 *@param term
	 *@return
	 *@return:List<TeachingClass>
	 *@trhows
	 */
	public List<TeachingClass> findRebuild(String snum,String year,int term){
		Session session=sessionFactory.getCurrentSession();
		Query query2=session.createQuery("from TeachingClass t where t.teachingSchedule.tYear=? and t.tcpNum < t.tcCapacity and t.containRetake=? and t.course.cnum in"
				+ "(select g.cnum.cnum from Grade g where g.type=? and g.cnum.cterm=? and g.snum.snum=?)");
		query2.setParameter(0, year);
		query2.setParameter(1, 1);
		query2.setParameter(2, "不合格");
		query2.setParameter(3, term);
		query2.setParameter(4, snum);
		query2.setFirstResult(0);
		query2.setMaxResults(4);
		return query2.list();
	}
	/**
	 * 
	 *@desc:检查某个学生在当前学年的当前学期的某个具体的课表安排，用于判断是否冲突
	 *@param snum
	 *@param year
	 *@param term
	 *@param day
	 *@param time
	 *@return
	 *@return:List<Timetable>
	 *@trhows
	 */
	public List<Timetable> select(String snum,String year,int term,int day,String time){
		Session session=sessionFactory.getCurrentSession();
		Query query=session.createQuery("from Timetable t where t.snum.snum=? and t.year=? and t.cnum.cterm=? and t.day=? and t.time=?");
		query.setParameter(0, snum);
		query.setParameter(1, year);
		query.setParameter(2, term);
		query.setParameter(3, day);
		query.setParameter(4, time);
		return query.list();
	}
	/**
	 * 
	 *@desc:将选课插入到学生课表
	 *@param timetable
	 *@return:void
	 *@trhows
	 */
	public void saveTimetable(Timetable timetable) {
		Session session=sessionFactory.getCurrentSession();
		session.save(timetable);
	}
	
	public Student findStudent(String snum) {
		Session session=sessionFactory.getCurrentSession();
		Query query=session.createQuery("from Student s where s.snum=?");
		query.setParameter(0, snum);
		return (Student) query.uniqueResult();
	}
	
	/**
	 * 
	 *@desc:删除某条选课信息:这个方法没用
	 *@param snum
	 *@param tnum
	 *@param cnum
	 *@param day
	 *@param time
	 *@return:void
	 *@trhows
	 */
    public void delete(String snum,String tnum,int cnum,int day ,String time,String year) {
    	Session session=sessionFactory.getCurrentSession();
    	Query query=session.createQuery("delete from Timetable t where t.snum.snum=? and t.tnum.tnum=? and t.cnum.cnum=? and t.day=? and t.time=? and t.year=?" );
    	query.setParameter(0, snum);
    	query.setParameter(1, tnum);
    	query.setParameter(2, cnum);
    	query.setParameter(3, day);
    	query.setParameter(4, time);
    	query.setParameter(5, time);
    	query.executeUpdate();
    }
    public void deleteTimetable(int id) {
    	Session session=sessionFactory.getCurrentSession();
    	Query query=session.createQuery("delete from Timetable t where t.id=?");
    	query.setParameter(0, id);
    	query.executeUpdate();
    }
    /**
     * 
     *@desc:查找学生刚刚的选课信息
     *@param snum
     *@param year
     *@return
     *@return:List<Timetable>
     *@trhows
     */
   public List<Timetable> findAlready(String snum,String year){
	   List<Timetable> list=new ArrayList<Timetable>();
	   Session session=sessionFactory.getCurrentSession();
	   Query query1=session.createQuery("from Timetable t where t.snum.snum=? and t.year=? and t.cnum.type=?");
	   query1.setParameter(0, snum);
	   query1.setParameter(1, year);
	   query1.setParameter(2, "选修");
	   Query query2=session.createQuery("from Timetable t where t.snum.snum=? and t.year=? and t.cnum.type=? and t.tcId.containRetake=?");
	   query2.setParameter(0, snum);
	   query2.setParameter(1, year);
	   query2.setParameter(2, "必修");
	   query2.setParameter(3, 1);
	   for(int i=0;i<query1.list().size();i++) {
		   list.add((Timetable) query1.list().get(i));
	   }
	   for(int i=0;i<query2.list().size();i++) {
		   list.add((Timetable) query2.list().get(i));
	   }
	   return list;
   }
   
	/* 
	 * 向option表中插入可选数据记录
	 */
    public void save(Option option) {
	   Session session=sessionFactory.getCurrentSession();
	   session.save(option);
    }
    
    public Option selectOption(int id) {
    	Session session=sessionFactory.getCurrentSession();
    	Query query=session.createQuery("from Option o where o.id=?");
    	query.setParameter(0, id);
    	return (Option) query.uniqueResult();
    }
	
}
