package com.student.util;

import java.text.SimpleDateFormat;
import java.util.Date;

public class GetYearOrTerm {

	public static String getYear() {
		//获取系统的当前学年
		SimpleDateFormat sfDateFormat=new SimpleDateFormat("yyyy,MM,dd");
		String format=sfDateFormat.format(new Date());
		String[] str=format.split(",");
		int nowYear=Integer.parseInt(str[0]);
		int nowMonth=Integer.parseInt(str[1]);
		String year = null;//当前学年
		if(nowMonth>=9&&nowMonth<=12) {
			int behind=nowYear+1;
			year=nowYear+"-"+behind;
		}else {
			int front=nowYear-1;
			year=front+"-"+nowYear;
		}
		return year;
	}
    
	public static int getTerm() {
		//获取系统的当前学期
		SimpleDateFormat sfDateFormat=new SimpleDateFormat("yyyy,MM,dd");
		String format=sfDateFormat.format(new Date());
		String[] str=format.split(",");
		int nowYear=Integer.parseInt(str[0]);
		int nowMonth=Integer.parseInt(str[1]);
		int term=0;//学期
		if(nowMonth>=3&&nowMonth<=8) {
			term=2;
		}else{
			term =1;
		}
		return term;
	}
}
