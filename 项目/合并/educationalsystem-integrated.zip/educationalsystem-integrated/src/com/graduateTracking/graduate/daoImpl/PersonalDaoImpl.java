package com.graduateTracking.graduate.daoImpl;

import java.util.List;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import com.bean.Job;
import com.bean.Undergraduate;
import com.graduateTracking.graduate.dao.PersonalDao;
@Repository
public class PersonalDaoImpl extends BaseDaoImpl implements PersonalDao{

	

	
	@Override
	public List<Job> getAllJobPeopleByYear(String year) {
		String hql="from Job r where r.sclass=?";
		Query query = getSession().createQuery(hql);
		query.setParameter(0, year);
		List<Job> list=query.list();
		return list;
	}
	@Override
	public List<Undergraduate> getAllUnderGratuatePeopleByYear(String year) {
		String hql="from Undergraduate r where r.sclass=?";
		Query query = getSession().createQuery(hql);
		query.setParameter(0, year);
		List<Undergraduate> list=query.list();
		return list;
	}
}
