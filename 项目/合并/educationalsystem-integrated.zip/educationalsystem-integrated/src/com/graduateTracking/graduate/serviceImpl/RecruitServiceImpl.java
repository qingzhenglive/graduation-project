package com.graduateTracking.graduate.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bean.Recruit;
import com.graduateTracking.graduate.dao.RecruitDao;
import com.graduateTracking.graduate.service.RecruitService;
@Transactional
@Service
public class RecruitServiceImpl implements RecruitService{

	@Autowired
	private RecruitDao recruitDao;
	@Override
	public List<Recruit> getAllRecruit() {
		return recruitDao.getAllRecruit();
	}
	@Override
	public List<Recruit> getAllRecruitBySite(String site) {
		// TODO Auto-generated method stub
		return recruitDao.getAllRecruitBySite(site);
	}
	@Override
	public List<Recruit> getRecruitByClassify(String classify) {
		// TODO Auto-generated method stub
		return recruitDao.getRecruitByClassify(classify);
	}
	
	//通过分页查询
	@Override
	public List<Recruit> getRecruitByPage(int currentpage, int sum) {
		return recruitDao.getRecruitByPage(currentpage, sum);
	}
	@Override
	public Recruit getRecruitByRecruitId(int id) {
		// TODO Auto-generated method stub
		return recruitDao.getRecruitByRecruitId(id);
	}
	@Override
	public List<Recruit> getRecruitPartAttribute() {
		// TODO Auto-generated method stub
		return recruitDao.getRecruitPartAttribute();
	}
	@Override
	public List<Recruit> getRecruitByCompany(String name,int currentpage,int sum) {
		// TODO Auto-generated method stub
		return recruitDao.getRecruitByCompany(name,currentpage, sum);
	}

}
