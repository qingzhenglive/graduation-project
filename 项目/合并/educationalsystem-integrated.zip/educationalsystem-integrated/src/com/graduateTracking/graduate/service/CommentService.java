package com.graduateTracking.graduate.service;

import java.util.List;

import com.bean.Comment;

public interface CommentService {

	//	根据课堂的Id获得分页的评论
	 List<Comment> getPageCommentByTeachingId(int id,int currentPage,int sum);
	 //插入一条评论
	 void  InsertComment(Comment comment);
}
