package com.graduateTracking.graduate.daoImpl;

import java.util.List;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import com.bean.Company;
import com.graduateTracking.graduate.dao.CompanyDao;
@Repository
public class CompanyDaoImpl extends BaseDaoImpl implements CompanyDao{

	//根据用户Id获得公司
	public List<Company> getCompanyByPeopleId(int id){
		String hql="from Job";
	
		return null;
		
	}

	@Override
	public Company getCompanyByRecruitId(int id) {
		String hql="from Company r  where r.id=?";
		Query query = getSession().createQuery(hql);
		query.setParameter(0, id);
		Company company=(Company) query.uniqueResult();
		return company;
	}
}
