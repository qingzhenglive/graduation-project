package com.graduateTracking.graduate.service;

import java.util.List;

import com.bean.Company;

public interface CompanyService {

	//根据用户Id获得公司
	 List<Company> getCompanyByPeopleId(int id);
	 //根据招聘信息ID获得公司
	 Company getCompanyByRecruitId(int id);
}
