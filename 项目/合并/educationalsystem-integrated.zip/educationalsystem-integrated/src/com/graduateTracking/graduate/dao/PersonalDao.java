package com.graduateTracking.graduate.dao;

import java.util.List;

import com.bean.Job;
import com.bean.Undergraduate;

public interface PersonalDao {


	 //按年份查询工作的毕业生
	 List<Job> getAllJobPeopleByYear(String year);
	 //按年份查询考研的毕业生
	 List<Undergraduate> getAllUnderGratuatePeopleByYear(String year);
}
