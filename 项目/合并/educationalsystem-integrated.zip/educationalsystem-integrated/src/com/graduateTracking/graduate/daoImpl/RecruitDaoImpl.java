package com.graduateTracking.graduate.daoImpl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.stereotype.Repository;

import com.bean.Recruit;
import com.graduateTracking.graduate.dao.RecruitDao;

@Repository
public class RecruitDaoImpl extends BaseDaoImpl implements RecruitDao {

	@Override
	public List<Recruit> getAllRecruit() {
		String hql="from Recruit";
		List<Recruit> list = getSession().createQuery(hql).list();
		return list;
	}

	//通过地点查询
	@Override
	public List<Recruit> getAllRecruitBySite(String site) {
		String hql="from Recruit r  where r.site=?";
		Query query = getSession().createQuery(hql);
		query.setParameter(0, site);
		List<Recruit> list=query.list();
		return list;
	}

	//通过类别查询
	@Override
	public List<Recruit> getRecruitByClassify(String classify) {
		String hql="from Recruit r  where r.classify=?";
		Query query = getSession().createQuery(hql);
		query.setParameter(0, classify);
		List<Recruit> list=query.list();
		return list;
	}

	//分页查询
	@Override
	public List<Recruit> getRecruitByPage(int currentpage, int sum) {
		Session session=getSession();
		String hql="from Recruit r";
		Query query=session.createQuery(hql);
		
		query.setFirstResult((currentpage-1)*sum);
		query.setMaxResults(sum);
		List <Recruit>list = query.list();
		return list;
	}

	@Override
	public Recruit getRecruitByRecruitId(int id) {
		String hql="from Recruit r  where r. id=?";
		Query query = getSession().createQuery(hql);
		query.setParameter(0, id);
		Recruit recruit=(Recruit) query.uniqueResult();
		return recruit;
	}

	@Override
	public List<Recruit> getRecruitPartAttribute() {
		String hql="select new Recruit(r.name,r.salary,r.company) from Recruit r";
		Query query = getSession().createQuery(hql);
		query.setFirstResult(0);
		query.setMaxResults(3);
		List <Recruit> list=query.list();
		return list;
	}

	@Override
	public List<Recruit> getRecruitByCompany(String name,int currentpage,int sum) {
		String hql="select  from Recruit r  where r.company.name=?";
		Query query = getSession().createQuery(hql);
		query.setParameter(0, name);
		query.setFirstResult((currentpage-1)*sum);
		query.setMaxResults(sum);
		List <Recruit> list=query.list();
		return list;
	}

	


}
