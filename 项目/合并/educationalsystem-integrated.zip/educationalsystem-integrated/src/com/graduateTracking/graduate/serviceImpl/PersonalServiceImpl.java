package com.graduateTracking.graduate.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bean.Job;
import com.bean.Undergraduate;
import com.graduateTracking.graduate.dao.PersonalDao;
import com.graduateTracking.graduate.service.PersonalService;

@Service
public class PersonalServiceImpl  implements PersonalService{
	@Autowired
	private PersonalDao personalDao;


	@Override
	public List<Job> getAllJobPeopleByYear(String year) {
		// TODO Auto-generated method stub
		return personalDao.getAllJobPeopleByYear(year);
	}

	@Override
	public List<Undergraduate> getAllUnderGratuatePeopleByYear(String year) {
		// TODO Auto-generated method stub
		return personalDao.getAllUnderGratuatePeopleByYear(year);
	}
}
