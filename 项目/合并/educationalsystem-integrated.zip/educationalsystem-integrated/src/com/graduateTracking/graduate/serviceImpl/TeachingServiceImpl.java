package com.graduateTracking.graduate.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bean.Teaching;
import com.graduateTracking.graduate.dao.TeachingDao;
import com.graduateTracking.graduate.service.TeachingService;
@Service
public class TeachingServiceImpl implements TeachingService{
	

	@Autowired
	private TeachingDao teachingDao;
	//	查询所有的的招募信息
	 public List<Teaching> getAllTeaching(){
		 return teachingDao.getAllTeaching();
	 }

	@Override
	public List<Teaching> getAllTeachingByPage(int currentPage, int sum) {
		// TODO Auto-generated method stub
		return teachingDao.getAllTeachingByPage(currentPage, sum);
	}

	@Override
	public List<Teaching> getPartAttributeTeachingByPage(int currentPage, int sum) {
		return teachingDao.getPartAttributeTeachingByPage(currentPage, sum);
	}

	@Override
	public Teaching getTeachingById(int teachingId) {
		// TODO Auto-generated method stub
		return teachingDao.getTeachingById(teachingId);
	}

	@Override
	public void saveTeaching(Teaching teaching) {
		teachingDao.saveTeaching(teaching);
		
	}

	
	
	
}
