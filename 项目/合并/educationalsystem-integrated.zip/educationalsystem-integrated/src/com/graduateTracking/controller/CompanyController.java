package com.graduateTracking.controller;

import java.util.List;

import org.springframework.stereotype.Controller;

import com.bean.Company;
@Controller
public class CompanyController{

	//根据用户Id获得公司
	public List<Company> getCompanyByPeopleId(int id){
		String hql="from Job";
		
		return null;
		
	}
}
