package com.graduateTracking.controller;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.bean.Comment;
import com.bean.Teaching;
import com.graduateTracking.graduate.service.CommentService;
import com.graduateTracking.graduate.service.TeachingService;


@Controller
public class TeachingController{

	@Autowired
	private TeachingService teachingService;
	@Autowired
	private CommentService commentService;
	
	
	//	查询所有的的视频信息
	@RequestMapping("/getAllTeaching")
	public  ModelAndView getAllTeaching(HttpServletRequest request){
		List<Teaching> list = teachingService.getAllTeaching();
		//session.setAttribute("AllRecruit", list);
		ModelAndView modelAndView=new ModelAndView();
		modelAndView.setViewName("/square");
		return modelAndView;
	 }
	
	
	//	分页查询所有的视频信息
	@RequestMapping("/getAllTeachingByPage")
	public  ModelAndView getAllTeachingByPage(HttpServletRequest request){
		String page =  request.getParameter("currentPage");
		Integer currentPage=Integer.valueOf(page);
		if(page==null) {currentPage=1;}
		List<Teaching> list = teachingService.getAllTeachingByPage(currentPage, 4);
		ModelAndView modelAndView=new ModelAndView();
		modelAndView.addObject("AllTeachingByPage",list);
		modelAndView.setViewName("/schoolmate");
		return modelAndView;
	}
	
	 //分页查询部分课堂属性  第一次从列表页查询的时候
	@RequestMapping("/getPartAttributeTeachingByPage")
	public ModelAndView getPartAttributeTeachingByPage( HttpServletResponse response,HttpServletRequest request,HttpSession session) throws UnsupportedEncodingException, IOException{
		String page =  request.getParameter("currentPage");
		String teaching_id =  request.getParameter("teaching_id");
		Integer currentPage=Integer.valueOf(page);
		Integer teachingId=Integer.valueOf(teaching_id);
		Teaching teaching=teachingService.getTeachingById(teachingId);
		if(page==null) {currentPage=1;}
		List<Teaching> Teachinglist = teachingService.getPartAttributeTeachingByPage(1, 3);
		List<Comment> Commentlist = commentService.getPageCommentByTeachingId(teachingId, currentPage,3);
		ModelAndView modelAndView=new ModelAndView();
		modelAndView.addObject("Teachinglist",Teachinglist);
		modelAndView.addObject("Commentlist",Commentlist);
		modelAndView.addObject("teachingById",teachingId);
		modelAndView.addObject("currentPage",currentPage);
		session.setAttribute("teachingById", teachingId);
		modelAndView.setViewName("/watch");
		return modelAndView;
	 }
	
	//视频页面的推荐的局部刷新
	@RequestMapping("/getRecommendTeachingByPage")
	@ResponseBody
	public ModelAndView getRecommendTeachingByPage( HttpServletResponse response,HttpServletRequest request) 
	{
		String page =  request.getParameter("currentPage");
		String teaching_id =  request.getParameter("teaching_id");
		Integer currentPage=Integer.valueOf(page);
		Integer teachingId=Integer.valueOf(teaching_id);
		Teaching teaching=teachingService.getTeachingById(teachingId);
		if(page==null) {currentPage=1;}
		List<Teaching> Teachinglist = teachingService.getPartAttributeTeachingByPage(currentPage, 3);
		ModelAndView modelAndView=new ModelAndView();
		modelAndView.addObject("Teachinglist",Teachinglist);
		modelAndView.addObject("teachingById",teachingId);
		modelAndView.setViewName("/watch_Recommend");
		return modelAndView;
		
	}
		
	
	//视频页面的推荐的局部刷新
	@RequestMapping("/getCommendTeachingByPage")
	@ResponseBody
	public ModelAndView getCommendTeachingByPage( HttpServletResponse response,HttpServletRequest request) 
	{
		String page =  request.getParameter("currentPage");
		String teaching_id =  request.getParameter("teaching_id");
		Integer currentPage=Integer.valueOf(page);
		Integer teachingId=Integer.valueOf(teaching_id);
		Teaching teaching=teachingService.getTeachingById(teachingId);
		if(page==null) {currentPage=1;}
		List<Comment> commentslist = commentService.getPageCommentByTeachingId(teachingId, currentPage, 3);
		ModelAndView modelAndView=new ModelAndView();
		modelAndView.addObject("commentslist",commentslist);
		modelAndView.addObject("teachingById",teachingId);
		modelAndView.setViewName("/watch_Comment");
		return modelAndView;
		
	}
		
	 //上传课堂
		@RequestMapping(value="/gotoAction")
	    public ModelAndView upload(@RequestParam("image") MultipartFile imagefile,@RequestParam("video") MultipartFile videofile,HttpServletRequest request) throws IllegalStateException, IOException{
			    String contextPath = request.getContextPath();//"/SpringMvcFileUpload"
	            String servletPath = request.getServletPath();//"/gotoAction"
	            String scheme = request.getScheme();
	            String storePath= request.getSession().getServletContext().getRealPath("image/");
	            String ImagePath="";
	            String VideoPath="";
			 if (!imagefile.isEmpty()) {
				 
	            String fileName = imagefile.getOriginalFilename();
	            ImagePath="image/"+fileName;
	            File filepath= new File(storePath, fileName);
	            if (!filepath.getParentFile().exists()) {
                    filepath.getParentFile().mkdirs();//如果目录不存在，创建目录
	            }
	            imagefile.transferTo(new File(storePath+File.separator+fileName));//把文件写入目标文件地址
	        }
           if (!videofile.isEmpty()) {
	            String fileName = videofile.getOriginalFilename();
	            VideoPath="image/"+fileName;
	            File filepath2 = new File(storePath, fileName);
	            if (!filepath2.getParentFile().exists()) {
	            	  filepath2.getParentFile().mkdirs();//如果目录不存在，创建目录
	            }
	            videofile.transferTo(new File(storePath+File.separator+fileName));//把文件写入目标文件地址
	        }
            String describe=request.getParameter("describe");
			String summary=request.getParameter("summary");
			String type=request.getParameter("type");
			String image=request.getParameter("image");
			String video=request.getParameter("video");
			String name=request.getParameter("name");
			
			HttpSession session=request.getSession();
			Teaching teaching=new  Teaching();
			teaching.setDescribe(describe);
			teaching.setName(name);
			teaching.setType(type);
			teaching.setSummary(summary);
   		    teaching.setVideo(VideoPath);
			teaching.setWatcher(0);
			teaching.setImages(ImagePath);
		
			//拿到user后要插入数据库对应的user的 Id
			Object object = session.getAttribute("user");
			teaching.setLecturer(null);
			teachingService.saveTeaching(teaching);
			ModelAndView modelAndView=new ModelAndView();
			List<Teaching> list = teachingService.getAllTeachingByPage(1, 4);
			modelAndView.addObject("AllTeachingByPage",list);
			modelAndView.setViewName("/schoolmate");
			return modelAndView;
		 }
		 
}
