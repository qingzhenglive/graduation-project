package com.graduateTracking.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.bean.Comment;
import com.bean.Student;
import com.bean.Teaching;
import com.graduateTracking.graduate.service.CommentService;
import com.graduateTracking.graduate.service.TeachingService;
@Controller
public class CommentController {

	@Autowired
	private CommentService commentService;
	@Autowired
	private TeachingService teachingService;
	
	 //	根据课堂的Id所有的评论
	@RequestMapping("/getPageCommentByTeachingId")
	public ModelAndView getPageCommentByTeachingId(HttpServletRequest request){
		String page =  request.getParameter("currentPage");
		String teaching_id =  request.getParameter("teaching_id");
		Integer currentPage=Integer.valueOf(page);
		Integer teachingId=Integer.valueOf(teaching_id);
		if(page==null) {currentPage=1;}
		List<Comment> list = commentService.getPageCommentByTeachingId(teachingId, currentPage, 3);
		ModelAndView modelAndView=new ModelAndView();
		modelAndView.addObject("PageCommentByTeachingId",list);
		modelAndView.setViewName("/watch");
		return modelAndView;
	 }
	
		//插入一条评论
	@RequestMapping("/InsertComment")
		public  ModelAndView  InsertComment(HttpServletRequest request,HttpSession session) {
			String content=request.getParameter("content");
			String teachId=request.getParameter("teachingById");
			System.out.println(teachId+"shdkafksfsdkjjksdkj");
			Integer teachingById = Integer.valueOf(teachId);
			Student student=(Student) session.getAttribute("user");
			 SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");//设置日期格式
	          System.out.println(df.format(new Date()));// new Date()为获取当前系统时间
	          String time = df.format(new Date()).toString();
	          Comment comment=new Comment();
	          comment.setContent(content);
	          
	          /* 合并之后需要修改user  更改user的登录
	           * */
	          comment.setStudent(null);
	          Teaching teaching = teachingService.getTeachingById(teachingById);
	      		System.out.println(teaching+"绿山咖啡交啊收款方啥课复试");
	          comment.setTeaching(teaching);
	          commentService.InsertComment(comment);
	          ModelAndView modelAndView=new ModelAndView();
	          
	  			modelAndView.setViewName("/getPartAttributeTeachingByPage?currentPage=1&teaching_id="+teachId);
	  		return modelAndView;
		}
}
