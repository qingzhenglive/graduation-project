package com.graduateTracking.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.bean.Company;
import com.bean.Recruit;
import com.graduateTracking.graduate.service.CompanyService;
import com.graduateTracking.graduate.service.RecruitService;

@Controller
public class RecruitController{
	@Autowired
	private RecruitService recruitService;
	@Autowired
	private CompanyService companyService;
	
	//查询所有的的招募信息
	@RequestMapping("/getAllRecruit")
	public ModelAndView getAllRecruit(HttpServletRequest request,HttpSession session){
		List<Recruit> list = recruitService.getAllRecruit();
		session.setAttribute("AllRecruit", list);
		ModelAndView modelAndView=new ModelAndView();
		modelAndView.setViewName("/square");
		return modelAndView;
	}
		//根据地区查询招募信息
	@RequestMapping("/getAllRecruitBySite")
	public ModelAndView getAllRecruitBySite(HttpServletRequest request,HttpSession session){
		String site = request.getParameter("site");
		List<Recruit> list = recruitService.getAllRecruitBySite(site);
		session.setAttribute("RecruitBySite", list);
		ModelAndView modelAndView=new ModelAndView();
		modelAndView.setViewName("/square");
		return modelAndView;
		
	}
	 	//根据类别查询招募信息
	@RequestMapping("/getRecruitByClassify")
	public ModelAndView getRecruitByClassify(HttpServletRequest request,HttpSession session){
		String classify = request.getParameter("classify");
		List<Recruit> list = recruitService.getRecruitByClassify(classify);
		session.setAttribute("RecruitByClassify", list);
		ModelAndView modelAndView=new ModelAndView();
		modelAndView.setViewName("/square");
		return modelAndView;
	}
	////根据分页查询招募信息
	@RequestMapping("/getRecruitByPage")
	public ModelAndView getRecruitByPage(HttpServletRequest request,HttpSession session){
		String page = request.getParameter("currentPage");
		Integer currentPage=Integer.valueOf(page);
		if(page==null) {currentPage=1;}
		List<Recruit> list = recruitService.getRecruitByPage(currentPage, 4);
		ModelAndView modelAndView=new ModelAndView();
		modelAndView.addObject("RecruitByPage",list);
		modelAndView.addObject("Page","page");
		modelAndView.setViewName("/square");
		return modelAndView;
		 
	 }
	 //根据RecruitId获得招募详情
	@RequestMapping("/getRecruitByRecruitId")
	public ModelAndView getRecruitByRecruitId(HttpServletRequest request){
		String id = request.getParameter("recruit_id");
		Integer recruit_id=Integer.valueOf(id);
		if(id==null) {recruit_id=1;}
		Recruit recruit = recruitService.getRecruitByRecruitId(recruit_id);
		Company company = companyService.getCompanyByRecruitId(recruit_id);
		List <Recruit> list=recruitService.getRecruitPartAttribute();
		ModelAndView modelAndView=new ModelAndView();
		modelAndView.addObject("recruit",recruit);
		modelAndView.addObject("company",company);
		modelAndView.addObject("recruitList",list);
		modelAndView.setViewName("/post");
		return modelAndView;
	 }
	
	//根据公司名字查询
	@RequestMapping("/getRecruitByCompany")
		public ModelAndView getRecruitByCompany(HttpServletRequest request){
			String companyName = request.getParameter("id");
			int id=Integer.valueOf(companyName);
			
			ModelAndView modelAndView=new ModelAndView();
			List <String> company=new ArrayList<String>();
			company.add(0, "百度");
			company.add(1, "趣头条");
			company.add(2, "跳动字节");
			company.add(3, "之江");
			company.add(4, "猿辅导");
			company.add(5, "畅游");
			List <Recruit> list=recruitService.getRecruitByCompany(company.get(id),1,6);
			modelAndView.addObject("recruitList",list);
			modelAndView.setViewName("/post");
			return modelAndView;
		 }
	
}
