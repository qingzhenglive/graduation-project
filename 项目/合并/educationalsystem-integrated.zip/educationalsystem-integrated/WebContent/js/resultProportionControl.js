filterAttrs = document.getElementsByClassName('filterAttr');
		for(var i=0; i<filterAttrs.length; ++i){
			filterAttrs[i].onclick = function(){
				var start = this.parentNode;
				if(!this.checked){
					// console.log('没选中');
					start.style.opacity = 0.2;
					for(var j=0; j<5; ++j){
						for(var k=0; k<7; ++k){
							if(start.nextElementSibling == null){
								start = start.parentNode.nextElementSibling.firstElementChild;
							} else {
								start = start.nextElementSibling;
							}
							
						}
						start.style.opacity = 0.2;
						start.firstElementChild.value = 0;
						start.firstElementChild.setAttribute('readonly', 'readonly');
					}
				} else{
					console.log('选中了');
					start.style.opacity = 1;
					for(var j=0; j<5; ++j){
						for(var k=0; k<7; ++k){
							if(start.nextElementSibling == null){
								start = start.parentNode.nextElementSibling.firstElementChild;
							} else {
								start = start.nextElementSibling;
							}
						}
						// console.log(start)
						start.style.opacity = 1;
						start.firstElementChild.value = "";
						start.firstElementChild.removeAttribute('readonly');
					}
				}
			}
		}