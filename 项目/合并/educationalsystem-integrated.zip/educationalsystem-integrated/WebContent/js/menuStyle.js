function p(inf){
			console.log(inf);
		}

		var extensions = document.getElementsByClassName("extension");
		var innerUls = document.getElementsByClassName("innerUl");
		var isExtended = false;
		// 点击让扩展菜单显示
		for(var i = 0; i < extensions.length; ++i){
			extensions[i].onclick = function(e){
				if(isExtended == false){
					p("应该显示出来")
					this.nextElementSibling.style.display = "block";
					isExtended = true;
				} else{
					p("已经出来了收回")
					for(var i =0; i < innerUls.length; ++i){
						innerUls[i].style.display = "none";
						isExtended = false;
					}
				}
				e.stopPropagation();
			};
		}
		
		// 点击任意地方扩展部分消失
		document.body.onclick =function(){
			for(var i =0; i < innerUls.length; ++i){
				innerUls[i].style.display = "none";
			}
			isExtended = false;
		}

//		// 除了弹窗意外点击其他地方都不消失 
//		for(var i =0; i < innerUls.length; ++i){
//			innerUls[i].onclick = function(){
//				e.stopPropagation();
//			}
//		}